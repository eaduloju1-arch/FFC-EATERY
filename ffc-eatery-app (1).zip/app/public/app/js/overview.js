/* Overview: how the business is doing right now */
import { S, D, actions, loaders, hooks, branchName, itemById, itemName, itemEmoji, hueOf, hueVars, visibleBranchIds } from './state.js';
import { esc, ic, money, tm, dlabel, compact } from './util.js';
import { api } from './api.js';
import { pageHead, stat, empty, pill, hourBars, rankList, branchOptions, methodLabel } from './ui.js';

loaders.overview = async () => {
  D.overview = await api('GET', '/api/overview' + (S.ovBranch !== 'all' ? '?branch=' + encodeURIComponent(S.ovBranch) : ''));
};

const greet = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };

function periodCard(label, sub, a, hue) {
  return '<div class="pcard" style="' + hueVars(hue) + '"><span class="pl">' + esc(label) + '</span><small>' + esc(sub) + '</small>' +
    '<b class="pv" data-count="' + a.sales.total + '" data-money>' + money(a.sales.total) + '</b>' +
    '<div class="pf"><span>' + a.sales.count + ' order' + (a.sales.count === 1 ? '' : 's') + '</span><span>Spent ' + money(a.expenses.total) + '</span><span class="net ' + (a.net < 0 ? 'neg' : '') + '">Net ' + money(a.net) + '</span></div></div>';
}

export function overviewView() {
  const o = D.overview, bs = visibleBranchIds(), multi = bs.length > 1;
  const scope = S.ovBranch !== 'all' ? branchName(S.ovBranch) : (multi ? 'All branches' : branchName(bs[0]));
  const rangeLabel = (r) => dlabel(r[0]) + ' to ' + dlabel(r[1]);
  const low = o.low.map(l => {
    const it = itemById(l.itemId); if (!it) return '';
    return '<li class="lowrow"><span class="ce" aria-hidden="true">' + esc(itemEmoji(l.itemId)) + '</span><div><b>' + esc(it.name) + '</b><small>' + (multi ? esc(branchName(l.branch)) + ' · ' : '') + 'Reorder at ' + l.reorder + '</small></div>' +
      (l.qty <= 0 ? pill('Out of stock', 'bad') : pill(l.qty + ' left', 'warn')) + '</li>';
  }).join('');
  const shifts = o.openShifts.map(s => '<li class="lowrow"><span class="ce" aria-hidden="true">' + ic('clock', 22) + '</span><div><b>' + esc(s.byName) + '</b><small>' + (multi ? esc(branchName(s.branch)) + ' · ' : '') + 'Since ' + tm(s.openedAt) + ' · ' + s.count + ' sale' + (s.count === 1 ? '' : 's') + '</small></div><b>' + money(s.cashSales) + '</b></li>').join('');
  const recent = o.recent.map(s => '<li><button class="sale' + (s.voided ? ' void' : '') + '" data-act="ov-sale" data-id="' + esc(s.id) + '"><span class="st">' + tm(s.at) + '</span><div class="sm"><b>' + esc(s.no) + '</b><span class="items">' +
    esc(s.lines.map(l => l.qty + '× ' + l.name).join(', ')) + '</span><small>' + esc(s.byName) + (multi ? ' · ' + esc(branchName(s.branch)) : '') + '</small></div><div class="sr"><b>' + money(s.total) + '</b>' +
    (s.voided ? pill('Voided', 'bad') : '<span class="mchip">' + methodLabel(s.method) + '</span>') + '</div></button></li>').join('');
  return pageHead(greet() + ', ' + esc(S.user.name.split(' ')[0]), esc(scope) + ' · ' + esc(dlabel(o.today)),
      S.user.role === 'gm' && multi ? '<label class="f inl"><span>Branch</span><select data-change="ov-branch">' + branchOptions(S.ovBranch, null, true) + '</select></label>' : '') +
    (o.pending > 0 ? '<button class="alert-card" data-act="go" data-v="transfers">' + ic('swap', 24) + '<div><b>' + o.pending + ' stock transfer' + (o.pending === 1 ? '' : 's') + ' waiting for approval</b><small>Review and approve them so stock reaches the branch.</small></div>' + ic('right', 20) + '</button>' : '') +
    '<div class="pcards">' + periodCard('Today', dlabel(o.today), { sales: o.day.sales, expenses: o.day.expenses, net: o.day.net }, 1) +
      periodCard('This week', rangeLabel(o.week), { sales: o.weekAgg.sales, expenses: o.weekAgg.expenses, net: o.weekAgg.net }, 2) +
      periodCard('This month', rangeLabel(o.month), { sales: o.monthAgg.sales, expenses: o.monthAgg.expenses, net: o.monthAgg.net }, 5) + '</div>' +
    '<div class="two"><section class="card"><h2>Sales by hour today</h2>' + hourBars(o.byHour) + '</section>' +
      '<section class="card"><h2>Best sellers today</h2>' + rankList(o.topToday, r => r.qty, r => r.name, r => r.qty + ' sold · ' + money(r.revenue), r => { const it = itemById(r.itemId); return it ? hueOf(it.category) : 1; }) + '</section></div>' +
    (o.byBranch.length ? '<section class="card"><h2>Branches</h2><div class="brs">' + o.byBranch.map((b, i) => '<div class="br" style="' + hueVars(i % 2 ? 5 : 2) + '"><b>' + esc(branchName(b.branch)) + '</b>' +
      '<div><span>Today</span><b>' + money(b.day.sales.total) + '</b></div><div><span>This week</span><b>' + money(b.week.sales.total) + '</b></div><div><span>This month</span><b>' + money(b.month.sales.total) + '</b></div>' +
      '<div><span>Net this month</span><b class="' + (b.month.net < 0 ? 'neg' : '') + '">' + money(b.month.net) + '</b></div></div>').join('') + '</div></section>' : '') +
    '<div class="two"><section class="card"><div class="ch"><h2>Running low</h2><button class="btn sm" data-act="go" data-v="stock">Open stock</button></div>' +
      (low ? '<ul class="plain">' + low + '</ul>' : empty('✅', 'Everything is stocked', 'No item is at its reorder level.')) + '</section>' +
    '<section class="card"><h2>Open shifts</h2>' + (shifts ? '<ul class="plain">' + shifts + '</ul>' : '<p class="muted">Nobody has a shift open right now.</p>') + '</section></div>' +
    '<section class="card"><div class="ch"><h2>Latest sales</h2><button class="btn sm" data-act="go" data-v="sales">All sales</button></div>' +
      (recent ? '<ul class="sales-l">' + recent + '</ul>' : '<p class="muted">No sales in the last few days.</p>') + '</section>';
}

actions['ov-branch'] = el => { S.ovBranch = el.value; hooks.reload(); };
actions['ov-sale'] = el => { const s = D.overview.recent.find(x => x.id === el.dataset.id); if (s) hooks.openModal({ type: 'receipt', sale: s }); };
