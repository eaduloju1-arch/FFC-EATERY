/* Stock: what is on the shelf, receiving deliveries, wastage and recounts */
import { S, D, F, fv, actions, loaders, modalViews, hooks, biz, branches, branchName, itemById, itemName, activeItems, hueOf, hueVars, visibleBranchIds, isMulti } from './state.js';
import { esc, ic, money, num, dt, tm } from './util.js';
import { api } from './api.js';
import { pageHead, sheetHead, catChips, field, pill, stat, empty, run, branchOptions, itemOptions } from './ui.js';

const canReceive = () => S.user.role === 'procurement' || S.user.role === 'gm';
const canAdjust = () => S.user.role === 'supervisor' || S.user.role === 'gm';

loaders.stock = async () => {
  const jobs = [api('GET', '/api/stock')];
  if (S.user.role !== 'sales') jobs.push(api('GET', '/api/stock/movements'));
  const r = await Promise.all(jobs);
  D.stock = { stock: r[0].stock, reserved: r[0].reserved, moves: r[1] ? r[1].movements : null };
};

const qtyOf = (b, id) => ((D.stock.stock[b] || {})[id]) || 0;
const level = (q, it) => q <= 0 ? 'out' : q <= (it.reorder == null ? 5 : it.reorder) ? 'low' : 'ok';

function item(i) {
  const bs = visibleBranchIds().filter(b => D.stock.stock[b]);
  const cells = bs.map(b => {
    const q = qtyOf(b, i.id), lv = level(q, i), rs = D.stock.reserved[b + '|' + i.id] || 0, max = Math.max((i.reorder == null ? 5 : i.reorder) * 3, q, 1);
    return '<div class="qc ' + lv + '"><span class="qb">' + (isMulti() ? esc(branchName(b)) : lv === 'out' ? 'Sold out' : lv === 'low' ? 'Running low' : 'In stock') + '</span><b>' + q + '</b>' +
      '<i class="qbar"><u style="--w:' + Math.min(100, Math.round(q / max * 100)) + '%"></u></i>' + (rs ? '<small>' + rs + ' promised to a transfer</small>' : '') + '</div>';
  }).join('');
  return '<article class="card stk" style="' + hueVars(hueOf(i.category)) + '"><div class="sk-h"><span class="ce" aria-hidden="true">' + esc(i.emoji || '🍽️') + '</span><div><b>' + esc(i.name) + '</b><small>' + esc(i.category) + ' · ' + money(i.price) + ' · reorder at ' + (i.reorder == null ? 5 : i.reorder) + '</small></div>' +
    '<div class="sk-a">' + (canReceive() ? '<button class="ib sm" data-act="stk-receive" data-id="' + esc(i.id) + '" aria-label="Receive ' + esc(i.name) + '" title="Receive stock">' + ic('plus', 18) + '</button>' : '') +
    (canAdjust() ? '<button class="ib sm" data-act="stk-adjust" data-id="' + esc(i.id) + '" aria-label="Adjust ' + esc(i.name) + '" title="Wastage or recount">' + ic('sliders', 18) + '</button>' : '') + '</div></div><div class="qcs">' + cells + '</div></article>';
}

export function stockView() {
  const items = activeItems(), cats = []; items.forEach(i => { if (!cats.includes(i.category)) cats.push(i.category); });
  const cat = cats.includes(S.stockCat) ? S.stockCat : 'All', list = items.filter(i => cat === 'All' || i.category === cat), bs = visibleBranchIds().filter(b => D.stock.stock[b]);
  let out = 0, low = 0; items.forEach(i => bs.forEach(b => { const l = level(qtyOf(b, i.id), i); if (l === 'out') out++; else if (l === 'low') low++; }));
  const mv = D.stock.moves;
  return pageHead('Stock', S.user.role === 'sales' ? 'What is left at your branch.' : 'Levels, deliveries, wastage and recounts.',
      (canReceive() ? '<button class="btn primary" data-act="stk-receive">' + ic('plus', 18) + 'Receive stock</button>' : '') + (canAdjust() ? '<button class="btn" data-act="stk-adjust">' + ic('sliders', 18) + 'Wastage or recount</button>' : '')) +
    '<div class="stats">' + stat('Sold out', out, { plain: true, hue: 1, sub: out ? 'Needs restocking now' : 'Nothing is sold out' }) + stat('Running low', low, { plain: true, hue: 3, sub: 'At or below reorder level' }) + stat('Dishes on the menu', items.length, { plain: true, hue: 4 }) + '</div>' +
    catChips(cats, cat, 'stk-cat') +
    (list.length ? '<div class="stk-g">' + list.map(item).join('') + '</div>' : empty('📦', 'No items here', 'Add dishes in Settings.')) +
    (mv ? '<section class="card"><h2>Recent stock movements</h2>' + (mv.length ? '<ul class="plain">' + mv.map(m => '<li class="lowrow"><div><b>' + esc(itemName(m.itemId)) + '</b><small>' + esc(m.kind) + (isMulti() ? ' · ' + esc(branchName(m.branch)) : '') + ' · ' + esc(m.byName) + ' · ' + esc(dt(m.at)) + (m.note ? ' · ' + esc(m.note) : '') + '</small></div><b class="' + (m.qty < 0 ? 'neg' : 'pos') + '">' + (m.qty > 0 ? '+' : '') + m.qty + '</b></li>').join('') + '</ul>' : '<p class="muted">No movements in the last 30 days.</p>') + '</section>' : '');
}
actions['stk-cat'] = el => { S.stockCat = el.dataset.v; hooks.render(); };

/* ---------- receive ---------- */
const re = () => hooks.renderModal();

modalViews.restock = () => {
  const bs = visibleBranchIds(), b = fv('m.branch', bs[0]), id = fv('m.item'), cost = num(fv('m.cost')), it = itemById(id);
  return sheetHead('Receive stock', 'Add a delivery or purchase to a branch.') + '<div class="sh-body scroll">' +
    '<div class="grid2">' + field('Branch', '<select data-f="m.branch" data-change="modal-refresh">' + branchOptions(b, bs) + '</select>') + field('Item', '<select data-f="m.item" data-change="modal-refresh">' + itemOptions(id, 'Choose an item') + '</select>', it ? 'Now ' + qtyOf(b, id) + ' at ' + esc(branchName(b)) : '') + '</div>' +
    '<div class="grid2">' + field('Quantity received', '<input inputmode="numeric" data-autofocus data-f="m.qty" value="' + esc(fv('m.qty')) + '" autocomplete="off">') + field('Cost paid (optional)', '<input inputmode="decimal" data-f="m.cost" data-input="modal-refresh" value="' + esc(fv('m.cost')) + '" autocomplete="off">') + '</div>' +
    (cost > 0 ? '<label class="chk"><input type="checkbox" data-f="m.also"' + (fv('m.also', true) ? ' checked' : '') + '><span>Also record ' + money(cost) + ' as a food supplies expense</span></label>' : '') +
    field('Note (optional)', '<input maxlength="120" data-f="m.note" data-enter="stk-do-receive" placeholder="Supplier or invoice" value="' + esc(fv('m.note')) + '" autocomplete="off">') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="stk-do-receive">Add to stock</button></div>';
};
actions['stk-receive'] = el => hooks.openModal({ type: 'restock', f: { 'm.branch': visibleBranchIds()[0], 'm.item': el.dataset.id || '', 'm.also': true } });
actions['stk-do-receive'] = el => run(el, async () => {
  const b = fv('m.branch', visibleBranchIds()[0]), id = fv('m.item'), qty = Math.floor(num(fv('m.qty'))), cost = num(fv('m.cost'));
  if (!id) throw new Error('Choose an item.'); if (!(qty >= 1)) throw new Error('Enter a quantity of 1 or more.');
  await api('POST', '/api/restocks', { branch: b, itemId: id, qty, cost, note: (fv('m.note') || '').trim(), alsoExpense: cost > 0 && fv('m.also', true) !== false });
  hooks.closeModal(); await hooks.reload();
}, { ok: 'Stock added.' });

/* ---------- adjust ---------- */
modalViews.adjust = () => {
  const bs = S.user.role === 'supervisor' ? [S.user.branch] : branches().map(b => b.id), b = fv('m.branch', bs[0]), id = fv('m.item'), reason = fv('m.reason', 'Wastage'), it = itemById(id), recount = reason === 'Recount';
  return sheetHead('Wastage or recount', 'Take stock out for a reason, or correct the count.') + '<div class="sh-body scroll">' +
    '<div class="grid2">' + (bs.length > 1 ? field('Branch', '<select data-f="m.branch" data-change="modal-refresh">' + branchOptions(b, bs) + '</select>') : '') + field('Item', '<select data-f="m.item" data-change="modal-refresh">' + itemOptions(id, 'Choose an item') + '</select>', it ? 'Now ' + qtyOf(b, id) + ' at ' + esc(branchName(b)) : '') + '</div>' +
    field('Reason', '<select data-f="m.reason" data-change="modal-refresh">' + S.config.adjustReasons.map(r => '<option' + (r === reason ? ' selected' : '') + '>' + esc(r) + '</option>').join('') + '</select>', recount ? 'A recount can add or remove stock.' : 'This removes stock.') +
    (recount ? '<div class="seg" role="group" aria-label="Direction"><button class="' + (fv('m.dir', 'add') === 'add' ? 'on' : '') + '" data-act="adj-dir" data-v="add">Add to stock</button><button class="' + (fv('m.dir', 'add') === 'remove' ? 'on' : '') + '" data-act="adj-dir" data-v="remove">Remove from stock</button></div>' : '') +
    '<div class="grid2">' + field('Quantity', '<input inputmode="numeric" data-autofocus data-f="m.qty" value="' + esc(fv('m.qty')) + '" autocomplete="off">') + field('Note (optional)', '<input maxlength="120" data-f="m.note" data-enter="stk-do-adjust" value="' + esc(fv('m.note')) + '" autocomplete="off">') + '</div></div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="stk-do-adjust">Save</button></div>';
};
actions['stk-adjust'] = el => hooks.openModal({ type: 'adjust', f: { 'm.branch': S.user.role === 'supervisor' ? S.user.branch : branches()[0].id, 'm.item': el.dataset.id || '', 'm.reason': 'Wastage', 'm.dir': 'add' } });
actions['adj-dir'] = el => { F['m.dir'] = el.dataset.v; re(); };
actions['stk-do-adjust'] = el => run(el, async () => {
  const b = S.user.role === 'supervisor' ? S.user.branch : fv('m.branch', branches()[0].id), id = fv('m.item'), reason = fv('m.reason', 'Wastage'), q = Math.floor(num(fv('m.qty')));
  if (!id) throw new Error('Choose an item.'); if (!(q >= 1)) throw new Error('Enter a quantity of 1 or more.');
  const delta = reason === 'Recount' && fv('m.dir', 'add') === 'add' ? q : -q;
  await api('POST', '/api/adjustments', { branch: b, itemId: id, delta, reason, note: (fv('m.note') || '').trim() });
  hooks.closeModal(); await hooks.reload();
}, { ok: 'Stock updated.' });
