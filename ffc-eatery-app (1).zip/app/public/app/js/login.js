/* Sign-in: pick a role, pick your name, tap your PIN */
import { S, ROLES, ROLE_ORDER, actions, hooks, hueVars } from './state.js';
import { $, esc, ic, toast } from './util.js';
import { api, setToken } from './api.js';

const STICKERS = [['🍛', 1], ['🍗', 2], ['🌯', 3], ['🍹', 6], ['🥧', 4], ['🍩', 5]];

const dots = () => Array.from({ length: 6 }, (_, i) => '<span class="dot' + (i < S.pin.length ? ' on' : '') + '"></span>').join('');

export function loginView() {
  const intro = S.loginIntro; S.loginIntro = false;
  const users = S.loginRole ? S.roster.filter(u => u.role === S.loginRole) : [];
  if (S.loginRole && !users.find(u => u.id === S.loginUser)) S.loginUser = users[0] ? users[0].id : '';
  const tickets = ROLE_ORDER.map((r, i) => {
    const R = ROLES[r];
    return '<button class="ticket ' + (S.loginRole === r ? 'on' : '') + '" style="' + hueVars(R.hue) + ';--i:' + i + '" data-act="pick-role" data-v="' + r + '">' +
      '<span class="stub">' + ic(R.icon, 26) + '</span><span class="tx"><b>' + R.label + '</b><span>' + R.blurb + '</span></span></button>';
  }).join('');
  const pinCard = S.loginRole ? (
    '<div class="card pincard"><label class="f"><span>Your name</span><select id="lg-user" data-change="login-user">' +
    (users.length ? users.map(u => '<option value="' + esc(u.id) + '" ' + (u.id === S.loginUser ? 'selected' : '') + '>' + esc(u.name) + '</option>').join('') : '<option value="">No active accounts for this role</option>') +
    '</select></label>' +
    '<div class="pin-dots" id="pin-dots" role="img" aria-label="PIN entry, ' + S.pin.length + ' digits entered">' + dots() + '</div>' +
    '<div class="keypad">' + [1, 2, 3, 4, 5, 6, 7, 8, 9].map(k => '<button class="key" data-act="pin-key" data-v="' + k + '">' + k + '</button>').join('') +
    '<button class="key ghost" data-act="pin-clear">Clear</button><button class="key" data-act="pin-key" data-v="0">0</button>' +
    '<button class="key ghost" data-act="pin-del" aria-label="Delete last digit">' + ic('backspace', 22) + '</button></div>' +
    '<button class="btn primary big" id="lg-go" data-act="login" ' + (S.pin.length < 4 || S.busy ? 'disabled' : '') + '>Sign in as ' + ROLES[S.loginRole].label + '</button></div>'
  ) : '';
  return '<div class="login' + (intro ? ' intro' : '') + '"><section class="lhero patterned"><div class="lhero-in">' +
    '<div class="wm-card"><div class="wm">FFC</div><p>' + esc(S.bizName || 'Eatery') + ' point of sale</p></div>' +
    '<div class="stickers" aria-hidden="true">' + STICKERS.map((s, i) => '<span class="stk" style="' + hueVars(s[1]) + ';--i:' + i + '">' + s[0] + '</span>').join('') + '</div></div></section>' +
    '<section class="lp"><h1>Sign in</h1><p class="muted">Pick your role, then enter your PIN.</p><div class="tickets">' + tickets + '</div>' + pinCard + '</section></div>';
}

function updatePin() {
  const d = $('#pin-dots'); if (d) { d.innerHTML = dots(); d.setAttribute('aria-label', 'PIN entry, ' + S.pin.length + ' digits entered'); }
  const b = $('#lg-go'); if (b) b.disabled = S.pin.length < 4 || S.busy;
}
function shake() { const d = $('#pin-dots'); if (!d) return; d.classList.remove('shake'); void d.offsetWidth; d.classList.add('shake'); }

export async function doLogin() {
  if (S.busy || S.pin.length < 4 || !S.loginUser) return;
  S.busy = true; updatePin();
  try {
    const r = await api('POST', '/api/login', { userId: S.loginUser, pin: S.pin });
    setToken(r.token); S.pin = ''; S.busy = false;
    await hooks.startSession();
  } catch (e) { S.busy = false; S.pin = ''; updatePin(); shake(); toast(e.message, 'err'); }
}

export function pinKey(k) {
  if (!S.loginRole || S.busy) return;
  if (k === 'del') S.pin = S.pin.slice(0, -1); else if (k === 'clear') S.pin = ''; else if (S.pin.length < 6) S.pin += k;
  updatePin();
}

actions['pick-role'] = el => { S.loginRole = el.dataset.v; S.pin = ''; hooks.render(); };
actions['login-user'] = el => { S.loginUser = el.value; S.pin = ''; updatePin(); };
actions['pin-key'] = el => pinKey(el.dataset.v);
actions['pin-del'] = () => pinKey('del');
actions['pin-clear'] = () => pinKey('clear');
actions.login = () => doLogin();
