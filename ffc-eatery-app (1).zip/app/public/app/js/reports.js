/* Reports: any day, week or month, compared with the one before */
import { S, D, actions, loaders, hooks, branchName, itemById, hueOf, hueVars, visibleBranchIds, isMulti } from './state.js';
import { esc, ic, money, fmt, today, addDays, weekStart, monthRange, dlabel, mlabel, parseYmd, ymd } from './util.js';
import { api, download } from './api.js';
import { pageHead, seg, stat, empty, run, dayBars, hourBars, rankList, donut, branchOptions } from './ui.js';

function periods() {
  const a = S.rep.anchor || today(), m = S.rep.mode;
  if (m === 'day') return { cur: [a, a], prev: [addDays(a, -1), addDays(a, -1)], label: dlabel(a), vs: 'the day before' };
  if (m === 'week') { const w = weekStart(a); return { cur: [w, addDays(w, 6)], prev: [addDays(w, -7), addDays(w, -1)], label: dlabel(w) + ' to ' + dlabel(addDays(w, 6)), vs: 'the week before' }; }
  const cur = monthRange(a), pm = monthRange(addDays(cur[0], -1));
  return { cur, prev: pm, label: mlabel(a), vs: 'the month before' };
}

loaders.reports = async () => {
  const p = periods(), b = S.rep.branch !== 'all' ? '&branch=' + encodeURIComponent(S.rep.branch) : '';
  D.reports = await api('GET', '/api/report?from=' + p.cur[0] + '&to=' + p.cur[1] + '&pfrom=' + p.prev[0] + '&pto=' + p.prev[1] + b);
};

const delta = (cur, prev, goodUp, vs) => {
  if (prev == null) return '';
  if (prev === 0) return cur === 0 ? '' : '<span class="dl">New this period</span>';
  const pc = Math.round((cur - prev) / Math.abs(prev) * 100); if (pc === 0) return '<span class="dl">Same as ' + vs + '</span>';
  return '<span class="dl ' + ((pc > 0) === goodUp ? 'good' : 'badd') + '">' + (pc > 0 ? '▲' : '▼') + ' ' + Math.abs(pc) + '% vs ' + vs + '</span>';
};

export function reportsView() {
  const R = D.reports, c = R.cur, pv = R.prev, p = periods(), bs = visibleBranchIds(), nextOff = p.cur[1] >= today();
  const cats = c.byCategory.map(x => [x.name, x.revenue, hueOf(x.name)]);
  const pay = [['Cash', c.sales.cash, 4], ['Transfer', c.sales.transfer, 5], ['Card', c.sales.card, 7]];
  const types = { 'dine-in': 'Dine in', takeaway: 'Takeaway', delivery: 'Delivery' };
  return pageHead('Reports', esc(p.label) + (S.rep.branch !== 'all' ? ' · ' + esc(branchName(S.rep.branch)) : bs.length > 1 ? ' · All branches' : ''),
      '<button class="btn no-print" data-act="rep-print">' + ic('print', 18) + 'Print</button>') +
    '<div class="datebar no-print"><button class="ib" data-act="rep-prev" aria-label="Earlier period">' + ic('left', 18) + '</button><div class="dlabel">' + esc(p.label) + '</div><button class="ib" data-act="rep-next" aria-label="Later period"' + (nextOff ? ' disabled' : '') + '>' + ic('right', 18) + '</button>' +
    (nextOff ? '' : '<button class="btn sm" data-act="rep-now">Now</button>') + '</div>' +
    '<div class="filters no-print">' + seg([['day', 'Day'], ['week', 'Week'], ['month', 'Month']], S.rep.mode, 'rep-mode', 'Period length') +
    (bs.length > 1 ? '<label class="f inl"><span>Branch</span><select data-change="rep-branch">' + branchOptions(S.rep.branch, null, true) + '</select></label>' : '') + '</div>' +
    '<div class="stats">' + stat('Sales', c.sales.total, { hue: 4, sub: delta(c.sales.total, pv && pv.sales.total, true, p.vs) }) +
      stat('Expenses', c.expenses.total, { hue: 1, sub: delta(c.expenses.total, pv && pv.expenses.total, false, p.vs) }) +
      stat('Net', c.net, { hue: c.net < 0 ? 1 : 5, sub: delta(c.net, pv && pv.net, true, p.vs) }) +
      stat('Orders', c.sales.count, { plain: true, hue: 2, sub: delta(c.sales.count, pv && pv.sales.count, true, p.vs) }) +
      stat('Average order', c.sales.avg, { hue: 6 }) + stat('Discounts given', c.sales.discount, { hue: 3 }) + stat('VAT collected', c.sales.vat, { hue: 7 }) +
      stat('Voided sales', c.voided.count, { plain: true, hue: 1, sub: c.voided.count ? money(c.voided.total) + ' removed' : 'None' }) + '</div>' +
    '<section class="card"><h2>Sales and expenses by day</h2>' + dayBars(c.byDay) + '</section>' +
    '<div class="two"><section class="card"><h2>How customers paid</h2>' + donut(pay, money(c.sales.total)) + '</section><section class="card"><h2>What sold, by category</h2>' + donut(cats, '') + '</section></div>' +
    '<div class="two"><section class="card"><h2>Top dishes</h2>' + rankList(c.topItems, r => r.qty, r => r.name, r => r.qty + ' sold · ' + money(r.revenue), r => { const it = itemById(r.itemId); return it ? hueOf(it.category) : 1; }) + '</section>' +
      '<section class="card"><h2>Busy hours</h2>' + hourBars(c.byHour) + '</section></div>' +
    '<div class="two"><section class="card"><h2>Staff sales</h2>' + rankList(c.byStaff, r => r.total, r => r.name, r => r.count + ' orders · ' + money(r.total)) + '</section>' +
      '<section class="card"><h2>Order types</h2>' + rankList(c.byType, r => r.total, r => types[r.type] || r.type, r => r.count + ' orders · ' + money(r.total)) + '</section></div>' +
    (c.byBranch.length > 1 ? '<section class="card"><h2>Branches</h2>' + rankList(c.byBranch, r => r.sales, r => branchName(r.branch), r => money(r.sales) + ' · spent ' + money(r.expenses)) + '</section>' : '') +
    '<div class="two"><section class="card"><h2>Spending by category</h2>' + rankList(c.expByCat, r => r.total, r => r.name, r => money(r.total), (r, i) => (i + 2) % 7 + 1) + '</section>' +
      '<section class="card"><h2>Wastage</h2>' + (c.wastage.qty ? '<p class="muted">' + fmt(c.wastage.qty) + ' unit' + (c.wastage.qty === 1 ? '' : 's') + ' thrown away, spoiled or eaten by staff.</p>' + rankList(c.wastage.items, r => r.qty, r => r.name, r => r.qty + ' units', () => 1) : '<p class="muted">No wastage recorded in this period.</p>') + '</section></div>' +
    '<section class="card no-print"><h2>Download for a spreadsheet</h2><p class="muted">Covers ' + esc(p.label) + '.</p><div class="btnrow">' +
      '<button class="btn" data-act="rep-export" data-v="sales">' + ic('download', 18) + 'Sales</button><button class="btn" data-act="rep-export" data-v="items">' + ic('download', 18) + 'Items sold</button><button class="btn" data-act="rep-export" data-v="expenses">' + ic('download', 18) + 'Expenses</button></div></section>';
}

const shift = dir => {
  const a = S.rep.anchor || today(), m = S.rep.mode;
  if (m === 'day') S.rep.anchor = addDays(a, dir); else if (m === 'week') S.rep.anchor = addDays(weekStart(a), dir * 7);
  else { const r = monthRange(a); S.rep.anchor = dir < 0 ? addDays(r[0], -1) : addDays(r[1], 1); }
  if (S.rep.anchor > today()) S.rep.anchor = today();
  hooks.reload();
};
actions['rep-prev'] = () => shift(-1);
actions['rep-next'] = () => shift(1);
actions['rep-now'] = () => { S.rep.anchor = today(); hooks.reload(); };
actions['rep-mode'] = el => { S.rep.mode = el.dataset.v; hooks.reload(); };
actions['rep-branch'] = el => { S.rep.branch = el.value; hooks.reload(); };
actions['rep-print'] = () => window.print();
actions['rep-export'] = el => run(null, async () => {
  const p = periods(), k = el.dataset.v, b = S.rep.branch !== 'all' ? '&branch=' + encodeURIComponent(S.rep.branch) : '';
  await download('/api/export/' + k + '?from=' + p.cur[0] + '&to=' + p.cur[1] + b, 'ffc-' + k + '-' + p.cur[0] + '-to-' + p.cur[1] + '.csv');
}, { ok: 'Download started.' });
