/* Small helpers shared by every screen */
export const $ = (s, r) => (r || document).querySelector(s);
export const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
export const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const pad = n => String(n).padStart(2, '0');
export const num = v => { const n = parseFloat(String(v == null ? '' : v).replace(/,/g, '')); return isFinite(n) ? n : 0; };
export const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
export const fmt = n => Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 });
export const clone = o => JSON.parse(JSON.stringify(o));
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const reduceMotion = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

let CUR = '', TZ = 'UTC';
export const setLocale = (cur, tz) => { CUR = cur || ''; TZ = tz || 'UTC'; };
export const money = n => { n = Number(n || 0); return n < 0 ? '-' + CUR + fmt(-n) : CUR + fmt(n); };
export const compact = n => { n = Math.abs(n); return n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, '') + 'k' : String(Math.round(n)); };

/* dates are plain YYYY-MM-DD strings in the business time zone */
export const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
export const parseYmd = s => { const p = s.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); };
export const addDays = (s, n) => { const d = parseYmd(s); d.setDate(d.getDate() + n); return ymd(d); };
export const weekStart = s => { const d = parseYmd(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return ymd(d); };
export const monthRange = s => { const p = s.split('-').map(Number); return [p[0] + '-' + pad(p[1]) + '-01', p[0] + '-' + pad(p[1]) + '-' + pad(new Date(p[0], p[1], 0).getDate())]; };
export const today = () => { try { return new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()); } catch (e) { return ymd(new Date()); } };
export const tm = iso => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', timeZone: TZ });
export const dt = iso => new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short', timeZone: TZ }) + ', ' + tm(iso);
export const dlabel = s => parseYmd(s).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
export const mlabel = s => parseYmd(s.slice(0, 7) + '-01').toLocaleDateString([], { month: 'long', year: 'numeric' });
export const hourLabel = h => (h % 12 || 12) + (h < 12 ? 'am' : 'pm');

export const LS = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } }
};

/* order totals: kept identical to the server, which has the final say */
export function calcTotals(subtotal, d, b) {
  let disc = 0;
  if (d && d.value > 0) disc = d.type === 'pct' ? r2(subtotal * Math.min(d.value, 100) / 100) : Math.min(r2(d.value), subtotal);
  const taxable = r2(subtotal - disc), rate = Number(b.vatRate) || 0;
  let vat = 0, total = taxable;
  if (rate > 0) { if (b.vatInclusive) vat = r2(taxable - taxable / (1 + rate / 100)); else { vat = r2(taxable * rate / 100); total = r2(taxable + vat); } }
  return { subtotal: r2(subtotal), discount: disc, vat, total };
}

/* icons: 24px stroke set */
const IC = {
  sell: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.4a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 7H6"/>',
  receipt: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6"/>',
  box: '<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
  swap: '<path d="M4 8h15l-4-4"/><path d="M20 16H5l4 4"/>',
  wallet: '<path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l12-4v4"/><circle cx="16.5" cy="13.5" r="1"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  grid: '<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',
  sliders: '<path d="M4 6h8M18 6h2M4 12h2M12 12h8M4 18h10M20 18h0"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  truck: '<path d="M2 6h11v10H2z"/><path d="M13 9h5l3 3v4h-8"/><circle cx="6.5" cy="17.5" r="1.6"/><circle cx="17.5" cy="17.5" r="1.6"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  print: '<path d="M7 9V3h10v6M6 17H4v-6h16v6h-2M7 14h10v7H7z"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
  pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  backspace: '<path d="M9 5h11v14H9L3 12z"/><path d="M12 9l5 6M17 9l-5 6"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  card: '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M7 15h4"/>',
  cash: '<rect x="3" y="7" width="18" height="11" rx="2"/><circle cx="12" cy="12.5" r="2.5"/>',
  bank: '<path d="M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/>',
  left: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  right: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'
};
export const ic = (n, s) => '<svg viewBox="0 0 24 24" width="' + (s || 20) + '" height="' + (s || 20) + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || '') + '</svg>';

/* feedback */
let toastTimer = null;
export function toast(msg, kind) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.className = 'toast ' + (kind || ''); t.hidden = false;
  t.style.animation = 'none'; void t.offsetWidth; t.style.animation = '';
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, kind === 'err' ? 5200 : 3200);
}

export function countUp(root) {
  if (reduceMotion()) return;
  $$('[data-count]', root).forEach(el => {
    const to = Number(el.dataset.count); if (!isFinite(to) || to === 0) return;
    const asMoney = el.dataset.money != null, t0 = performance.now(), dur = 750;
    const step = t => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3), v = to * e;
      el.textContent = p < 1 ? (asMoney ? money(v) : fmt(Math.round(v))) : (asMoney ? money(to) : fmt(to));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

export function confetti() {
  if (reduceMotion()) return;
  const c = $('#fx'); if (!c) return;
  const dpr = window.devicePixelRatio || 1, W = c.width = innerWidth * dpr, H = c.height = innerHeight * dpr, ctx = c.getContext('2d');
  c.style.display = 'block';
  const cols = ['#C8102E', '#F26A1B', '#F2B705', '#14915B', '#1B6CA8', '#B0246F', '#FFFFFF'];
  const ps = Array.from({ length: 120 }, () => ({
    x: W / 2 + (Math.random() - .5) * W * .25, y: H * .3, vx: (Math.random() - .5) * 15 * dpr, vy: (-Math.random() * 15 - 5) * dpr,
    s: (5 + Math.random() * 6) * dpr, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[(Math.random() * cols.length) | 0], dot: Math.random() < .4
  }));
  const start = performance.now(); let last = start;
  (function step(t) {
    const k = Math.min(32, t - last) / 16; last = t; ctx.clearRect(0, 0, W, H); let alive = 0;
    for (const p of ps) {
      p.vy += .42 * dpr * k; p.x += p.vx * k; p.y += p.vy * k; p.vx *= .992; p.r += p.vr * k;
      if (p.y < H + 30) alive++;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c;
      if (p.dot) { ctx.beginPath(); ctx.arc(0, 0, p.s / 2, 0, 7); ctx.fill(); } else ctx.fillRect(-p.s / 2, -p.s / 3, p.s, p.s * .6);
      ctx.restore();
    }
    if (alive && t - start < 2800) requestAnimationFrame(step); else { ctx.clearRect(0, 0, W, H); c.style.display = 'none'; }
  })(start);
}
