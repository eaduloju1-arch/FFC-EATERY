/* Shifts: cash drawer open and close, and the shift history for supervisors and the GM */
import { S, D, F, fv, actions, loaders, modalViews, hooks, biz, branchName, isMulti, visibleBranchIds } from './state.js';
import { $, esc, ic, money, num, r2, tm, dt, today, addDays, dlabel } from './util.js';
import { api } from './api.js';
import { pageHead, sheetHead, field, pill, stat, empty, run, branchOptions } from './ui.js';

const canSell = () => S.user.role === 'sales' || S.user.role === 'supervisor';
const varianceChip = v => v === 0 ? pill('Balanced', 'ok') : v > 0 ? pill('Over by ' + money(v), 'warn') : pill('Short by ' + money(-v), 'bad');

loaders.shifts = async () => {
  const q = '?from=' + S.shiftFrom + '&to=' + S.shiftTo + (S.shiftBranch !== 'all' ? '&branch=' + encodeURIComponent(S.shiftBranch) : '');
  const jobs = [api('GET', '/api/shifts' + q)];
  if (canSell()) jobs.push(api('GET', '/api/shifts/current'));
  const r = await Promise.all(jobs);
  D.shifts = { shifts: r[0].shifts }; if (r[1]) D.myShift = r[1].shift;
};

/* the strip at the top of Sell (and Shifts for supervisors) */
export function shiftBar() {
  if (!canSell()) return '';
  const sh = D.myShift;
  if (sh) return '<div class="shiftbar on"><span class="dotlive" aria-hidden="true"></span><div><b>Your shift is open</b><small>Since ' + tm(sh.openedAt) + ' · Opening cash ' + money(sh.float) + ' · ' + sh.count + ' sale' + (sh.count === 1 ? '' : 's') + ' · ' + money(sh.totalSales) + '</small></div>' +
    '<button class="btn sm" data-act="shift-close">Close shift</button></div>';
  const need = biz().requireShift;
  return '<div class="shiftbar' + (need ? ' need' : '') + '"><div><b>No shift open</b><small>' + (need ? 'Open your shift to start selling.' : 'Open a shift to keep track of the cash in your drawer.') + '</small></div>' +
    '<button class="btn primary sm" data-act="shift-open">' + ic('clock', 16) + 'Open shift</button></div>';
}

function shiftCard(s) {
  const open = !s.closedAt;
  return '<article class="card shift' + (open ? ' live' : '') + '"><div class="sc-h"><div><b>' + esc(s.byName) + '</b><small>' + (isMulti() ? esc(branchName(s.branch)) + ' · ' : '') + dlabel(s.date) + ' · ' + tm(s.openedAt) + (open ? '' : ' to ' + tm(s.closedAt)) + '</small></div>' +
    (open ? pill('<i class="dotlive"></i>Open now', 'ok') : varianceChip(s.variance || 0)) + '</div>' +
    '<dl class="kv"><div><dt>Opening cash</dt><dd>' + money(s.float) + '</dd></div><div><dt>Cash sales</dt><dd>' + money(s.cashSales) + '</dd></div><div><dt>All sales</dt><dd>' + money(s.totalSales) + ' <small>(' + s.count + ')</small></dd></div>' +
    '<div><dt>Should be in drawer</dt><dd>' + money(s.expected) + '</dd></div>' + (open ? '' : '<div><dt>Counted</dt><dd>' + money(s.counted) + '</dd></div>') + '</dl>' +
    (s.closeNote ? '<p class="muted small">Note: ' + esc(s.closeNote) + '</p>' : '') + '</article>';
}

export function shiftsView() {
  const list = D.shifts.shifts, closed = list.filter(s => s.closedAt), sales = list.reduce((a, s) => a + s.totalSales, 0), varSum = r2(closed.reduce((a, s) => a + (s.variance || 0), 0));
  const bs = visibleBranchIds();
  return pageHead('Shifts', 'Cash drawers, opening and closing counts.') + shiftBar() +
    '<div class="filters"><label class="f inl"><span>From</span><input type="date" data-change="shift-from" value="' + esc(S.shiftFrom) + '" max="' + esc(today()) + '"></label>' +
    '<label class="f inl"><span>To</span><input type="date" data-change="shift-to" value="' + esc(S.shiftTo) + '" max="' + esc(today()) + '"></label>' +
    (bs.length > 1 ? '<label class="f inl"><span>Branch</span><select data-change="shift-branch">' + branchOptions(S.shiftBranch, null, true) + '</select></label>' : '') +
    '<button class="btn sm" data-act="shift-today">Today</button></div>' +
    '<div class="stats">' + stat('Shifts', list.length, { plain: true, hue: 5 }) + stat('Sales in these shifts', sales, { hue: 4 }) +
    stat('Drawer difference', varSum === 0 ? money(0) : (varSum > 0 ? '+' : '') + money(varSum), { hue: varSum < 0 ? 1 : varSum > 0 ? 3 : 4, sub: closed.length ? 'across ' + closed.length + ' closed shift' + (closed.length === 1 ? '' : 's') : 'No closed shifts yet' }) + '</div>' +
    (list.length ? '<div class="cards">' + list.map(shiftCard).join('') + '</div>' : empty('🕒', 'No shifts in this period', 'Try a wider date range.'));
}

actions['shift-from'] = el => { S.shiftFrom = el.value || today(); if (S.shiftTo < S.shiftFrom) S.shiftTo = S.shiftFrom; hooks.reload(); };
actions['shift-to'] = el => { S.shiftTo = el.value || today(); if (S.shiftTo < S.shiftFrom) S.shiftFrom = S.shiftTo; hooks.reload(); };
actions['shift-branch'] = el => { S.shiftBranch = el.value; hooks.reload(); };
actions['shift-today'] = () => { S.shiftFrom = today(); S.shiftTo = today(); hooks.reload(); };

/* ---------- open and close ---------- */
modalViews['shift-open'] = () => sheetHead('Open your shift', 'Count the cash in your drawer before the first sale.') +
  '<div class="sh-body">' + field('Opening cash', '<input inputmode="decimal" data-autofocus data-f="m.float" data-enter="shift-do-open" placeholder="0" value="' + esc(fv('m.float')) + '" autocomplete="off">', 'Enter 0 if the drawer starts empty.') + '</div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="shift-do-open">Open shift</button></div>';

actions['shift-open'] = () => hooks.openModal({ type: 'shift-open', cls: 'low' });
actions['shift-do-open'] = el => {
  const v = fv('m.float');
  return run(el, async () => {
    if (v === '' || !(num(v) >= 0)) throw new Error('Enter the opening cash. Use 0 if the drawer is empty.');
    await api('POST', '/api/shifts/open', { float: num(v) }); hooks.closeModal(); await hooks.reload();
  }, { ok: 'Shift opened. Happy selling!' });
};

modalViews['shift-close'] = () => {
  const sh = D.myShift; if (!sh) return sheetHead('Close shift') + '<div class="sh-body"><p>You have no open shift.</p></div>';
  return sheetHead('Close your shift', 'Count every note and coin in the drawer.') + '<div class="sh-body">' +
    '<dl class="kv"><div><dt>Opened</dt><dd>' + tm(sh.openedAt) + '</dd></div><div><dt>Opening cash</dt><dd>' + money(sh.float) + '</dd></div><div><dt>Sales taken</dt><dd>' + sh.count + ' · ' + money(sh.totalSales) + '</dd></div></dl>' +
    field('Cash counted in the drawer', '<input inputmode="decimal" data-autofocus data-f="m.counted" placeholder="0" value="' + esc(fv('m.counted')) + '" autocomplete="off">') +
    field('Note (optional)', '<input maxlength="140" data-f="m.cnote" data-enter="shift-do-close" value="' + esc(fv('m.cnote')) + '" autocomplete="off">') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="shift-do-close">Close shift</button></div>';
};
actions['shift-close'] = () => hooks.openModal({ type: 'shift-close', cls: 'low' });
actions['shift-do-close'] = el => {
  const v = fv('m.counted'), note = fv('m.cnote');
  return run(el, async () => {
    if (v === '' || !(num(v) >= 0)) throw new Error('Enter the cash you counted.');
    const r = await api('POST', '/api/shifts/close', { counted: num(v), note });
    D.myShift = null; hooks.openModal({ type: 'shift-result', shift: r.shift, cls: 'low' }); await hooks.reload();
  });
};
modalViews['shift-result'] = m => {
  const s = m.shift, v = s.variance || 0;
  return sheetHead('Shift closed', 'Thank you, ' + esc(s.byName.split(' ')[0]) + '.') + '<div class="sh-body"><div class="verdict ' + (v === 0 ? 'ok' : v > 0 ? 'warn' : 'bad') + '"><span>' + (v === 0 ? 'Your drawer balances' : v > 0 ? 'Drawer is over by' : 'Drawer is short by') + '</span><b>' + (v === 0 ? '✓' : money(Math.abs(v))) + '</b></div>' +
    '<dl class="kv"><div><dt>Opening cash</dt><dd>' + money(s.float) + '</dd></div><div><dt>Cash sales</dt><dd>' + money(s.cashSales) + '</dd></div><div><dt>Should be in drawer</dt><dd>' + money(s.expected) + '</dd></div><div><dt>You counted</dt><dd>' + money(s.counted) + '</dd></div></dl></div>' +
    '<div class="sh-foot"><button class="btn primary" data-act="close">Done</button></div>';
};
