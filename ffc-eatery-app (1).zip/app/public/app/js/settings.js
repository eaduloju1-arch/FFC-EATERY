/* Settings (General Manager): menu, staff, branches, business details, activity log, backup */
import { S, D, F, fv, ROLES, ROLE_ORDER, actions, loaders, modalViews, hooks, biz, branches, branchName, buildHues, hueOf, hueVars, roleLabel } from './state.js';
import { $, esc, ic, money, num, dt, setLocale } from './util.js';
import { api, download } from './api.js';
import { pageHead, sheetHead, seg, field, pill, empty, run, branchOptions } from './ui.js';

const SECTIONS = [['menu', 'Menu'], ['staff', 'Staff'], ['branches', 'Branches'], ['business', 'Business'], ['audit', 'Activity'], ['data', 'Backup']];
const EMOJIS = ['🍛', '🍚', '🍗', '🥩', '🥘', '🍲', '🥧', '🌯', '🍟', '🍔', '🥗', '🍳', '🍩', '🍰', '🥟', '🍹', '🥤', '💧', '☕', '🍽️'];
const ZONES = ['Africa/Lagos', 'Africa/Accra', 'Africa/Nairobi', 'Africa/Johannesburg', 'Africa/Cairo', 'Europe/London', 'America/New_York', 'Asia/Dubai', 'UTC'];
let auditTimer = null;

loaders.settings = async () => {
  const jobs = [api('GET', '/api/admin/users')];
  if (S.sett === 'audit') jobs.push(api('GET', '/api/admin/audit?days=30&q=' + encodeURIComponent(S.auditQ.trim())));
  const r = await Promise.all(jobs);
  D.settings = { users: r[0].users, audit: r[1] ? r[1].audit : (D.settings && D.settings.audit) || [] };
};

/* ---------- sections ---------- */
function menuSec() {
  const items = S.config.items, cats = []; items.forEach(i => { if (!cats.includes(i.category)) cats.push(i.category); });
  return '<div class="ch"><p class="muted">Prices and dishes here show on the till, receipts and your website.</p><button class="btn primary" data-act="item-add">' + ic('plus', 18) + 'Add dish</button></div>' +
    (cats.length ? cats.map(c => '<section class="card" style="' + hueVars(hueOf(c)) + '"><h2 class="cat-h">' + esc(c) + '</h2><ul class="plain">' + items.filter(i => i.category === c).map(i =>
      '<li class="lowrow' + (i.active === false ? ' off' : '') + '"><span class="ce" aria-hidden="true">' + esc(i.emoji || '🍽️') + '</span><div><b>' + esc(i.name) + '</b><small>' + money(i.price) + ' per ' + esc(i.unit || 'piece') + ' · reorder at ' + (i.reorder == null ? 5 : i.reorder) + '</small></div>' +
      '<button class="switch' + (i.active === false ? '' : ' on') + '" role="switch" aria-checked="' + (i.active !== false) + '" aria-label="Show ' + esc(i.name) + ' on the menu" data-act="item-toggle" data-id="' + esc(i.id) + '"><i></i></button>' +
      '<button class="ib sm" data-act="item-edit" data-id="' + esc(i.id) + '" aria-label="Edit ' + esc(i.name) + '">' + ic('edit', 18) + '</button></li>').join('') + '</ul></section>').join('') : empty('🍽️', 'No dishes yet', 'Add your first dish.'));
}
function staffSec() {
  const us = D.settings.users;
  return '<div class="ch"><p class="muted">Each person signs in with their own PIN.</p><button class="btn primary" data-act="staff-add">' + ic('plus', 18) + 'Add staff</button></div>' +
    '<section class="card"><ul class="plain">' + us.map(u => {
      const R = ROLES[u.role], me = u.id === S.user.id;
      return '<li class="lowrow' + (u.active ? '' : ' off') + '" style="' + hueVars(R ? R.hue : 1) + '"><span class="av">' + esc(u.name.split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase()) + '</span><div><b>' + esc(u.name) + (me ? ' <small>(you)</small>' : '') + '</b><small>' + esc(roleLabel(u.role)) + (u.branch ? ' · ' + esc(branchName(u.branch)) : ' · All branches') + '</small></div>' +
        '<button class="switch' + (u.active ? ' on' : '') + '" role="switch" aria-checked="' + u.active + '" aria-label="' + esc(u.name) + ' can sign in"' + (me ? ' disabled' : '') + ' data-act="staff-toggle" data-id="' + esc(u.id) + '"><i></i></button>' +
        '<button class="ib sm" data-act="staff-edit" data-id="' + esc(u.id) + '" aria-label="Rename ' + esc(u.name) + '">' + ic('edit', 18) + '</button><button class="ib sm" data-act="staff-pin" data-id="' + esc(u.id) + '" aria-label="Reset PIN for ' + esc(u.name) + '">' + ic('lock', 18) + '</button></li>';
    }).join('') + '</ul></section>';
}
function branchSec() {
  return '<div class="ch"><p class="muted">Each branch keeps its own stock, staff and cash drawers.</p><button class="btn primary" data-act="branch-add">' + ic('plus', 18) + 'Add branch</button></div>' +
    '<section class="card"><ul class="plain">' + branches().map((b, i) => '<li class="lowrow" style="' + hueVars(i % 2 ? 5 : 2) + '"><span class="av">' + esc(b.code) + '</span><div><b>' + esc(b.name) + '</b><small>Receipt code ' + esc(b.code) + '</small></div><button class="ib sm" data-act="branch-edit" data-id="' + esc(b.id) + '" aria-label="Rename ' + esc(b.name) + '">' + ic('edit', 18) + '</button></li>').join('') + '</ul></section>';
}
function businessSec() {
  const b = biz(), chk = (k, on) => fv('biz.' + k, on) ? ' checked' : '';
  return '<section class="card"><h2>Business details</h2><div class="grid2">' +
    field('Business name', '<input data-f="biz.name" maxlength="60" value="' + esc(fv('biz.name', b.name)) + '">') + field('Currency symbol', '<input data-f="biz.currency" maxlength="4" value="' + esc(fv('biz.currency', b.currency)) + '">') +
    field('Time zone', '<input data-f="biz.timezone" list="zones" value="' + esc(fv('biz.timezone', b.timezone)) + '"><datalist id="zones">' + ZONES.map(z => '<option value="' + z + '">').join('') + '</datalist>', 'Decides when a business day starts and ends.') +
    field('VAT rate (%)', '<input inputmode="decimal" data-f="biz.vatRate" value="' + esc(fv('biz.vatRate', b.vatRate)) + '">', 'Use 0 if you do not charge VAT.') +
    field('Biggest discount a cashier can give (%)', '<input inputmode="decimal" data-f="biz.maxDiscountPct" value="' + esc(fv('biz.maxDiscountPct', b.maxDiscountPct)) + '">', 'Supervisors and the GM are not limited.') +
    field('Receipt footer', '<input data-f="biz.receiptFooter" maxlength="120" value="' + esc(fv('biz.receiptFooter', b.receiptFooter)) + '">') + '</div>' +
    '<label class="chk"><input type="checkbox" data-f="biz.vatInclusive"' + chk('vatInclusive', b.vatInclusive) + '><span>Menu prices already include VAT</span></label>' +
    '<label class="chk"><input type="checkbox" data-f="biz.requireShift"' + chk('requireShift', b.requireShift) + '><span>Cashiers must open a shift before they can sell</span></label>' +
    '<div class="btnrow"><button class="btn primary" data-act="biz-save">Save business details</button></div></section>';
}
function auditSec() {
  const list = D.settings.audit;
  return '<label class="search">' + ic('search', 18) + '<input id="audit-q" type="search" placeholder="Search activity by person or action" value="' + esc(S.auditQ) + '" data-input="audit-q" autocomplete="off" aria-label="Search activity"></label>' +
    '<section class="card" id="audit-l">' + auditList(list) + '</section>';
}
const auditList = list => list.length ? '<ul class="plain">' + list.map(a => '<li class="lowrow"><div><b>' + esc(a.byName) + ' <span class="act">' + esc(a.action) + '</span></b><small>' + esc(a.detail || '') + '</small></div><small class="when">' + esc(dt(a.at)) + '</small></li>').join('') + '</ul>' : '<p class="muted">Nothing found in the last 30 days.</p>';
function dataSec() {
  return '<section class="card"><h2>Back up your data</h2><p class="muted">Download everything: menu, staff, stock, sales, expenses and the activity log, in one file. Keep a copy somewhere safe every week.</p>' +
    '<div class="btnrow"><button class="btn primary" data-act="backup">' + ic('download', 18) + 'Download backup</button></div></section>' +
    '<section class="card"><h2>Your PIN</h2><p class="muted">Change your own PIN from your account menu at the top of the screen.</p><div class="btnrow"><button class="btn" data-act="account">Open account</button></div></section>';
}

export function settingsView() {
  const sec = { menu: menuSec, staff: staffSec, branches: branchSec, business: businessSec, audit: auditSec, data: dataSec }[S.sett] || menuSec;
  return pageHead('Settings', 'Set up your menu, people and business.') + seg(SECTIONS, S.sett, 'sett-tab', 'Settings sections') + '<div class="sett">' + sec() + '</div>';
}

actions['sett-tab'] = el => { S.sett = el.dataset.v; hooks.render(); hooks.reload(); };
actions['audit-q'] = el => { S.auditQ = el.value; clearTimeout(auditTimer); auditTimer = setTimeout(async () => { try { await loaders.settings(); const l = $('#audit-l'); if (l) l.innerHTML = auditList(D.settings.audit); } catch (e) { /* ignore */ } }, 300); };
actions.backup = el => run(el, async () => { await download('/api/admin/backup', 'ffc-backup.json'); }, { ok: 'Backup downloaded.' });

/* ---------- business ---------- */
actions['biz-save'] = el => run(el, async () => {
  const b = biz(), g = (k, d) => fv('biz.' + k, d);
  const r = await api('PATCH', '/api/admin/settings', { name: g('name', b.name), currency: g('currency', b.currency), timezone: g('timezone', b.timezone), vatRate: num(g('vatRate', b.vatRate)), vatInclusive: !!g('vatInclusive', b.vatInclusive), maxDiscountPct: num(g('maxDiscountPct', b.maxDiscountPct)), receiptFooter: g('receiptFooter', b.receiptFooter), requireShift: !!g('requireShift', b.requireShift) });
  S.config.business = r.business; setLocale(r.business.currency, r.business.timezone);
  Object.keys(F).forEach(k => { if (k.startsWith('biz.')) delete F[k]; }); hooks.render();
}, { ok: 'Business details saved.' });

/* ---------- menu items ---------- */
modalViews.item = m => {
  const cats = [...new Set(S.config.items.map(i => i.category))], em = fv('m.emoji');
  return sheetHead(m.id ? 'Edit dish' : 'Add a dish') + '<div class="sh-body scroll">' +
    '<div class="grid2">' + field('Name', '<input data-autofocus maxlength="60" data-f="m.name" value="' + esc(fv('m.name')) + '" autocomplete="off">') + field('Category', '<input list="cats" maxlength="30" data-f="m.cat" value="' + esc(fv('m.cat')) + '" autocomplete="off"><datalist id="cats">' + cats.map(c => '<option value="' + esc(c) + '">').join('') + '</datalist>') + '</div>' +
    '<div class="grid2">' + field('Price', '<input inputmode="decimal" data-f="m.price" value="' + esc(fv('m.price')) + '" autocomplete="off">') + field('Sold by', '<input maxlength="20" data-f="m.unit" placeholder="plate, piece, bottle" value="' + esc(fv('m.unit')) + '" autocomplete="off">') + '</div>' +
    field('Tell me when stock reaches', '<input inputmode="numeric" data-f="m.reorder" value="' + esc(fv('m.reorder')) + '" autocomplete="off">', 'Shown as running low at or below this number.') +
    '<div class="f"><span>Picture</span><div class="emojis">' + EMOJIS.map(e => '<button class="' + (e === em ? 'on' : '') + '" data-act="item-emoji" data-v="' + e + '" aria-label="Use ' + e + '" aria-pressed="' + (e === em) + '">' + e + '</button>').join('') + '</div></div>' +
    (m.id ? '<label class="chk"><input type="checkbox" data-f="m.active"' + (fv('m.active', true) ? ' checked' : '') + '><span>Show on the menu</span></label>' : '') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="item-save">Save dish</button></div>';
};
actions['item-add'] = () => hooks.openModal({ type: 'item', f: { 'm.cat': S.tab && S.config.items[0] ? S.config.items[0].category : 'Meals', 'm.unit': 'plate', 'm.reorder': '5', 'm.emoji': '🍛', 'm.active': true } });
actions['item-edit'] = el => {
  const i = S.config.items.find(x => x.id === el.dataset.id); if (!i) return;
  hooks.openModal({ type: 'item', id: i.id, f: { 'm.name': i.name, 'm.cat': i.category, 'm.price': String(i.price), 'm.unit': i.unit || '', 'm.reorder': String(i.reorder == null ? 5 : i.reorder), 'm.emoji': i.emoji || '', 'm.active': i.active !== false } });
};
actions['item-emoji'] = el => { F['m.emoji'] = el.dataset.v; hooks.renderModal(); };
function applyItem(it) { const k = S.config.items.findIndex(x => x.id === it.id); if (k >= 0) S.config.items[k] = it; else S.config.items.push(it); buildHues(); }
actions['item-save'] = el => run(el, async () => {
  const id = S.modal.id, body = { name: fv('m.name').trim(), category: fv('m.cat').trim(), price: num(fv('m.price')), unit: fv('m.unit').trim(), emoji: fv('m.emoji'), reorder: fv('m.reorder') === '' ? undefined : Math.floor(num(fv('m.reorder'))) };
  if (id) body.active = !!fv('m.active', true);
  const r = id ? await api('PATCH', '/api/admin/items/' + encodeURIComponent(id), body) : await api('POST', '/api/admin/items', body);
  applyItem(r.item); hooks.closeModal(); hooks.render();
}, { ok: 'Dish saved.' });
actions['item-toggle'] = el => run(null, async () => {
  const i = S.config.items.find(x => x.id === el.dataset.id), r = await api('PATCH', '/api/admin/items/' + encodeURIComponent(i.id), { active: i.active === false });
  applyItem(r.item); hooks.render();
});

/* ---------- staff ---------- */
modalViews.staff = m => {
  const role = fv('m.role', 'sales'), needsBranch = role === 'sales' || role === 'supervisor';
  return sheetHead(m.id ? 'Rename staff member' : 'Add staff') + '<div class="sh-body scroll">' + field('Full name', '<input data-autofocus maxlength="60" data-f="m.name" value="' + esc(fv('m.name')) + '" autocomplete="off">') +
    (m.id ? '' : '<div class="grid2">' + field('Role', '<select data-f="m.role" data-change="modal-refresh">' + ROLE_ORDER.map(r => '<option value="' + r + '"' + (r === role ? ' selected' : '') + '>' + esc(ROLES[r].label) + '</option>').join('') + '</select>') +
      (needsBranch ? field('Branch', '<select data-f="m.branch">' + branchOptions(fv('m.branch', branches()[0].id)) + '</select>') : '') + '</div>' +
      field('Starting PIN (4 to 6 digits)', '<input inputmode="numeric" maxlength="6" data-f="m.pin" value="' + esc(fv('m.pin')) + '" autocomplete="off">', 'Tell them to change it from their account menu.')) + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="staff-save">Save</button></div>';
};
actions['staff-add'] = () => hooks.openModal({ type: 'staff', f: { 'm.role': 'sales', 'm.branch': branches()[0].id } });
actions['staff-edit'] = el => { const u = D.settings.users.find(x => x.id === el.dataset.id); if (u) hooks.openModal({ type: 'staff', id: u.id, f: { 'm.name': u.name }, cls: 'low' }); };
actions['staff-save'] = el => run(el, async () => {
  const id = S.modal.id, name = fv('m.name').trim(); if (!name) throw new Error('Enter a name.');
  if (id) await api('PATCH', '/api/admin/users/' + encodeURIComponent(id), { name });
  else { const role = fv('m.role', 'sales'), pin = fv('m.pin'); if (!/^\d{4,6}$/.test(pin)) throw new Error('PIN must be 4 to 6 digits.'); await api('POST', '/api/admin/users', { name, role, pin, branch: (role === 'sales' || role === 'supervisor') ? fv('m.branch', branches()[0].id) : null }); }
  hooks.closeModal(); await hooks.reload();
}, { ok: 'Staff member saved.' });
actions['staff-toggle'] = el => run(null, async () => {
  const u = D.settings.users.find(x => x.id === el.dataset.id); await api('PATCH', '/api/admin/users/' + encodeURIComponent(u.id), { active: !u.active }); await hooks.reload();
}, { ok: 'Updated.' });
modalViews['staff-pin'] = m => sheetHead('Reset PIN', esc(m.name)) + '<div class="sh-body">' + field('New PIN (4 to 6 digits)', '<input inputmode="numeric" maxlength="6" data-autofocus data-f="m.pin" data-enter="staff-pin-save" value="' + esc(fv('m.pin')) + '" autocomplete="off">', 'They will be signed out of any device that is using the old PIN.') + '</div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="staff-pin-save">Set PIN</button></div>';
actions['staff-pin'] = el => { const u = D.settings.users.find(x => x.id === el.dataset.id); if (u) hooks.openModal({ type: 'staff-pin', id: u.id, name: u.name, cls: 'low' }); };
actions['staff-pin-save'] = el => run(el, async () => {
  const pin = fv('m.pin'); if (!/^\d{4,6}$/.test(pin)) throw new Error('PIN must be 4 to 6 digits.');
  await api('POST', '/api/admin/users/' + encodeURIComponent(S.modal.id) + '/pin', { pin }); hooks.closeModal();
}, { ok: 'PIN changed.' });

/* ---------- branches ---------- */
modalViews.branch = m => sheetHead(m.id ? 'Rename branch' : 'Add a branch') + '<div class="sh-body"><div class="grid2">' + field('Branch name', '<input data-autofocus maxlength="40" data-f="m.name" data-enter="branch-save" value="' + esc(fv('m.name')) + '" autocomplete="off">') +
  (m.id ? '' : field('Receipt code (2 to 3 letters)', '<input maxlength="3" data-f="m.code" data-enter="branch-save" value="' + esc(fv('m.code')) + '" autocomplete="off">')) + '</div></div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="branch-save">Save</button></div>';
actions['branch-add'] = () => hooks.openModal({ type: 'branch', cls: 'low' });
actions['branch-edit'] = el => { const b = branches().find(x => x.id === el.dataset.id); if (b) hooks.openModal({ type: 'branch', id: b.id, f: { 'm.name': b.name }, cls: 'low' }); };
actions['branch-save'] = el => run(el, async () => {
  const id = S.modal.id, name = fv('m.name').trim(); if (!name) throw new Error('Enter a branch name.');
  const r = id ? await api('PATCH', '/api/admin/branches/' + encodeURIComponent(id), { name }) : await api('POST', '/api/admin/branches', { name, code: fv('m.code').trim() });
  const k = S.config.branches.findIndex(x => x.id === r.branch.id); if (k >= 0) S.config.branches[k] = r.branch; else S.config.branches.push(r.branch);
  hooks.closeModal(); hooks.render();
}, { ok: 'Branch saved.' });
