/* Sell: tap dishes, build the order, take payment, hand over the receipt */
import { S, D, actions, loaders, modalViews, hooks, biz, itemById, itemName, activeItems, hueOf, hueVars } from './state.js';
import { $, esc, ic, money, num, r2, calcTotals, toast, confetti, LS, tm } from './util.js';
import { api } from './api.js';
import { sheetHead, catChips, run, empty, field } from './ui.js';
import { shiftBar } from './shifts.js';

const stockQ = id => (D.sell && D.sell.stock[id]) || 0;
const cartLines = () => Object.keys(S.cart).filter(id => itemById(id) && S.cart[id] > 0).map(id => ({ itemId: id, qty: S.cart[id] }));
const countItems = () => cartLines().reduce((a, l) => a + l.qty, 0);
const subtotal = () => cartLines().reduce((a, l) => a + itemById(l.itemId).price * l.qty, 0);
const discObj = () => S.disc.type === 'none' ? null : { type: S.disc.type, value: num(S.disc.value) };
const totals = () => calcTotals(subtotal(), discObj(), biz());
const freshPay = () => ({ method: 'cash', rest: 'transfer', tender: '', touched: false, cash: '', ref: '', seen: false });
const freshDisc = () => ({ type: 'none', value: '', reason: '' });
const heldKey = () => 'ffc:held:' + S.user.id;
const getHeld = () => LS.get(heldKey()) || [];

loaders.sell = async () => {
  const [st, sh] = await Promise.all([api('GET', '/api/stock'), api('GET', '/api/shifts/current')]);
  D.sell = { stock: st.stock[S.user.branch] || {} }; D.myShift = sh.shift;
  let cut = false;
  Object.keys(S.cart).forEach(id => { const have = stockQ(id); if (!itemById(id) || S.cart[id] > have) { cut = true; if (have > 0 && itemById(id)) S.cart[id] = have; else delete S.cart[id]; } });
  if (cut) toast('Some items in the order were reduced to what is in stock.', 'err');
};

/* ---------- pieces ---------- */
function tile(i) {
  const q = stockQ(i.id), n = S.cart[i.id] || 0, out = q <= 0, low = !out && q <= (i.reorder == null ? 5 : i.reorder), bump = S.lastAdded === i.id;
  return '<button class="tile' + (out ? ' out' : '') + (bump ? ' bump' : '') + '" style="' + hueVars(hueOf(i.category)) + '" data-act="add" data-id="' + esc(i.id) + '"' + (out ? ' disabled' : '') +
    ' aria-label="' + esc(i.name + ', ' + money(i.price) + (out ? ', sold out' : ', ' + q + ' left') + (n ? ', ' + n + ' in order' : '')) + '">' +
    (n ? '<em class="tq">' + n + '</em>' : '') + '<span class="te" aria-hidden="true">' + esc(i.emoji || '🍽️') + '</span><b>' + esc(i.name) + '</b><span class="tp">' + money(i.price) + '</span>' +
    '<small class="' + (out ? 'bad' : low ? 'warn' : '') + '">' + (out ? 'Sold out' : low ? 'Only ' + q + ' left' : q + ' left') + '</small></button>';
}
function tilesHtml() {
  const q = S.q.trim().toLowerCase(), list = activeItems().filter(i => (S.cat === 'All' || i.category === S.cat) && (!q || i.name.toLowerCase().includes(q)));
  S.lastAdded = null;
  return list.length ? list.map(tile).join('') : '<div class="tiles-empty">' + empty('🔎', 'Nothing matches', 'Try another word or category.') + '</div>';
}
function cartInner() {
  const ls = cartLines(), t = totals(), held = getHeld().length;
  const rows = ls.map(l => {
    const it = itemById(l.itemId);
    return '<li class="cl" style="' + hueVars(hueOf(it.category)) + '"><span class="ce" aria-hidden="true">' + esc(it.emoji || '🍽️') + '</span><div class="cn"><b>' + esc(it.name) + '</b><small>' + money(it.price) + ' each</small></div>' +
      '<div class="step"><button data-act="dec" data-id="' + esc(it.id) + '" aria-label="One less ' + esc(it.name) + '">−</button><b aria-live="polite">' + l.qty + '</b><button data-act="inc" data-id="' + esc(it.id) + '" aria-label="One more ' + esc(it.name) + '">+</button></div>' +
      '<span class="cp">' + money(it.price * l.qty) + '</span></li>';
  }).join('');
  return '<div class="cart-h"><h2>Current order</h2><div class="cart-tools">' +
    (held ? '<button class="btn sm" data-act="held-open">' + ic('pause', 16) + 'Held (' + held + ')</button>' : '') +
    (ls.length ? '<button class="ib sm" data-act="hold" aria-label="Put order on hold" title="Put on hold">' + ic('pause', 18) + '</button><button class="ib sm" data-act="clear-cart" aria-label="Clear order" title="Clear order">' + ic('trash', 18) + '</button>' : '') +
    '<button class="ib sm only-m" data-act="cart-close" aria-label="Close order">' + ic('x', 18) + '</button></div></div>' +
    (ls.length ? '<ul class="cls">' + rows + '</ul>' : empty('🍛', 'No items yet', 'Tap a dish to start an order.')) +
    '<div class="cart-f"><div class="tl"><span>Subtotal</span><span>' + money(t.subtotal) + '</span></div>' +
    (t.discount ? '<div class="tl"><span>Discount</span><span>-' + money(t.discount) + '</span></div>' : '') +
    (t.vat ? '<div class="tl"><span>VAT ' + biz().vatRate + '%' + (biz().vatInclusive ? ' (included)' : '') + '</span><span>' + money(t.vat) + '</span></div>' : '') +
    '<div class="tl big"><span>Total</span><span>' + money(t.total) + '</span></div>' +
    '<button class="btn primary big wide" data-act="checkout"' + (ls.length ? '' : ' disabled') + '>' + ic('cash', 20) + 'Charge ' + money(t.total) + '</button></div>';
}
const cartbarHtml = () => { const n = countItems(); return n ? ic('sell', 20) + '<b>' + n + ' item' + (n === 1 ? '' : 's') + '</b><span>' + money(totals().total) + '</span><i>View order</i>' : ''; };

export function sellView() {
  const cats = []; activeItems().forEach(i => { if (!cats.includes(i.category)) cats.push(i.category); });
  return '<div class="sell"><section class="menu">' + shiftBar() +
    '<div class="tools"><label class="search">' + ic('search', 18) + '<input id="sell-q" type="search" placeholder="Search the menu" value="' + esc(S.q) + '" data-input="sell-q" autocomplete="off" aria-label="Search the menu"></label></div>' +
    catChips(cats, S.cat, 'sell-cat') + '<div class="tiles" id="tiles">' + tilesHtml() + '</div></section>' +
    '<div class="cart-bg' + (S.pop === 'cart' ? ' open' : '') + '" id="cart-bg" data-act="cart-close"></div>' +
    '<aside class="cart' + (S.pop === 'cart' ? ' open' : '') + '" id="cart" aria-label="Current order">' + cartInner() + '</aside>' +
    '<button class="cartbar" id="cartbar" data-act="cart-open"' + (countItems() ? '' : ' hidden') + '>' + cartbarHtml() + '</button></div>';
}

function paint() {
  const t = $('#tiles'); if (t) t.innerHTML = tilesHtml();
  const c = $('#cart'); if (c) c.innerHTML = cartInner();
  const b = $('#cartbar'); if (b) { b.innerHTML = cartbarHtml(); b.hidden = !countItems(); }
  if (!countItems() && S.pop === 'cart') { S.pop = null; const w = $('#cart'), g = $('#cart-bg'); if (w) w.classList.remove('open'); if (g) g.classList.remove('open'); }
}
function resetSale() { S.cart = {}; S.order = { type: S.order.type, name: '', phone: '', note: '' }; S.disc = freshDisc(); S.pay = freshPay(); S.pop = null; }

/* ---------- actions ---------- */
actions['sell-q'] = el => { S.q = el.value; const t = $('#tiles'); if (t) t.innerHTML = tilesHtml(); };
actions['sell-cat'] = el => { S.cat = el.dataset.v; hooks.render(); };
actions.add = el => {
  const id = el.dataset.id, have = stockQ(id), cur = S.cart[id] || 0;
  if (cur >= have) { toast('Only ' + have + ' ' + itemName(id) + ' left.', 'err'); return; }
  S.cart[id] = cur + 1; S.lastAdded = id; paint();
};
actions.inc = el => { const id = el.dataset.id, have = stockQ(id); if ((S.cart[id] || 0) >= have) { toast('Only ' + have + ' ' + itemName(id) + ' left.', 'err'); return; } S.cart[id] = (S.cart[id] || 0) + 1; paint(); };
actions.dec = el => { const id = el.dataset.id; if ((S.cart[id] || 0) <= 1) delete S.cart[id]; else S.cart[id]--; paint(); };
actions['clear-cart'] = () => { resetSale(); paint(); };
actions['cart-open'] = () => { S.pop = 'cart'; $('#cart').classList.add('open'); $('#cart-bg').classList.add('open'); };
actions['cart-close'] = () => { S.pop = null; $('#cart').classList.remove('open'); $('#cart-bg').classList.remove('open'); };

actions.hold = () => {
  if (!cartLines().length) return;
  const h = getHeld(); h.unshift({ id: Date.now(), at: new Date().toISOString(), cart: S.cart, order: S.order, disc: S.disc }); LS.set(heldKey(), h.slice(0, 10));
  resetSale(); paint(); toast('Order put on hold.', 'ok');
};
modalViews.held = () => {
  const h = getHeld(), busy = cartLines().length > 0;
  return sheetHead('Held orders', 'Pick one up when the customer is ready.') + '<div class="sh-body scroll">' +
    (busy ? '<div class="note">Clear or hold the current order before resuming another.</div>' : '') +
    (h.length ? '<ul class="plain">' + h.map(o => {
      const ids = Object.keys(o.cart).filter(id => itemById(id)), n = ids.reduce((a, id) => a + o.cart[id], 0), tot = calcTotals(ids.reduce((a, id) => a + itemById(id).price * o.cart[id], 0), null, biz()).total;
      return '<li class="row"><div><b>' + n + ' item' + (n === 1 ? '' : 's') + ' · ' + money(tot) + '</b><small>' + esc(ids.slice(0, 3).map(itemName).join(', ')) + (ids.length > 3 ? '…' : '') + ' · held at ' + tm(o.at) + '</small></div>' +
        '<div class="row-a"><button class="btn sm" data-act="held-del" data-id="' + o.id + '" aria-label="Delete held order">' + ic('trash', 16) + '</button><button class="btn primary sm" data-act="held-resume" data-id="' + o.id + '"' + (busy ? ' disabled' : '') + '>Resume</button></div></li>';
    }).join('') + '</ul>' : empty('🕒', 'Nothing on hold')) + '</div>';
};
actions['held-open'] = () => hooks.openModal({ type: 'held', cls: 'low' });
actions['held-del'] = el => { LS.set(heldKey(), getHeld().filter(o => String(o.id) !== el.dataset.id)); if (!getHeld().length) hooks.closeModal(); else hooks.renderModal(); paint(); };
actions['held-resume'] = el => {
  const o = getHeld().find(x => String(x.id) === el.dataset.id); if (!o) return;
  const cart = {}; Object.keys(o.cart).forEach(id => { const q = Math.min(o.cart[id], stockQ(id)); if (itemById(id) && q > 0) cart[id] = q; });
  S.cart = cart; S.order = o.order; S.disc = o.disc || freshDisc();
  LS.set(heldKey(), getHeld().filter(x => x.id !== o.id)); hooks.closeModal(); paint();
  if (Object.keys(cart).length < Object.keys(o.cart).length) toast('Some items were reduced because stock is lower now.', 'err');
};

/* ---------- checkout ---------- */
actions.checkout = () => {
  if (!cartLines().length) return;
  if (biz().requireShift && !D.myShift) { toast('Open your shift before selling.', 'err'); hooks.openModal({ type: 'shift-open', cls: 'low', f: { 'm.float': '' } }); return; }
  S.pay = freshPay(); hooks.openModal({ type: 'checkout' });
};

function tenderOf(t) { return S.pay.tender === '' ? t.total : num(S.pay.tender); }
function problem(t) {
  const P = S.pay;
  if (S.user.role === 'sales' && subtotal() > 0 && (t.discount / subtotal()) * 100 > Number(biz().maxDiscountPct) + 0.001) return 'Discounts above ' + biz().maxDiscountPct + '% need a supervisor to sign in.';
  if (S.disc.type !== 'none' && num(S.disc.value) > 0 && !S.disc.reason.trim() && S.user.role === 'sales') return 'Add a short reason for the discount.';
  if (!(t.total > 0)) return 'The total must be above zero.';
  if (P.method === 'cash' && tenderOf(t) < t.total) return 'Cash received is less than the total.';
  if (P.method === 'split') { const c = num(P.cash); if (!(c > 0 && c < t.total)) return 'Enter the cash part: more than zero and less than the total.'; }
  return '';
}
const roundUps = total => {
  const out = [];
  [100, 500, 1000, 5000, 10000].forEach(step => { const v = Math.ceil(total / step) * step; if (v > total && !out.includes(v)) out.push(v); });
  return out.slice(0, 3);
};
const METHODS = [['cash', 'Cash', 'cash', 4], ['transfer', 'Transfer', 'bank', 5], ['card', 'Card', 'card', 7], ['split', 'Split', 'swap', 2]];

modalViews.checkout = () => {
  const t = totals(), P = S.pay, O = S.order, Ds = S.disc, err = problem(t), n = countItems();
  const typeBtns = [['dine-in', 'Dine in'], ['takeaway', 'Takeaway'], ['delivery', 'Delivery']].map(x => '<button class="' + (O.type === x[0] ? 'on' : '') + '" data-act="co-type" data-v="' + x[0] + '" aria-pressed="' + (O.type === x[0]) + '">' + x[1] + '</button>').join('');
  const discBtns = [['none', 'None'], ['pct', 'Percent'], ['amt', 'Amount']].map(x => '<button class="' + (Ds.type === x[0] ? 'on' : '') + '" data-act="co-disc" data-v="' + x[0] + '" aria-pressed="' + (Ds.type === x[0]) + '">' + x[1] + '</button>').join('');
  const meth = METHODS.map(m => '<button class="pm' + (P.method === m[0] ? ' on' : '') + '" style="' + hueVars(m[3]) + '" data-act="co-method" data-v="' + m[0] + '" aria-pressed="' + (P.method === m[0]) + '">' + ic(m[2], 24) + '<b>' + m[1] + '</b></button>').join('');
  let payBody = '';
  if (P.method === 'cash') {
    const td = tenderOf(t), ch = r2(td - t.total);
    payBody = field('Cash received', '<input inputmode="decimal" data-f="m.tender" data-input="co-tender-in" data-enter="co-confirm" placeholder="' + t.total + '" value="' + esc(P.tender) + '" autocomplete="off">') +
      '<div class="quick"><button data-act="co-tender" data-v="">Exact</button>' + roundUps(t.total).map(v => '<button data-act="co-tender" data-v="' + v + '">' + money(v) + '</button>').join('') + '</div>' +
      '<div class="chg ' + (ch < 0 ? 'bad' : 'ok') + '"><span>' + (ch < 0 ? 'Short by' : 'Change to give') + '</span><b>' + money(Math.abs(ch)) + '</b></div>';
  } else if (P.method === 'transfer') {
    payBody = '<p class="muted small">Confirm the money has arrived in the account before you continue.</p>' + field('Sender name or transfer reference (optional)', '<input data-f="m.ref" data-input="co-ref" maxlength="60" value="' + esc(P.ref) + '" autocomplete="off">');
  } else if (P.method === 'card') {
    payBody = '<p class="muted small">Take the card payment on your terminal, then confirm here.</p>' + field('Terminal approval code (optional)', '<input data-f="m.ref" data-input="co-ref" maxlength="60" value="' + esc(P.ref) + '" autocomplete="off">');
  } else {
    const c = num(P.cash), rest = r2(t.total - c);
    payBody = field('Cash part', '<input inputmode="decimal" data-f="m.cash" data-input="co-cash-in" placeholder="0" value="' + esc(P.cash) + '" autocomplete="off">') +
      '<div class="seg" role="group" aria-label="Pay the rest by"><button class="' + (P.rest === 'transfer' ? 'on' : '') + '" data-act="co-rest" data-v="transfer">Rest by transfer</button><button class="' + (P.rest === 'card' ? 'on' : '') + '" data-act="co-rest" data-v="card">Rest by card</button></div>' +
      '<div class="chg ' + (c > 0 && c < t.total ? 'ok' : 'bad') + '"><span>Remaining by ' + P.rest + '</span><b>' + money(c > 0 && c < t.total ? rest : 0) + '</b></div>' +
      field('Reference (optional)', '<input data-f="m.ref" data-input="co-ref" maxlength="60" value="' + esc(P.ref) + '" autocomplete="off">');
  }
  return sheetHead('Take payment', n + ' item' + (n === 1 ? '' : 's') + ' in this order') + '<div class="sh-body scroll">' +
    '<div class="co-total"><span>Total to pay</span><b>' + money(t.total) + '</b><small>' + (t.discount ? 'After ' + money(t.discount) + ' discount' : 'Subtotal ' + money(t.subtotal)) + (t.vat ? ' · VAT ' + money(t.vat) + (biz().vatInclusive ? ' included' : ' added') : '') + '</small></div>' +
    '<h3 class="sub">Order</h3><div class="seg" role="group" aria-label="Order type">' + typeBtns + '</div>' +
    '<div class="grid2">' + field(O.type === 'dine-in' ? 'Table (optional)' : 'Customer name (optional)', '<input data-f="m.name" data-input="co-name" maxlength="60" value="' + esc(O.name) + '" autocomplete="off">') +
    (O.type === 'delivery' ? field('Phone', '<input type="tel" data-f="m.phone" data-input="co-phone" maxlength="24" value="' + esc(O.phone) + '" autocomplete="off">') : field('Note (optional)', '<input data-f="m.note" data-input="co-note" maxlength="140" value="' + esc(O.note) + '" autocomplete="off">')) + '</div>' +
    (O.type === 'delivery' ? field('Note (optional)', '<input data-f="m.note2" data-input="co-note" maxlength="140" value="' + esc(O.note) + '" autocomplete="off">') : '') +
    '<h3 class="sub">Discount</h3><div class="seg" role="group" aria-label="Discount type">' + discBtns + '</div>' +
    (Ds.type !== 'none' ? '<div class="grid2">' + field(Ds.type === 'pct' ? 'Percent off' : 'Amount off', '<input inputmode="decimal" data-f="m.dv" data-input="co-dv" value="' + esc(Ds.value) + '" autocomplete="off">', S.user.role === 'sales' ? 'You can give up to ' + biz().maxDiscountPct + '%.' : '') +
      field('Reason', '<input data-f="m.dr" data-input="co-dr" maxlength="80" value="' + esc(Ds.reason) + '" autocomplete="off">') + '</div>' : '') +
    '<h3 class="sub">Payment</h3><div class="pms" role="group" aria-label="Payment method">' + meth + '</div><div class="paybody">' + payBody + '</div>' +
    (err ? '<div class="note bad" role="alert">' + esc(err) + '</div>' : '') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Back</button><button class="btn primary big" data-act="co-confirm"' + (err ? ' disabled' : '') + '>' + ic('check', 20) + 'Confirm ' + money(t.total) + '</button></div>';
};

const re = () => hooks.renderModal();
actions['co-type'] = el => { S.order.type = el.dataset.v; re(); };
actions['co-name'] = el => { S.order.name = el.value; };
actions['co-phone'] = el => { S.order.phone = el.value; };
actions['co-note'] = el => { S.order.note = el.value; };
actions['co-disc'] = el => { S.disc.type = el.dataset.v; if (el.dataset.v === 'none') { S.disc.value = ''; S.disc.reason = ''; } re(); };
actions['co-dv'] = el => { S.disc.value = el.value; re(); };
actions['co-dr'] = el => { S.disc.reason = el.value; re(); };
actions['co-method'] = el => { S.pay.method = el.dataset.v; re(); };
actions['co-rest'] = el => { S.pay.rest = el.dataset.v; re(); };
actions['co-tender'] = el => { S.pay.tender = el.dataset.v; re(); };
actions['co-tender-in'] = el => { S.pay.tender = el.value; re(); };
actions['co-cash-in'] = el => { S.pay.cash = el.value; re(); };
actions['co-ref'] = el => { S.pay.ref = el.value; };

actions['co-confirm'] = el => {
  const t = totals(); if (problem(t)) { re(); return; }
  const P = S.pay, O = S.order, dv = discObj();
  const payment = { method: P.method, ref: P.ref.trim() };
  if (P.method === 'cash') payment.tendered = tenderOf(t);
  if (P.method === 'split') { payment.cash = num(P.cash); payment.rest = P.rest; }
  const body = {
    lines: cartLines(), payment,
    order: { type: O.type, table: O.name.trim(), customer: O.name.trim(), phone: O.phone.trim(), note: O.note.trim() }
  };
  if (dv && dv.value > 0) body.discount = { type: dv.type, value: dv.value, reason: S.disc.reason.trim() };
  return run(el, async () => {
    let r;
    try { r = await api('POST', '/api/sales', body); } catch (e) { if (e.status === 409) { try { await loaders.sell(); paint(); } catch (x) { /* ignore */ } } throw e; }
    resetSale(); hooks.openModal({ type: 'receipt', sale: r.sale, fresh: true }); confetti();
    try { await loaders.sell(); } catch (e) { /* ignore */ }
    paint();
  });
};
