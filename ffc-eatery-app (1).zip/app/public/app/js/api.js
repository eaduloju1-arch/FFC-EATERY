/* Talks to the FFC server. The sign-in token is kept on this device only. */
let token = '';
try { token = localStorage.getItem('ffc:token') || ''; } catch (e) { /* ignore */ }
export const setToken = t => { token = t || ''; try { if (t) localStorage.setItem('ffc:token', t); else localStorage.removeItem('ffc:token'); } catch (e) { /* ignore */ } };
export const hasToken = () => !!token;

export class ApiError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
let onUnauthorized = () => {};
export const setUnauthorizedHandler = f => { onUnauthorized = f; };

export async function api(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method, cache: 'no-store',
      headers: Object.assign({}, body ? { 'Content-Type': 'application/json' } : {}, token ? { Authorization: 'Bearer ' + token } : {}),
      body: body ? JSON.stringify(body) : undefined
    });
  } catch (e) { throw new ApiError(0, 'Cannot reach the server. Check your connection and try again.'); }
  let data = null;
  if ((res.headers.get('content-type') || '').includes('json')) { try { data = await res.json(); } catch (e) { /* ignore */ } }
  if (!res.ok) {
    if (res.status === 401 && token) onUnauthorized();
    throw new ApiError(res.status, (data && data.error) || 'Something went wrong (' + res.status + ').');
  }
  return data;
}

/* live updates: a long-lived request the server writes to whenever something changes */
export function openStream(onEvent, onStatus) {
  let stop = false, ctrl = null, wait = 1000;
  (async function run() {
    while (!stop) {
      try {
        ctrl = new AbortController();
        const res = await fetch('/api/events', { headers: { Authorization: 'Bearer ' + token }, signal: ctrl.signal, cache: 'no-store' });
        if (res.status === 401) { onUnauthorized(); return; }
        if (!res.ok || !res.body) throw new Error('stream');
        onStatus(true); wait = 1000;
        const rd = res.body.getReader(), dec = new TextDecoder(); let buf = '';
        for (;;) {
          const { done, value } = await rd.read(); if (done) break;
          buf += dec.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
            const m = /^data: (.*)$/m.exec(chunk);
            if (m) { try { onEvent(JSON.parse(m[1])); } catch (e) { /* ignore */ } }
          }
        }
      } catch (e) { /* reconnect below */ }
      if (stop) break;
      onStatus(false);
      await new Promise(r => setTimeout(r, wait)); wait = Math.min(wait * 2, 15000);
    }
  })();
  return () => { stop = true; try { ctrl && ctrl.abort(); } catch (e) { /* ignore */ } };
}

export async function download(url, filename) {
  let res;
  try { res = await fetch(url, { headers: { Authorization: 'Bearer ' + token } }); } catch (e) { throw new ApiError(0, 'Cannot reach the server.'); }
  if (!res.ok) throw new ApiError(res.status, 'Download failed.');
  const blob = await res.blob(), a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
}
