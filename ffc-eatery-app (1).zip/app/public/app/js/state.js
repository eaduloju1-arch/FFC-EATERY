/* Shared app state and the small registries every screen plugs into */
import { today } from './util.js';

export const ROLES = {
  sales: { label: 'Sales Point', blurb: 'Sell and collect cash, transfer or card', icon: 'sell', hue: 1, tabs: ['sell', 'sales', 'stock'] },
  supervisor: { label: 'Supervisor', blurb: 'Run your branch and approve incoming stock', icon: 'shield', hue: 5, tabs: ['overview', 'sell', 'transfers', 'sales', 'stock', 'shifts', 'expenses', 'reports'] },
  procurement: { label: 'Procurement Officer', blurb: 'Buy stock and send it between branches', icon: 'truck', hue: 2, tabs: ['transfers', 'stock', 'expenses'] },
  gm: { label: 'General Manager', blurb: 'All branches, reports, menu and staff', icon: 'star', hue: 6, tabs: ['overview', 'sales', 'transfers', 'stock', 'shifts', 'expenses', 'reports', 'settings'] }
};
export const ROLE_ORDER = ['sales', 'supervisor', 'procurement', 'gm'];
export const TABS = {
  sell: ['Sell', 'sell'], sales: ['Sales', 'receipt'], overview: ['Overview', 'grid'], transfers: ['Transfers', 'swap'], stock: ['Stock', 'box'],
  shifts: ['Shifts', 'clock'], expenses: ['Expenses', 'wallet'], reports: ['Reports', 'chart'], settings: ['Settings', 'sliders']
};

export const S = {
  ready: false, user: null, config: null, catHue: {}, tab: null, enter: false, live: false, pending: 0, loginIntro: true, modal: null,
  /* sign in */
  loginRole: null, loginUser: '', pin: '', roster: [], busy: false,
  /* sell */
  cat: 'All', q: '', cart: {}, order: { type: 'dine-in', name: '', phone: '', note: '' }, disc: { type: 'none', value: '', reason: '' },
  pay: { method: 'cash', rest: 'transfer', tender: '', touched: false, cash: '', ref: '', seen: false }, pop: null,
  /* screens */
  salesDate: '', salesBranch: 'all', salesMethod: 'all', salesQ: '',
  exp: { range: 'week', scope: 'all' }, rep: { mode: 'week', anchor: '', branch: 'all' }, ovBranch: 'all',
  shiftFrom: '', shiftTo: '', shiftBranch: 'all', stockCat: 'All', sett: 'menu', auditQ: '',
  td: { from: '', to: '', lines: [{ itemId: '', qty: '' }], note: '' }
};
export const D = {};                 // data loaded from the server, by screen
export const F = {};                 // text typed into forms
export const fv = (k, d) => F[k] != null ? F[k] : (d == null ? '' : d);
export const actions = {};           // click, input and change handlers, by name
export const loaders = {};           // screen data loaders
export const modalViews = {};        // modal renderers, by type
export const hooks = { render() {}, renderModal() {}, openModal() {}, closeModal() {}, reload() {}, go() {}, startSession() {}, refreshBadges() {} };

export const biz = () => S.config.business;
export const branches = () => S.config.branches;
export const branchName = id => { const b = S.config.branches.find(x => x.id === id); return b ? b.name : 'Unknown branch'; };
export const itemById = id => S.config.items.find(i => i.id === id);
export const itemName = id => { const i = itemById(id); return i ? i.name : 'Removed item'; };
export const itemEmoji = id => { const i = itemById(id); return (i && i.emoji) || '🍽️'; };
export const activeItems = () => S.config.items.filter(i => i.active !== false);
export const roleLabel = r => ROLES[r] ? ROLES[r].label : r;
export const visibleBranchIds = () => (S.user.role === 'sales' || S.user.role === 'supervisor') ? [S.user.branch] : S.config.branches.map(b => b.id);
export const isMulti = () => visibleBranchIds().length > 1;
export const canApprove = t => S.user.role === 'gm' || (S.user.role === 'supervisor' && S.user.branch === t.to);

export function buildHues() {
  const seen = []; S.catHue = {};
  S.config.items.forEach(i => { if (!seen.includes(i.category)) seen.push(i.category); });
  seen.forEach((c, k) => { S.catHue[c] = (k % 7) + 1; });
}
export const hueOf = cat => S.catHue[cat] || 1;
export const hueVars = h => '--c:var(--h' + h + ');--ct:var(--h' + h + 't);--cd:var(--h' + h + 'd)';

export const loadingView = () => '<div class="skel" aria-busy="true" aria-label="Loading"><div class="sk h"></div><div class="sk"></div><div class="sk"></div><div class="sk s"></div></div>';

export function resetFilters() {
  const t = today();
  S.salesDate = t; S.salesBranch = 'all'; S.salesMethod = 'all'; S.salesQ = '';
  S.exp = { range: 'week', scope: 'all' }; S.rep = { mode: 'week', anchor: t, branch: 'all' }; S.ovBranch = 'all';
  S.shiftFrom = t; S.shiftTo = t; S.shiftBranch = 'all'; S.stockCat = 'All'; S.sett = 'menu'; S.auditQ = '';
  S.cart = {}; S.cat = 'All'; S.q = '';
  S.order = { type: 'dine-in', name: '', phone: '', note: '' }; S.disc = { type: 'none', value: '', reason: '' };
  S.td = { from: '', to: '', lines: [{ itemId: '', qty: '' }], note: '' };
  Object.keys(D).forEach(k => delete D[k]); Object.keys(F).forEach(k => delete F[k]);
}
