/* Transfers: move stock between branches, with approval by the receiving branch */
import { S, D, F, fv, actions, loaders, modalViews, hooks, branches, branchName, itemById, itemName, itemEmoji, canApprove } from './state.js';
import { esc, ic, money, num, dt } from './util.js';
import { api } from './api.js';
import { pageHead, sheetHead, seg, field, pill, empty, run, branchOptions, itemOptions } from './ui.js';

loaders.transfers = async () => {
  const [t, st] = await Promise.all([api('GET', '/api/transfers'), api('GET', '/api/stock')]);
  D.transfers = { list: t.transfers, stock: st.stock, reserved: st.reserved };
};

const avail = (branch, id) => {
  const T = D.transfers; if (!T) return 0;
  return Math.max(0, ((T.stock[branch] || {})[id] || 0) - (T.reserved[branch + '|' + id] || 0));
};
const canSend = () => S.user.role === 'procurement' || S.user.role === 'gm';
const KIND = { pending: 'warn', approved: 'ok', rejected: 'bad', cancelled: '' };
const LABEL = { pending: 'Waiting for approval', approved: 'Approved', rejected: 'Rejected', cancelled: 'Cancelled' };

function card(t) {
  const lines = t.lines.map(l => '<li><span aria-hidden="true">' + esc(itemEmoji(l.itemId)) + '</span><span>' + esc(itemName(l.itemId)) + '</span><b>× ' + l.qty + '</b></li>').join('');
  const short = t.status === 'pending' ? t.lines.filter(l => (((D.transfers.stock[t.from] || {})[l.itemId]) || 0) < l.qty) : [];
  const btns = [];
  if (t.status === 'pending' && canApprove(t)) btns.push('<button class="btn primary" data-act="tf-approve" data-id="' + esc(t.id) + '">' + ic('check', 18) + 'Approve</button><button class="btn danger" data-act="tf-reject" data-id="' + esc(t.id) + '">Reject</button>');
  if (t.status === 'pending' && canSend() && (S.user.role === 'gm' || t.by === S.user.id)) btns.push('<button class="btn" data-act="tf-cancel" data-id="' + esc(t.id) + '">Cancel transfer</button>');
  return '<article class="card tf ' + t.status + '"><div class="tf-h"><div class="route"><b>' + esc(branchName(t.from)) + '</b>' + ic('right', 18) + '<b>' + esc(branchName(t.to)) + '</b></div>' + pill(LABEL[t.status], KIND[t.status]) + '</div>' +
    '<ul class="tf-l">' + lines + '</ul>' + (t.note ? '<p class="muted small">Note: ' + esc(t.note) + '</p>' : '') +
    (short.length ? '<div class="note warn small">' + esc(branchName(t.from)) + ' does not have enough ' + esc(short.map(l => itemName(l.itemId)).join(', ')) + ' right now.</div>' : '') +
    '<p class="muted small">Sent by ' + esc(t.byName) + ' · ' + esc(dt(t.at)) + (t.decidedByName && t.status !== 'pending' ? ' · ' + (t.status === 'cancelled' ? 'Cancelled' : t.status === 'approved' ? 'Approved' : 'Rejected') + ' by ' + esc(t.decidedByName) + ' · ' + esc(dt(t.decidedAt)) : '') + '</p>' +
    (t.reason ? '<p class="muted small">Reason: ' + esc(t.reason) + '</p>' : '') + (btns.length ? '<div class="tf-a">' + btns.join('') + '</div>' : '') + '</article>';
}

export function transfersView() {
  const all = D.transfers.list, pend = all.filter(t => t.status === 'pending'), tab = S.tfTab || (pend.length ? 'pending' : 'all'), list = tab === 'pending' ? pend : all;
  return pageHead('Transfers', S.user.role === 'supervisor' ? 'Stock coming to or leaving your branch.' : 'Send stock from one branch to another.',
      canSend() ? '<button class="btn primary" data-act="tf-new">' + ic('plus', 18) + 'New transfer</button>' : '') +
    seg([['pending', 'Waiting (' + pend.length + ')'], ['all', 'All transfers']], tab, 'tf-tab', 'Show') +
    (list.length ? '<div class="cards">' + list.map(card).join('') + '</div>' : empty(tab === 'pending' ? '📦' : '🚚', tab === 'pending' ? 'Nothing is waiting' : 'No transfers yet', canSend() ? 'Use New transfer to send stock to a branch.' : 'Transfers will show up here.'));
}

actions['tf-tab'] = el => { S.tfTab = el.dataset.v; hooks.render(); };
actions['tf-approve'] = el => run(el, async () => { await api('POST', '/api/transfers/' + encodeURIComponent(el.dataset.id) + '/approve'); await hooks.reload(); hooks.refreshBadges(); }, { ok: 'Transfer approved. Stock has moved.' });
actions['tf-cancel'] = el => run(el, async () => { await api('POST', '/api/transfers/' + encodeURIComponent(el.dataset.id) + '/cancel'); await hooks.reload(); }, { ok: 'Transfer cancelled.' });
actions['tf-reject'] = el => hooks.openModal({ type: 'tf-reject', id: el.dataset.id, cls: 'low' });
modalViews['tf-reject'] = () => sheetHead('Reject this transfer?', 'The sender will see your reason.') + '<div class="sh-body">' +
  field('Reason (optional)', '<input data-autofocus maxlength="140" data-f="m.reason" data-enter="tf-reject-do" value="' + esc(fv('m.reason')) + '" autocomplete="off">') + '</div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">Back</button><button class="btn danger" data-act="tf-reject-do">Reject transfer</button></div>';
actions['tf-reject-do'] = el => run(el, async () => {
  await api('POST', '/api/transfers/' + encodeURIComponent(S.modal.id) + '/reject', { reason: (fv('m.reason') || '').trim() }); hooks.closeModal(); await hooks.reload(); hooks.refreshBadges();
}, { ok: 'Transfer rejected.' });

/* ---------- new transfer ---------- */
modalViews['tf-new'] = () => {
  const d = S.td, bs = branches(), rows = d.lines.map((l, i) => {
    const a = l.itemId ? avail(d.from, l.itemId) : null, over = a != null && num(l.qty) > a;
    return '<div class="tl-row"><label class="f"><span>Item</span><select data-change="td-item" data-i="' + i + '">' + itemOptions(l.itemId, 'Choose an item') + '</select></label>' +
      '<label class="f q"><span>Qty</span><input inputmode="numeric" data-f="m.q' + i + '" data-input="td-qty" data-i="' + i + '" value="' + esc(l.qty) + '" autocomplete="off"></label>' +
      '<button class="ib" data-act="td-del" data-i="' + i + '" aria-label="Remove this line"' + (d.lines.length < 2 ? ' disabled' : '') + '>' + ic('trash', 18) + '</button>' +
      (a != null ? '<small class="' + (over ? 'bad' : '') + ' hint">' + (over ? 'Only ' + a + ' available at ' + esc(branchName(d.from)) : a + ' available at ' + esc(branchName(d.from))) + '</small>' : '') + '</div>';
  }).join('');
  return sheetHead('New transfer', 'Stock leaves the sender only when the receiving branch approves.') + '<div class="sh-body scroll">' +
    '<div class="grid2">' + field('From', '<select data-change="td-from">' + branchOptions(d.from) + '</select>') + field('To', '<select data-change="td-to">' + branchOptions(d.to) + '</select>') + '</div>' +
    '<h3 class="sub">Items</h3>' + rows + '<button class="btn sm" data-act="td-add">' + ic('plus', 16) + 'Add another item</button>' +
    field('Note (optional)', '<input maxlength="140" data-f="m.tnote" data-input="td-note" value="' + esc(d.note) + '" autocomplete="off">') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="td-send">' + ic('truck', 18) + 'Send for approval</button></div>';
};
actions['tf-new'] = () => {
  const bs = branches(); if (bs.length < 2) { hooks.openModal({ type: 'info', title: 'You need two branches', text: 'Add a second branch in Settings before sending stock.', cls: 'low' }); return; }
  S.td = { from: bs[0].id, to: bs[1].id, lines: [{ itemId: '', qty: '' }], note: '' };
  hooks.openModal({ type: 'tf-new' });
};
modalViews.info = m => sheetHead(m.title) + '<div class="sh-body"><p>' + esc(m.text) + '</p></div><div class="sh-foot"><button class="btn primary" data-act="close">OK</button></div>';
const re = () => hooks.renderModal();
actions['td-from'] = el => { S.td.from = el.value; if (S.td.to === el.value) S.td.to = branches().find(b => b.id !== el.value).id; re(); };
actions['td-to'] = el => { S.td.to = el.value; if (S.td.from === el.value) S.td.from = branches().find(b => b.id !== el.value).id; re(); };
actions['td-item'] = el => { S.td.lines[+el.dataset.i].itemId = el.value; re(); };
actions['td-qty'] = el => { S.td.lines[+el.dataset.i].qty = el.value.replace(/[^\d]/g, ''); re(); };
actions['td-note'] = el => { S.td.note = el.value; };
actions['td-add'] = () => { S.td.lines.push({ itemId: '', qty: '' }); re(); };
actions['td-del'] = el => { if (S.td.lines.length > 1) S.td.lines.splice(+el.dataset.i, 1); re(); };
actions['td-send'] = el => run(el, async () => {
  const d = S.td, lines = d.lines.filter(l => l.itemId || l.qty !== '');
  if (!lines.length) throw new Error('Add at least one item.');
  for (const l of lines) { if (!l.itemId) throw new Error('Choose an item on every line.'); if (!(num(l.qty) >= 1)) throw new Error('Enter a quantity of 1 or more for ' + itemName(l.itemId) + '.'); }
  await api('POST', '/api/transfers', { from: d.from, to: d.to, lines: lines.map(l => ({ itemId: l.itemId, qty: Math.floor(num(l.qty)) })), note: d.note.trim() });
  S.tfTab = 'pending'; hooks.closeModal(); await hooks.reload();
}, { ok: 'Transfer sent for approval.' });
