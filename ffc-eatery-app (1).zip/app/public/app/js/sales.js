/* Sales: the day's sales, receipts and voids */
import { S, D, F, fv, actions, loaders, modalViews, hooks, branchName, isMulti, visibleBranchIds, hueVars } from './state.js';
import { $, esc, ic, money, tm, today, addDays, dlabel } from './util.js';
import { api } from './api.js';
import { pageHead, sheetHead, seg, stat, empty, field, pill, run, branchOptions, methodLabel } from './ui.js';

const MH = { cash: 4, transfer: 5, card: 7, split: 2 };

loaders.sales = async () => {
  const q = '?date=' + S.salesDate + (S.salesBranch !== 'all' ? '&branch=' + encodeURIComponent(S.salesBranch) : '');
  D.sales = await api('GET', '/api/sales' + q);
};

const visible = () => {
  const q = S.salesQ.trim().toLowerCase();
  return D.sales.sales.filter(s => (S.salesMethod === 'all' || s.method === S.salesMethod) &&
    (!q || (s.no + ' ' + (s.customer || '') + ' ' + (s.table || '') + ' ' + s.byName + ' ' + s.lines.map(l => l.name).join(' ')).toLowerCase().includes(q)));
};

function row(s) {
  const items = s.lines.map(l => l.qty + '× ' + l.name).join(', ');
  const where = s.orderType === 'dine-in' ? (s.table ? 'Table ' + s.table : 'Dine in') : (s.orderType === 'delivery' ? 'Delivery' : 'Takeaway') + (s.customer ? ' · ' + s.customer : '');
  return '<li><button class="sale' + (s.voided ? ' void' : '') + '" data-act="sale-open" data-id="' + esc(s.id) + '" style="' + hueVars(MH[s.method] || 1) + '">' +
    '<span class="st">' + tm(s.at) + '</span><div class="sm"><b>' + esc(s.no) + '</b><span class="items">' + esc(items) + '</span>' +
    '<small>' + esc(where) + ' · ' + esc(s.byName) + (isMulti() ? ' · ' + esc(branchName(s.branch)) : '') + '</small></div>' +
    '<div class="sr"><b>' + money(s.total) + '</b>' + (s.voided ? pill('Voided', 'bad') : '<span class="mchip">' + methodLabel(s.method) + '</span>') + '</div></button></li>';
}
const listHtml = () => { const l = visible(); return l.length ? '<ul class="sales-l">' + l.map(row).join('') + '</ul>' : empty('🧾', D.sales.sales.length ? 'No sales match' : 'No sales on this day', D.sales.sales.length ? 'Try clearing the search or payment filter.' : 'Sales will show up here as they are made.'); };

export function salesView() {
  const list = D.sales.sales, paid = list.filter(s => !s.voided), voided = list.length - paid.length;
  const sum = k => paid.reduce((a, s) => a + (s[k] || 0), 0), total = paid.reduce((a, s) => a + s.total, 0);
  const isToday = S.salesDate === today(), bs = visibleBranchIds();
  return pageHead('Sales', S.user.role === 'sales' ? 'The sales you have made.' : 'Every sale, receipt and void.') +
    '<div class="datebar"><button class="ib" data-act="sales-prev" aria-label="Previous day">' + ic('left', 18) + '</button>' +
    '<label class="dpick"><span>' + esc(isToday ? 'Today' : dlabel(S.salesDate)) + '</span><input type="date" data-change="sales-date" value="' + esc(S.salesDate) + '" max="' + esc(today()) + '" aria-label="Choose a day"></label>' +
    '<button class="ib" data-act="sales-next" aria-label="Next day"' + (isToday ? ' disabled' : '') + '>' + ic('right', 18) + '</button>' +
    (isToday ? '' : '<button class="btn sm" data-act="sales-today">Today</button>') + '</div>' +
    '<div class="stats">' + stat('Sales', total, { hue: 4, sub: paid.length + ' order' + (paid.length === 1 ? '' : 's') + (voided ? ' · ' + voided + ' voided' : '') }) + stat('Cash', sum('cash'), { hue: 3 }) + stat('Transfer', sum('transfer'), { hue: 5 }) + stat('Card', sum('card'), { hue: 7 }) + '</div>' +
    '<div class="filters">' + (bs.length > 1 ? '<label class="f inl"><span>Branch</span><select data-change="sales-branch">' + branchOptions(S.salesBranch, null, true) + '</select></label>' : '') +
    '<label class="search grow">' + ic('search', 18) + '<input id="sales-q" type="search" placeholder="Search receipt, table, customer or dish" value="' + esc(S.salesQ) + '" data-input="sales-q" autocomplete="off" aria-label="Search sales"></label></div>' +
    seg([['all', 'All'], ['cash', 'Cash'], ['transfer', 'Transfer'], ['card', 'Card'], ['split', 'Split']], S.salesMethod, 'sales-method', 'Payment method') +
    '<div id="sales-list">' + listHtml() + '</div>' + (D.sales.truncated ? '<p class="muted small">Showing the latest 1,000 sales. Narrow the filters to see others.</p>' : '');
}

const setDay = d => { S.salesDate = d > today() ? today() : d; hooks.reload(); };
actions['sales-prev'] = () => setDay(addDays(S.salesDate, -1));
actions['sales-next'] = () => setDay(addDays(S.salesDate, 1));
actions['sales-today'] = () => setDay(today());
actions['sales-date'] = el => { if (el.value) setDay(el.value); };
actions['sales-branch'] = el => { S.salesBranch = el.value; hooks.reload(); };
actions['sales-method'] = el => { S.salesMethod = el.dataset.v; hooks.render(); };
actions['sales-q'] = el => { S.salesQ = el.value; const l = $('#sales-list'); if (l) l.innerHTML = listHtml(); };
actions['sale-open'] = el => { const s = D.sales.sales.find(x => x.id === el.dataset.id); if (s) hooks.openModal({ type: 'receipt', sale: s }); };

/* ---------- void ---------- */
const REASONS = ['Wrong order', 'Customer cancelled', 'Duplicate entry', 'Price error', 'Food problem'];
modalViews.void = m => sheetHead('Void this sale?', esc(m.sale.no) + ' · ' + money(m.sale.total)) + '<div class="sh-body">' +
  '<p class="muted">The items go back into stock and the money is removed from the day\'s totals. This cannot be undone.</p>' +
  '<div class="chips small">' + REASONS.map(r => '<button class="chip" data-act="void-reason" data-v="' + esc(r) + '">' + esc(r) + '</button>').join('') + '</div>' +
  field('Reason', '<input data-autofocus maxlength="120" data-f="m.reason" data-enter="void-do" value="' + esc(fv('m.reason')) + '" autocomplete="off">') + '</div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">Keep sale</button><button class="btn danger" data-act="void-do">Void sale</button></div>';

actions['void-open'] = el => {
  const id = el.dataset.id, m = S.modal, s = (m && m.sale && m.sale.id === id) ? m.sale : (D.sales && D.sales.sales.find(x => x.id === id));
  if (s) hooks.openModal({ type: 'void', sale: s, cls: 'low' });
};
actions['void-reason'] = el => { F['m.reason'] = el.dataset.v; hooks.renderModal(); };
actions['void-do'] = el => run(el, async () => {
  const reason = (fv('m.reason') || '').trim(); if (reason.length < 3) throw new Error('Give a short reason for the void.');
  const r = await api('POST', '/api/sales/' + encodeURIComponent(S.modal.sale.id) + '/void', { reason });
  hooks.openModal({ type: 'receipt', sale: r.sale }); if (S.tab === 'sales' || S.tab === 'sell') await hooks.reload();
}, { ok: 'Sale voided and stock returned.' });
