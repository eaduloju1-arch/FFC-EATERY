/* Small UI pieces used by several screens: page headers, chips, stat cards, charts, the receipt */
import { S, actions, modalViews, hooks, biz, branchName, hueOf, hueVars } from './state.js';
import { esc, ic, money, fmt, compact, dt, tm, hourLabel, toast, num } from './util.js';

export const pageHead = (title, sub, right) =>
  '<div class="ph"><div><h1>' + esc(title) + '</h1>' + (sub ? '<p class="muted">' + sub + '</p>' : '') + '</div>' + (right ? '<div class="ph-r">' + right + '</div>' : '') + '</div>';

export const sheetHead = (title, sub) =>
  '<div class="sh-head"><div><h2>' + esc(title) + '</h2>' + (sub ? '<p class="muted">' + sub + '</p>' : '') + '</div>' +
  '<button class="x" data-act="close" aria-label="Close">' + ic('x', 20) + '</button></div>';

/* segmented control: items are [value, label] */
export const seg = (items, cur, act, label) =>
  '<div class="seg" role="group" aria-label="' + esc(label || 'Choose') + '">' +
  items.map(i => '<button class="' + (String(i[0]) === String(cur) ? 'on' : '') + '" data-act="' + act + '" data-v="' + esc(i[0]) + '" aria-pressed="' + (String(i[0]) === String(cur)) + '">' + i[1] + '</button>').join('') + '</div>';

/* category chips coloured by their hue; "All" uses the brand red */
export const catChips = (cats, cur, act) =>
  '<div class="chips" role="group" aria-label="Categories">' + ['All'].concat(cats).map(c =>
    '<button class="chip ' + (c === cur ? 'on' : '') + '" style="' + hueVars(c === 'All' ? 1 : hueOf(c)) + '" data-act="' + act + '" data-v="' + esc(c) + '" aria-pressed="' + (c === cur) + '">' + esc(c) + '</button>').join('') + '</div>';

export const pill = (text, kind) => '<span class="pill ' + (kind || '') + '">' + text + '</span>';

export const stat = (label, value, o) => {
  o = o || {};
  const v = typeof value === 'number' ? '<span data-count="' + value + '" ' + (o.plain ? '' : 'data-money') + '>' + (o.plain ? fmt(value) : money(value)) + '</span>' : value;
  return '<div class="stat" style="' + hueVars(o.hue || 1) + '"><span class="sl">' + esc(label) + '</span><b class="sv">' + v + '</b>' + (o.sub ? '<small>' + o.sub + '</small>' : '') + '</div>';
};

export const empty = (emoji, title, text, action) =>
  '<div class="empty"><div class="em" aria-hidden="true">' + emoji + '</div><h3>' + esc(title) + '</h3>' + (text ? '<p>' + text + '</p>' : '') + (action || '') + '</div>';

export const field = (label, control, hint) => '<label class="f"><span>' + label + '</span>' + control + (hint ? '<small>' + hint + '</small>' : '') + '</label>';

export const branchOptions = (cur, ids, all) =>
  (all ? '<option value="all"' + (cur === 'all' ? ' selected' : '') + '>All branches</option>' : '') +
  S.config.branches.filter(b => !ids || ids.includes(b.id)).map(b => '<option value="' + esc(b.id) + '"' + (b.id === cur ? ' selected' : '') + '>' + esc(b.name) + '</option>').join('');

export const itemOptions = (cur, blank) =>
  (blank ? '<option value="">' + esc(blank) + '</option>' : '') +
  S.config.items.filter(i => i.active !== false || i.id === cur).map(i => '<option value="' + esc(i.id) + '"' + (i.id === cur ? ' selected' : '') + '>' + esc((i.emoji ? i.emoji + ' ' : '') + i.name) + '</option>').join('');

let busy = false;
/* run an async action from a button: disable it, show errors as a toast, optionally close the sheet */
export async function run(el, fn, o) {
  o = o || {};
  const btn = el && el.tagName === 'BUTTON' ? el : null;
  if (busy) return false; busy = true;
  if (btn) { if (btn.disabled) { busy = false; return false; } btn.disabled = true; btn.classList.add('busy'); }
  try {
    const r = await fn();
    if (o.ok) toast(o.ok, 'ok');
    if (o.close) hooks.closeModal();
    return r === undefined ? true : r;
  } catch (e) {
    toast(e.message || 'Something went wrong.', 'err');
    return false;
  } finally { busy = false; if (btn && btn.isConnected) { btn.disabled = false; btn.classList.remove('busy'); } }
}

/* ---------- charts (plain SVG/CSS, no libraries) ---------- */
export function hourBars(byHour, label) {
  const from = 6, to = 23, rows = byHour.slice(from, to + 1), max = Math.max.apply(null, rows.map(h => h.revenue).concat([1]));
  if (!rows.some(h => h.revenue > 0)) return '<p class="muted small">No sales yet.</p>';
  const peak = rows.reduce((a, h, i) => h.revenue > rows[a].revenue ? i : a, 0);
  return '<div class="hbars" role="img" aria-label="' + esc(label || 'Sales by hour') + '. Busiest hour ' + hourLabel(from + peak) + '.">' + rows.map((h, i) =>
    '<div class="hb' + (i === peak ? ' peak' : '') + '" title="' + hourLabel(from + i) + ': ' + esc(money(h.revenue)) + ' from ' + h.count + ' sales"><i style="--h:' + Math.max(h.revenue ? 4 : 0, Math.round(h.revenue / max * 100)) + '%;--d:' + i + '"></i><span>' + ((from + i) % 3 === 0 ? hourLabel(from + i) : '') + '</span></div>').join('') + '</div>';
}

export function dayBars(days) {
  const max = Math.max.apply(null, days.map(d => Math.max(d.sales, d.expenses)).concat([1])), many = days.length > 14;
  return '<div class="dbars' + (many ? ' many' : '') + '" role="img" aria-label="Sales and expenses by day">' + days.map((d, i) => {
    const lb = d.date.slice(8) + (d.date.slice(8) === '01' || i === 0 ? '/' + d.date.slice(5, 7) : '');
    return '<div class="db" title="' + d.date + ': sales ' + esc(money(d.sales)) + ', expenses ' + esc(money(d.expenses)) + '"><div class="pair"><i class="s" style="--h:' + Math.round(d.sales / max * 100) + '%;--d:' + i + '"></i><i class="e" style="--h:' + Math.round(d.expenses / max * 100) + '%;--d:' + i + '"></i></div><span>' + (many && i % Math.ceil(days.length / 12) ? '' : lb) + '</span></div>';
  }).join('') + '</div><div class="legend"><span><i class="s"></i>Sales</span><span><i class="e"></i>Expenses</span></div>';
}

/* a ranked list with proportional bars, each in its own colour */
export function rankList(rows, valueOf, labelOf, fmtV, hueOfRow) {
  if (!rows.length) return '<p class="muted small">Nothing to show yet.</p>';
  const max = Math.max.apply(null, rows.map(valueOf).concat([1]));
  return '<ol class="rank">' + rows.map((r, i) => '<li style="' + hueVars(hueOfRow ? hueOfRow(r, i) : (i % 7) + 1) + '"><div class="rk-l"><b>' + esc(labelOf(r)) + '</b><span>' + fmtV(r) + '</span></div><div class="rk-b"><i style="--w:' + Math.max(3, Math.round(valueOf(r) / max * 100)) + '%;--d:' + i + '"></i></div></li>').join('') + '</ol>';
}

/* a donut using conic-gradient; parts are [label, value, hue] */
export function donut(parts, centre) {
  const tot = parts.reduce((a, p) => a + p[1], 0);
  if (!(tot > 0)) return '<p class="muted small">No sales in this period.</p>';
  let acc = 0;
  const stops = parts.filter(p => p[1] > 0).map(p => { const a = acc / tot * 100; acc += p[1]; return 'var(--h' + p[2] + ') ' + a.toFixed(2) + '% ' + (acc / tot * 100).toFixed(2) + '%'; }).join(',');
  return '<div class="donut-w"><div class="donut" style="background:conic-gradient(' + stops + ')" role="img" aria-label="' + esc(parts.map(p => p[0] + ' ' + Math.round(p[1] / tot * 100) + '%').join(', ')) + '"><div><b>' + esc(centre || '') + '</b></div></div>' +
    '<ul class="dl">' + parts.filter(p => p[1] > 0).map(p => '<li style="--c:var(--h' + p[2] + ')"><i></i><span>' + esc(p[0]) + '</span><b>' + Math.round(p[1] / tot * 100) + '%</b></li>').join('') + '</ul></div>';
}

/* ---------- receipt ---------- */
const METHOD = { cash: 'Cash', transfer: 'Bank transfer', card: 'Card', split: 'Split payment' };
export const methodLabel = m => METHOD[m] || m;

export function receiptHtml(s) {
  const b = biz(), ex = !s.vatInclusive && s.vat > 0;
  const rows = s.lines.map(l => '<tr><td class="q">' + l.qty + '×</td><td>' + esc(l.name) + '</td><td class="r">' + money(l.price * l.qty) + '</td></tr>').join('');
  const pay = [];
  if (s.cash) pay.push(['Cash', s.cash]); if (s.transfer) pay.push(['Bank transfer', s.transfer]); if (s.card) pay.push(['Card', s.card]);
  const who = s.orderType === 'dine-in' ? (s.table ? 'Table ' + esc(s.table) : 'Dine in') : (s.orderType === 'delivery' ? 'Delivery' : 'Takeaway') + (s.customer ? ' · ' + esc(s.customer) : '') + (s.phone ? ' · ' + esc(s.phone) : '');
  return '<div class="rc' + (s.voided ? ' void' : '') + '" id="receipt">' +
    (s.voided ? '<div class="stamp">VOIDED</div>' : '') +
    '<div class="rc-h"><b>' + esc(b.name) + '</b><span>' + esc(branchName(s.branch)) + '</span><small>' + esc(dt(s.at)) + '</small></div>' +
    '<div class="rc-m"><span>Receipt <b>' + esc(s.no) + '</b></span><span>' + who + '</span><span>Served by ' + esc(s.byName) + '</span></div>' +
    '<table class="rc-t">' + rows + '</table>' +
    '<div class="rc-s"><div><span>Subtotal</span><span>' + money(s.subtotal) + '</span></div>' +
    (s.discountAmt ? '<div><span>Discount' + (s.discountType === 'pct' ? ' (' + s.discountValue + '%)' : '') + '</span><span>-' + money(s.discountAmt) + '</span></div>' : '') +
    (s.vat ? '<div><span>VAT ' + s.vatRate + '%' + (s.vatInclusive ? ' (included)' : '') + '</span><span>' + money(s.vat) + '</span></div>' : '') +
    '<div class="tot"><span>Total' + (ex ? ' incl. VAT' : '') + '</span><span>' + money(s.total) + '</span></div>' +
    pay.map(p => '<div><span>' + p[0] + '</span><span>' + money(p[1]) + '</span></div>').join('') +
    (s.change ? '<div><span>Cash given</span><span>' + money(s.tendered) + '</span></div><div><span>Change</span><span>' + money(s.change) + '</span></div>' : '') +
    (s.ref ? '<div><span>Reference</span><span>' + esc(s.ref) + '</span></div>' : '') + '</div>' +
    (s.note ? '<p class="rc-n">Note: ' + esc(s.note) + '</p>' : '') +
    (s.voided ? '<p class="rc-n">Voided by ' + esc(s.voidedBy || '') + ': ' + esc(s.voidReason || '') + '</p>' : '') +
    '<p class="rc-f">' + esc(b.receiptFooter || 'Thank you for eating with us!') + '</p></div>';
}

export function receiptText(s) {
  const b = biz(), L = [b.name + ' - ' + branchName(s.branch), 'Receipt ' + s.no + ' | ' + dt(s.at), ''];
  s.lines.forEach(l => L.push(l.qty + ' x ' + l.name + '  ' + money(l.price * l.qty)));
  L.push('');
  if (s.discountAmt) L.push('Discount: -' + money(s.discountAmt));
  if (s.vat) L.push('VAT ' + s.vatRate + '%: ' + money(s.vat));
  L.push('TOTAL: ' + money(s.total), 'Paid by: ' + methodLabel(s.method), '', b.receiptFooter || 'Thank you for eating with us!');
  return L.join('\n');
}

modalViews.receipt = m => {
  const s = m.sale, canVoid = !s.voided && (S.user.role === 'gm' || (S.user.role === 'supervisor' && S.user.branch === s.branch));
  return sheetHead(m.fresh ? 'Sale complete' : 'Receipt', m.fresh ? 'Stock has been updated.' : esc(dt(s.at))) +
    '<div class="sh-body scroll">' + receiptHtml(s) + '</div>' +
    '<div class="sh-foot no-print"><button class="btn" data-act="rc-print">' + ic('print', 18) + 'Print</button><button class="btn" data-act="rc-share">' + ic('share', 18) + 'Share</button>' +
    (canVoid ? '<button class="btn danger" data-act="void-open" data-id="' + esc(s.id) + '">Void sale</button>' : '') +
    (m.fresh ? '<button class="btn primary" data-act="close">New sale</button>' : '<button class="btn primary" data-act="close">Done</button>') + '</div>';
};
actions['rc-print'] = () => window.print();
actions['rc-share'] = async () => {
  const s = S.modal && S.modal.sale; if (!s) return;
  const text = receiptText(s);
  try {
    if (navigator.share) { await navigator.share({ title: 'Receipt ' + s.no, text }); return; }
    await navigator.clipboard.writeText(text); toast('Receipt copied. Paste it into a message.', 'ok');
  } catch (e) { if (e && e.name !== 'AbortError') toast('Could not share this receipt.', 'err'); }
};

export { num, compact, tm };

/* a plain "are you sure?" sheet. The button fires actions[m.act] with data-id set to m.id */
modalViews.confirm = m => sheetHead(m.title) + '<div class="sh-body"><p>' + (m.text || '') + '</p></div>' +
  '<div class="sh-foot"><button class="btn" data-act="close">' + esc(m.no || 'Keep it') + '</button><button class="btn ' + (m.danger === false ? 'primary' : 'danger') + '" data-act="' + esc(m.act) + '" data-id="' + esc(m.id || '') + '">' + esc(m.yes || 'Yes') + '</button></div>';

actions['modal-refresh'] = () => hooks.renderModal();
