/* Expenses: money going out of a branch */
import { S, D, fv, actions, loaders, modalViews, hooks, branches, branchName, isMulti, visibleBranchIds, hueVars } from './state.js';
import { esc, ic, money, num, today, weekStart, monthRange, addDays, dlabel } from './util.js';
import { api } from './api.js';
import { pageHead, sheetHead, seg, field, pill, stat, empty, run, rankList, branchOptions } from './ui.js';

const range = () => { const t = today(); switch (S.exp.range) { case 'today': return [t, t]; case 'week': return [weekStart(t), t]; case 'month': return [monthRange(t)[0], t]; default: return [addDays(t, -89), t]; } };
const catHue = c => { const i = S.config.expenseCategories.indexOf(c); return (i < 0 ? 0 : i) % 7 + 1; };

loaders.expenses = async () => {
  const r = range(), b = S.exp.branch && S.exp.branch !== 'all' ? '&branch=' + encodeURIComponent(S.exp.branch) : '';
  D.expenses = (await api('GET', '/api/expenses?from=' + r[0] + '&to=' + r[1] + b));
};
const canDelete = e => S.user.role === 'gm' || (S.user.role === 'procurement' && e.by === S.user.id) || (S.user.role === 'supervisor' && e.branch === S.user.branch);

export function expensesView() {
  let list = D.expenses.expenses; if (S.exp.scope === 'mine') list = list.filter(e => e.by === S.user.id);
  const total = list.reduce((a, e) => a + e.amount, 0), by = {}; list.forEach(e => { by[e.category] = (by[e.category] || 0) + e.amount; });
  const cats = Object.keys(by).map(k => ({ name: k, total: by[k] })).sort((a, b) => b.total - a.total), bs = visibleBranchIds();
  const rows = list.map(e => '<li class="exp" style="' + hueVars(catHue(e.category)) + '"><span class="ec">' + esc(e.category) + '</span><div class="em"><b>' + esc(e.note || e.category) + '</b><small>' + esc(dlabel(e.date)) + ' · ' + esc(e.byName) + (isMulti() ? ' · ' + esc(branchName(e.branch)) : '') + '</small></div>' +
    '<b class="ea">' + money(e.amount) + '</b>' + (canDelete(e) ? '<button class="ib sm" data-act="exp-del" data-id="' + esc(e.id) + '" aria-label="Delete this expense">' + ic('trash', 18) + '</button>' : '') + '</li>').join('');
  return pageHead('Expenses', 'Gas, supplies, wages and everything else you pay for.', '<button class="btn primary" data-act="exp-add">' + ic('plus', 18) + 'Add expense</button>') +
    seg([['today', 'Today'], ['week', 'This week'], ['month', 'This month'], ['quarter', '3 months']], S.exp.range, 'exp-range', 'Period') +
    '<div class="filters">' + seg([['all', 'Everyone'], ['mine', 'Mine only']], S.exp.scope, 'exp-scope', 'Whose expenses') +
    (bs.length > 1 ? '<label class="f inl"><span>Branch</span><select data-change="exp-branch">' + branchOptions(S.exp.branch || 'all', null, true) + '</select></label>' : '') + '</div>' +
    '<div class="stats">' + stat('Total spent', total, { hue: 1, sub: list.length + ' expense' + (list.length === 1 ? '' : 's') }) + stat('Biggest category', cats[0] ? esc(cats[0].name) : 'None yet', { hue: 3, sub: cats[0] ? money(cats[0].total) : '' }) + '</div>' +
    (cats.length ? '<section class="card"><h2>Where it went</h2>' + rankList(cats, c => c.total, c => c.name, c => money(c.total), c => catHue(c.name)) + '</section>' : '') +
    (list.length ? '<ul class="exps card">' + rows + '</ul>' : empty('💸', 'No expenses in this period', 'Add one when you pay for something.'));
}

actions['exp-range'] = el => { S.exp.range = el.dataset.v; hooks.reload(); };
actions['exp-scope'] = el => { S.exp.scope = el.dataset.v; hooks.render(); };
actions['exp-branch'] = el => { S.exp.branch = el.value; hooks.reload(); };

modalViews.expense = () => {
  const fixed = S.user.role === 'supervisor', bs = visibleBranchIds();
  return sheetHead('Add expense', fixed ? esc(branchName(S.user.branch)) : 'Record money spent.') + '<div class="sh-body scroll">' +
    '<div class="grid2">' + (fixed ? '' : field('Branch', '<select data-f="m.branch">' + branchOptions(fv('m.branch', bs[0]), bs) + '</select>')) + field('Date', '<input type="date" data-f="m.date" max="' + esc(today()) + '" value="' + esc(fv('m.date', today())) + '">') + '</div>' +
    '<div class="grid2">' + field('Category', '<select data-f="m.cat">' + S.config.expenseCategories.map(c => '<option' + (c === fv('m.cat', 'Food supplies') ? ' selected' : '') + '>' + esc(c) + '</option>').join('') + '</select>') +
    field('Amount', '<input inputmode="decimal" data-autofocus data-f="m.amount" value="' + esc(fv('m.amount')) + '" autocomplete="off">') + '</div>' +
    field('Details (optional)', '<input maxlength="140" data-f="m.note" data-enter="exp-do-add" placeholder="What was it for?" value="' + esc(fv('m.note')) + '" autocomplete="off">') + '</div>' +
    '<div class="sh-foot"><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="exp-do-add">Save expense</button></div>';
};
actions['exp-add'] = () => hooks.openModal({ type: 'expense', f: { 'm.branch': visibleBranchIds()[0], 'm.date': today(), 'm.cat': 'Food supplies' } });
actions['exp-do-add'] = el => run(el, async () => {
  const amount = num(fv('m.amount')); if (!(amount > 0)) throw new Error('Enter an amount above zero.');
  await api('POST', '/api/expenses', { branch: S.user.role === 'supervisor' ? S.user.branch : fv('m.branch', visibleBranchIds()[0]), date: fv('m.date', today()), category: fv('m.cat', 'Food supplies'), amount, note: (fv('m.note') || '').trim() });
  hooks.closeModal(); await hooks.reload();
}, { ok: 'Expense saved.' });

actions['exp-del'] = el => { const e = D.expenses.expenses.find(x => x.id === el.dataset.id); if (e) hooks.openModal({ type: 'confirm', title: 'Delete this expense?', text: esc(e.category) + ' · ' + money(e.amount) + (e.note ? ' · ' + esc(e.note) : '') + '. It will be removed from the totals.', act: 'exp-do-del', id: e.id, yes: 'Delete', cls: 'low' }); };
actions['exp-do-del'] = el => run(el, async () => { await api('DELETE', '/api/expenses/' + encodeURIComponent(el.dataset.id)); hooks.closeModal(); await hooks.reload(); }, { ok: 'Expense deleted.' });
