/* FFC POS: starts the app, draws the frame around each screen, and wires clicks to actions */
import { S, D, F, fv, ROLES, TABS, actions, loaders, modalViews, hooks, biz, branchName, buildHues, resetFilters, loadingView, roleLabel, hueVars } from './state.js';
import { $, $$, esc, ic, toast, setLocale, countUp, LS } from './util.js';
import { api, setToken, hasToken, setUnauthorizedHandler, openStream } from './api.js';
import { loginView, pinKey, doLogin } from './login.js';
import { sheetHead, seg, field, run, empty } from './ui.js';
import { sellView } from './sell.js';
import { salesView } from './sales.js';
import { overviewView } from './overview.js';
import { transfersView } from './transfers.js';
import { stockView } from './stock.js';
import { shiftsView } from './shifts.js';
import { expensesView } from './expenses.js';
import { reportsView } from './reports.js';
import { settingsView } from './settings.js';

const VIEWS = { sell: sellView, sales: salesView, overview: overviewView, transfers: transfersView, stock: stockView, shifts: shiftsView, expenses: expensesView, reports: reportsView, settings: settingsView };
const TAB_HUE = { sell: 1, sales: 2, overview: 5, transfers: 6, stock: 4, shifts: 7, expenses: 3, reports: 5, settings: 7 };
const ERR = {};                      // last load error, by tab
let loadSeq = 0, stopLive = null, liveT = null, everLive = false, lastFocus = null;

/* ---------- frame ---------- */
const initials = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const tabsOf = () => ROLES[S.user.role].tabs;

function navBtn(t, bottom) {
  const on = S.tab === t, n = t === 'transfers' && S.pending > 0 && (S.user.role === 'supervisor' || S.user.role === 'gm') ? S.pending : 0;
  return '<button class="nv' + (on ? ' on' : '') + '" style="' + hueVars(TAB_HUE[t] || 1) + '" data-act="go" data-v="' + t + '"' + (on ? ' aria-current="page"' : '') + '>' +
    '<span class="nv-i">' + ic(TABS[t][1], bottom ? 22 : 20) + (n ? '<em class="badge" aria-label="' + n + ' waiting">' + n + '</em>' : '') + '</span><span class="nv-l">' + TABS[t][0] + '</span></button>';
}
const sideNav = () => tabsOf().map(t => navBtn(t, false)).join('');
function botNav() {
  const tabs = tabsOf(), few = tabs.length <= 5, shown = few ? tabs : tabs.slice(0, 4), hidden = few ? [] : tabs.slice(4);
  return shown.map(t => navBtn(t, true)).join('') + (hidden.length ? '<button class="nv' + (hidden.includes(S.tab) ? ' on' : '') + '" style="' + hueVars(7) + '" data-act="more"><span class="nv-i">' + ic('grid', 22) +
    (S.pending > 0 && hidden.includes('transfers') ? '<em class="badge">' + S.pending + '</em>' : '') + '</span><span class="nv-l">More</span></button>' : '');
}
const liveHtml = () => '<span class="live' + (S.live ? ' on' : '') + '" title="' + (S.live ? 'Live: updates appear instantly' : 'Reconnecting…') + '"><i></i><em>' + (S.live ? 'Live' : 'Offline') + '</em></span>';

function shellHtml() {
  const u = S.user, multi = !u.branch;
  return '<div class="shell' + (S.enter ? ' enter' : '') + '">' +
    '<header class="top"><span class="mk" aria-hidden="true">FFC</span><div class="who"><b>' + esc(biz().name) + '</b><span>' + (multi ? 'All branches' : esc(branchName(u.branch))) + '</span></div>' +
    '<span id="live-w"></span><button class="ib" data-act="theme" aria-label="Switch light or dark mode">' + ic('moon', 20) + '</button>' +
    '<button class="avatar" data-act="account" aria-label="Your account">' + esc(initials(u.name)) + '</button></header>' +
    '<nav id="nav-side" class="side" aria-label="Sections"></nav><main id="main" tabindex="-1"></main><nav id="nav-bot" class="bot" aria-label="Sections"></nav></div>';
}

function keepFocus() {
  const a = document.activeElement, m = $('#main');
  if (!a || !m || !m.contains(a) || !/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return null;
  const sel = a.dataset.f ? '[data-f="' + a.dataset.f + '"]' : a.id ? '#' + a.id : null; if (!sel) return null;
  let s = null, e = null; try { s = a.selectionStart; e = a.selectionEnd; } catch (x) { /* number inputs */ }
  return { sel, s, e };
}
function restoreFocus(k) {
  if (!k) return; const el = $(k.sel, $('#main')); if (!el) return;
  el.focus({ preventScroll: true }); try { if (k.s != null) el.setSelectionRange(k.s, k.e); } catch (x) { /* ignore */ }
}

function errorView(msg) {
  return empty('😕', 'This screen could not load', esc(msg), '<button class="btn primary" data-act="retry">Try again</button>');
}

export function render() {
  if (!S.ready) return;
  const root = $('#app');
  if (!S.user) { root.dataset.mode = 'login'; root.innerHTML = loginView(); return; }
  if (root.dataset.mode !== 'shell') { root.dataset.mode = 'shell'; root.innerHTML = shellHtml(); }
  $('#live-w').innerHTML = liveHtml(); $('#nav-side').innerHTML = sideNav(); $('#nav-bot').innerHTML = botNav();
  const main = $('#main'), t = S.tab, k = keepFocus();
  main.className = S.enter ? 'rise' : '';
  main.innerHTML = ERR[t] ? errorView(ERR[t]) : (loaders[t] && !D[t] ? loadingView() : VIEWS[t]());
  restoreFocus(k);
  if (S.enter) { countUp(main); S.enter = false; document.title = TABS[t][0] + ' · ' + biz().name; }
}

/* ---------- data ---------- */
async function loadTab() {
  const t = S.tab, f = loaders[t], seq = ++loadSeq;
  if (!f) { render(); return; }
  try { await f(); delete ERR[t]; } catch (e) { if (seq !== loadSeq || !S.user) return; ERR[t] = e.message; }
  if (seq === loadSeq && t === S.tab && S.user) { S.enter = S.enter || !S.dataSeen[t]; S.dataSeen[t] = true; render(); }
}
S.dataSeen = {};

async function refreshConfig() {
  const r = await api('GET', '/api/bootstrap');
  S.user = r.user; S.config = r.config; S.pending = r.pending; setLocale(biz().currency, biz().timezone); buildHues();
  if (!tabsOf().includes(S.tab)) S.tab = tabsOf()[0];
}

hooks.render = render;
hooks.reload = loadTab;
hooks.go = t => {
  if (!S.user || !tabsOf().includes(t)) return;
  S.tab = t; S.enter = true; S.pop = null; LS.set('ffc:tab:' + S.user.id, t);
  window.scrollTo(0, 0); render(); loadTab();
};
hooks.refreshBadges = async () => {
  try {
    const before = S.pending, r = await api('GET', '/api/badges'); S.pending = r.pending;
    if (r.pending > before && (S.user.role === 'supervisor' || S.user.role === 'gm')) toast('A stock transfer is waiting for your approval.');
    if (S.user) { $('#nav-side').innerHTML = sideNav(); $('#nav-bot').innerHTML = botNav(); }
  } catch (e) { /* ignore */ }
};

/* ---------- modal ---------- */
hooks.openModal = m => {
  Object.keys(F).forEach(k => { if (k.startsWith('m.')) delete F[k]; });
  if (m.f) Object.assign(F, m.f);
  lastFocus = document.activeElement; S.modal = m; renderModal();
};
hooks.closeModal = () => {
  S.modal = null; Object.keys(F).forEach(k => { if (k.startsWith('m.')) delete F[k]; });
  renderModal(); if (lastFocus && lastFocus.isConnected) { try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* ignore */ } } lastFocus = null;
};
function renderModal() {
  const host = $('#modal'), m = S.modal;
  if (!m) { host.innerHTML = ''; document.body.classList.remove('lock'); return; }
  const v = modalViews[m.type]; if (!v) { S.modal = null; return; }
  const scroll = $('.sh-body', host), st = scroll ? scroll.scrollTop : 0, again = host.firstChild && host.dataset.type === m.type;
  const a = document.activeElement; let keep = null;
  if (again && a && host.contains(a) && a.dataset && a.dataset.f) { keep = { sel: '[data-f="' + a.dataset.f + '"]' }; try { keep.s = a.selectionStart; keep.e = a.selectionEnd; } catch (x) { /* ignore */ } }
  host.dataset.type = m.type;
  host.innerHTML = '<div class="scrim' + (again ? ' again' : '') + '" data-scrim="1"><div class="sheet ' + (m.cls || '') + '" role="dialog" aria-modal="true" tabindex="-1">' + v(m) + '</div></div>';
  document.body.classList.add('lock');
  const sh = $('.sheet', host), s2 = $('.sh-body', host); if (s2 && again) s2.scrollTop = st;
  const kel = keep && $(keep.sel, host);
  if (kel) { kel.focus({ preventScroll: true }); try { if (keep.s != null) kel.setSelectionRange(keep.s, keep.e); } catch (x) { /* ignore */ } }
  else { const af = $('[data-autofocus]', host); (af || sh).focus({ preventScroll: true }); }
}
hooks.renderModal = renderModal;

/* ---------- session ---------- */
async function showLogin() {
  S.user = null; S.config = null; S.ready = true; S.pin = ''; S.loginRole = null; S.loginIntro = true; S.modal = null; renderModal();
  try { const r = await api('GET', '/api/public/roster'); S.roster = r.users; S.bizName = r.business.name; } catch (e) { S.roster = []; toast(e.message, 'err'); }
  document.title = 'Sign in · ' + (S.bizName || 'FFC Eatery POS'); render();
}

function localSignOut() {
  if (stopLive) { stopLive(); stopLive = null; } everLive = false; S.live = false; setToken(''); resetFilters(); S.dataSeen = {}; Object.keys(ERR).forEach(k => delete ERR[k]);
  const root = $('#app'); root.dataset.mode = ''; return showLogin();
}

hooks.startSession = async () => {
  await refreshConfig(); S.ready = true; resetFilters(); S.dataSeen = {};
  const saved = LS.get('ffc:tab:' + S.user.id); S.tab = tabsOf().includes(saved) ? saved : tabsOf()[0]; S.enter = true; S.live = false;
  if (stopLive) stopLive();
  everLive = false;
  stopLive = openStream(ev => onLive(ev), on => {
    S.live = on; const w = $('#live-w'); if (w) w.innerHTML = liveHtml();
    if (on) { if (everLive) { loadTab(); hooks.refreshBadges(); } everLive = true; }
  });
  $('#app').dataset.mode = ''; render(); loadTab();
  if (S.user.startPin) hooks.openModal({ type: 'account', force: true });
};

function onLive(ev) {
  clearTimeout(liveT);
  liveT = setTimeout(async () => {
    if (!S.user) return;
    hooks.refreshBadges();
    if (ev.type === 'config') { try { await refreshConfig(); } catch (e) { return; } }
    loadTab();
  }, 350);
}

setUnauthorizedHandler(() => { if (!S.user) return; toast('You were signed out. Please sign in again.'); localSignOut(); });

/* ---------- account, more, theme ---------- */
const effectiveDark = () => { const t = document.documentElement.getAttribute('data-theme'); return t ? t === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches; };
function setTheme(t) { document.documentElement.setAttribute('data-theme', t); try { localStorage.setItem('ffc:theme', t); } catch (e) { /* ignore */ } }

modalViews.account = m => {
  const u = S.user, R = ROLES[u.role];
  return sheetHead(u.name, esc(R.label) + (u.branch ? ' · ' + esc(branchName(u.branch)) : ' · All branches')) +
    '<div class="sh-body scroll">' +
    (u.startPin ? '<div class="note warn">You are using a starter PIN. Choose your own PIN now so only you can sign in as you.</div>' : '') +
    '<h3 class="sub">Change your PIN</h3><div class="grid2">' +
    field('Current PIN', '<input type="password" inputmode="numeric" autocomplete="current-password" maxlength="6" data-f="m.cur" value="' + esc(fv('m.cur')) + '">') +
    field('New PIN (4 to 6 digits)', '<input type="password" inputmode="numeric" autocomplete="new-password" maxlength="6" data-f="m.next" value="' + esc(fv('m.next')) + '">') + '</div>' +
    field('Type the new PIN again', '<input type="password" inputmode="numeric" autocomplete="new-password" maxlength="6" data-f="m.next2" data-enter="save-pin" value="' + esc(fv('m.next2')) + '">') +
    '<button class="btn primary" data-act="save-pin">Save new PIN</button>' +
    '<h3 class="sub">Appearance</h3>' + seg([['auto', 'Automatic'], ['light', 'Light'], ['dark', 'Dark']], document.documentElement.getAttribute('data-theme') || 'auto', 'set-theme', 'Colour mode') +
    '</div><div class="sh-foot">' + (m.force ? '<button class="btn" data-act="close">Later</button>' : '<button class="btn" data-act="close">Close</button>') + '<button class="btn danger" data-act="signout">Sign out</button></div>';
};
modalViews.more = () => sheetHead('More') + '<div class="sh-body"><div class="more">' +
  tabsOf().slice(4).map(t => '<button class="nv-big' + (S.tab === t ? ' on' : '') + '" style="' + hueVars(TAB_HUE[t] || 1) + '" data-act="go-close" data-v="' + t + '"><span>' + ic(TABS[t][1], 26) + '</span><b>' + TABS[t][0] + '</b>' +
    (t === 'transfers' && S.pending ? '<em class="badge">' + S.pending + '</em>' : '') + '</button>').join('') + '</div></div>';

actions.go = el => hooks.go(el.dataset.v);
actions['go-close'] = el => { hooks.closeModal(); hooks.go(el.dataset.v); };
actions.more = () => hooks.openModal({ type: 'more', cls: 'low' });
actions.account = () => hooks.openModal({ type: 'account' });
actions.close = () => hooks.closeModal();
actions.retry = () => { delete ERR[S.tab]; render(); loadTab(); };
actions.theme = () => { setTheme(effectiveDark() ? 'light' : 'dark'); };
actions['set-theme'] = el => {
  if (el.dataset.v === 'auto') { document.documentElement.removeAttribute('data-theme'); try { localStorage.removeItem('ffc:theme'); } catch (e) { /* ignore */ } } else setTheme(el.dataset.v);
  renderModal();
};
actions['save-pin'] = el => run(el, async () => {
  const cur = fv('m.cur'), n1 = fv('m.next'), n2 = fv('m.next2');
  if (!/^\d{4,6}$/.test(n1)) throw new Error('New PIN must be 4 to 6 digits.');
  if (n1 !== n2) throw new Error('The two new PINs do not match.');
  await api('POST', '/api/me/pin', { current: cur, next: n1 }); S.user.startPin = false; hooks.closeModal(); toast('Your PIN has been changed.', 'ok');
});
actions.signout = async () => { try { await api('POST', '/api/logout'); } catch (e) { /* ignore */ } S.modal = null; renderModal(); await localSignOut(); };

/* ---------- events ---------- */
document.addEventListener('click', e => {
  if (e.target.dataset && e.target.dataset.scrim && S.modal && !S.modal.force) { hooks.closeModal(); return; }
  const el = e.target.closest('[data-act]'); if (!el || el.disabled) return;
  const f = actions[el.dataset.act]; if (f) f(el, e);
});
function syncField(el) { const k = el.dataset.f; if (!k) return; F[k] = el.type === 'checkbox' ? el.checked : el.value; }
document.addEventListener('input', e => {
  syncField(e.target);
  const el = e.target.closest('[data-input]'); if (el && actions[el.dataset.input]) actions[el.dataset.input](el, e);
});
document.addEventListener('change', e => {
  syncField(e.target);
  const el = e.target.closest('[data-change]'); if (el && actions[el.dataset.change]) actions[el.dataset.change](el, e);
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && S.modal && !S.modal.force) { hooks.closeModal(); return; }
  if (e.key === 'Tab' && S.modal) {
    const sh = $('.sheet'); if (!sh) return;
    const f = $$('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex="0"]', sh).filter(x => x.offsetParent !== null);
    if (!f.length) return;
    if (e.shiftKey && (document.activeElement === f[0] || document.activeElement === sh)) { e.preventDefault(); f[f.length - 1].focus(); }
    else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    return;
  }
  const t = e.target;
  if (e.key === 'Enter' && t.dataset && t.dataset.enter && actions[t.dataset.enter]) { e.preventDefault(); actions[t.dataset.enter](t, e); return; }
  if (S.ready && !S.user && !S.modal && !/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) && S.loginRole && !e.ctrlKey && !e.metaKey && !e.altKey) {
    if (/^\d$/.test(e.key)) pinKey(e.key); else if (e.key === 'Backspace') pinKey('del'); else if (e.key === 'Enter' && t.tagName !== 'BUTTON') doLogin();
  }
});
document.addEventListener('visibilitychange', () => { if (!document.hidden && S.user) { hooks.refreshBadges(); loadTab(); } });
window.addEventListener('online', () => { if (S.user) loadTab(); });

/* ---------- start ---------- */
(async function boot() {
  if (hasToken()) {
    try { await hooks.startSession(); return; } catch (e) { setToken(''); }
  }
  await showLogin();
})();
