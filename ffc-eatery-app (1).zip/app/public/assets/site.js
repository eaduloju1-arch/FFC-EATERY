const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = s => document.querySelector(s);

async function main() {
  let data;
  try {
    const r = await fetch('/api/public/menu', { cache: 'no-store' });
    if (!r.ok) throw new Error('bad');
    data = await r.json();
  } catch (e) {
    $('#menu-body').innerHTML = '<div class="s-msg">The menu is not available right now. Please check back soon.</div>';
    return;
  }
  const cur = data.business.currency || '';
  const money = n => cur + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
  $('#biz-name').textContent = data.business.name.replace(/^FFC\s*/i, '') || 'Eatery';
  $('#foot-name').textContent = data.business.name;
  document.title = data.business.name;

  const cats = [];
  data.items.forEach(i => { if (!cats.includes(i.category)) cats.push(i.category); });
  const hue = c => (cats.indexOf(c) % 7) + 1;
  const hv = h => `--c:var(--h${h});--ct:var(--h${h}t);--cd:var(--h${h}d)`;

  $('#stickers').innerHTML = data.items.filter(i => i.emoji).slice(0, 6).map((i, k) =>
    `<div class="sticker" style="${hv(hue(i.category))};--i:${k}"><span class="e">${esc(i.emoji)}</span><b>${esc(i.name)}</b><span>${money(i.price)}</span></div>`).join('');

  $('#menu-body').innerHTML = cats.length ? cats.map(c => {
    const list = data.items.filter(i => i.category === c);
    return `<div class="cat" style="${hv(hue(c))}"><div class="cat-head"><h3>${esc(c)}</h3><i></i></div><div class="dishes">` +
      list.map(i => `<div class="dish"><span class="e" aria-hidden="true">${esc(i.emoji || '🍽️')}</span><div><b>${esc(i.name)}</b><small>per ${esc(i.unit)}</small></div><span class="p">${money(i.price)}</span></div>`).join('') +
      '</div></div>';
  }).join('') : '<div class="s-msg">The menu is being updated. Please check back soon.</div>';

  $('#branch-body').innerHTML = data.branches.map((b, k) => `<div class="branch" style="--c:var(--h${(k % 7) + 1})"><i></i>${esc(b.name)}</div>`).join('');
}
main();
