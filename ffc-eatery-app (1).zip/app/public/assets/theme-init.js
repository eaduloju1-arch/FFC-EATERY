(function () { try { var t = localStorage.getItem('ffc:theme'); if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t); } catch (e) { /* ignore */ } })();
