'use strict';
/*
  FFC Eatery POS server
  - Zero dependencies. Needs Node 18 or newer.
  - Serves the website at / and the POS web app at /app/
  - JSON API under /api: PIN sign-in, role checks, sales, stock, transfers, reports
  - Live updates to every signed-in device over server-sent events
  - Data lives in JSON files inside DATA_DIR (config.json + one file per month)
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

/* ------------------------------------------------------------------ settings */
const PORT = parseInt(process.env.PORT, 10) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const PUBLIC_DIR = path.join(__dirname, 'public');
const TRUST_PROXY = /^(1|true|yes)$/i.test(process.env.TRUST_PROXY || '');
const SEED_DEMO = !/^(0|false|no)$/i.test(process.env.SEED_DEMO || '1');
const SESSION_MS = 12 * 3600 * 1000;
const CFG_FILE = path.join(DATA_DIR, 'config.json');
const MONTH_DIR = path.join(DATA_DIR, 'months');
const COLS = ['sales', 'expenses', 'restocks', 'adjustments', 'transfers', 'shifts', 'audit'];
const EXP_CATS = ['Food supplies', 'Gas and fuel', 'Utilities', 'Wages and allowances', 'Transport', 'Repairs', 'Packaging', 'Rent', 'Other'];
const ADJ_REASONS = ['Wastage', 'Spoiled', 'Damaged', 'Staff meal', 'Recount'];
const ROLE_LIST = ['sales', 'supervisor', 'procurement', 'gm'];
const ORDER_TYPES = ['dine-in', 'takeaway', 'delivery'];

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = m => new HttpError(400, m);

/* ------------------------------------------------------------------ helpers */
const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const pad = n => String(n).padStart(2, '0');
const uid = () => Date.now().toString(36) + crypto.randomBytes(4).toString('hex');
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);
const int = v => { const n = Number(v); return Number.isFinite(n) && Math.floor(n) === n ? n : NaN; };
const isYmd = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s + 'T00:00:00Z'));
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const dayDiff = (a, b) => Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5);
const weekStart = s => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7)); return d.toISOString().slice(0, 10); };
const monthRange = s => { const [y, m] = s.split('-').map(Number); return [y + '-' + pad(m) + '-01', y + '-' + pad(m) + '-' + pad(new Date(Date.UTC(y, m, 0)).getUTCDate())]; };
const fmtCache = {};
function localParts(d, tz) {
  const f = fmtCache[tz] || (fmtCache[tz] = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' }));
  const p = {}; for (const x of f.formatToParts(d)) p[x.type] = x.value;
  return { date: p.year + '-' + p.month + '-' + p.day, hour: (+p.hour) % 24 };
}
const validTz = tz => { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return true; } catch (e) { return false; } };
const hashPin = pin => { const salt = crypto.randomBytes(16).toString('hex'); return { salt, hash: crypto.scryptSync(pin, salt, 32).toString('hex') }; };
const checkPin = (pin, rec) => { try { return crypto.timingSafeEqual(crypto.scryptSync(pin, rec.salt, 32), Buffer.from(rec.hash, 'hex')); } catch (e) { return false; } };
const okPin = p => /^\d{4,6}$/.test(p);

/* ------------------------------------------------------------------ data store */
let CFG = null;
const MONTHS = {};
const IDX = { sales: new Map(), expenses: new Map(), transfers: new Map(), shifts: new Map() };
const dirty = new Set();
let flushTimer = null;

function seedConfig() {
  const items = [
    ['Jollof rice', 'Meals', 1500, 'plate', '🍛'], ['Fried rice', 'Meals', 1500, 'plate', '🍚'], ['Grilled chicken', 'Meals', 2500, 'piece', '🍗'],
    ['Beef stew and rice', 'Meals', 1800, 'plate', '🥘'], ['Meat pie', 'Snacks', 800, 'piece', '🥧'], ['Chicken shawarma', 'Snacks', 2500, 'piece', '🌯'],
    ['Puff-puff', 'Snacks', 500, 'pack', '🍩'], ['Zobo', 'Drinks', 600, 'bottle', '🍹'], ['Bottled water', 'Drinks', 300, 'bottle', '💧'], ['Soft drink', 'Drinks', 500, 'bottle', '🥤']
  ].map((a, i) => ({ id: 'i' + (i + 1), name: a[0], category: a[1], price: a[2], unit: a[3], emoji: a[4], reorder: a[0] === 'Bottled water' ? 10 : 5, active: true }));
  const cfg = {
    version: 1,
    business: { name: 'FFC Eatery', currency: '₦', timezone: process.env.BUSINESS_TZ || 'Africa/Lagos', vatRate: 0, vatInclusive: true, maxDiscountPct: 10, receiptFooter: 'Thank you for eating at FFC', requireShift: false },
    branches: [{ id: 'b1', name: 'Main Branch', code: 'MB' }, { id: 'b2', name: 'Second Branch', code: 'SB' }],
    items, users: [], stock: { b1: {}, b2: {} }, seq: {}, sessions: {}
  };
  const adminPin = okPin(process.env.ADMIN_PIN || '') ? process.env.ADMIN_PIN : (SEED_DEMO ? '1000' : String(crypto.randomInt(100000, 999999)));
  const defs = SEED_DEMO
    ? [['u_gm', 'Amaka (General Manager)', 'gm', null, adminPin], ['u_proc', 'Tunde (Procurement)', 'procurement', null, '2000'],
       ['u_sup1', 'Ngozi (Supervisor, Main)', 'supervisor', 'b1', '3000'], ['u_sup2', 'Ibrahim (Supervisor, Second)', 'supervisor', 'b2', '3001'],
       ['u_sp1', 'Chidi (Sales, Main)', 'sales', 'b1', '4000'], ['u_sp2', 'Bola (Sales, Second)', 'sales', 'b2', '4001']]
    : [['u_gm', 'General Manager', 'gm', null, adminPin]];
  for (const d of defs) cfg.users.push({ id: d[0], name: d[1], role: d[2], branch: d[3], pin: hashPin(d[4]), startPin: SEED_DEMO && !(d[0] === 'u_gm' && process.env.ADMIN_PIN), active: true });
  if (SEED_DEMO) { items.forEach(i => { cfg.stock.b1[i.id] = 40; cfg.stock.b2[i.id] = i.id === 'i8' ? 0 : 20; }); }
  console.log('\n  First start: created starting accounts.');
  defs.forEach(d => console.log('    ' + d[1].padEnd(32) + ' PIN ' + d[4]));
  console.log('  Change these PINs from Settings > Staff after you sign in.\n');
  return cfg;
}

function bucket(k) { return MONTHS[k] || (MONTHS[k] = Object.fromEntries(COLS.map(c => [c, []]))); }
function loadAll() {
  fs.mkdirSync(MONTH_DIR, { recursive: true });
  if (fs.existsSync(CFG_FILE)) CFG = JSON.parse(fs.readFileSync(CFG_FILE, 'utf8'));
  else { CFG = seedConfig(); fs.writeFileSync(CFG_FILE, JSON.stringify(CFG)); }
  CFG.sessions = CFG.sessions || {}; CFG.seq = CFG.seq || {}; CFG.stock = CFG.stock || {};
  for (const f of fs.readdirSync(MONTH_DIR)) {
    const m = /^(\d{4}-\d{2})\.json$/.exec(f); if (!m) continue;
    const d = JSON.parse(fs.readFileSync(path.join(MONTH_DIR, f), 'utf8')), b = bucket(m[1]);
    for (const c of COLS) b[c] = Array.isArray(d[c]) ? d[c] : [];
    for (const c of Object.keys(IDX)) b[c].forEach(r => IDX[c].set(r.id, r));
  }
}
function markDirty(k) { dirty.add(k); if (!flushTimer) flushTimer = setTimeout(flush, 250); }
function writeAtomic(file, obj) { const tmp = file + '.' + process.pid + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(obj)); fs.renameSync(tmp, file); }
function flush() {
  flushTimer = null;
  for (const k of dirty) {
    try { if (k === 'cfg') writeAtomic(CFG_FILE, CFG); else writeAtomic(path.join(MONTH_DIR, k + '.json'), MONTHS[k]); }
    catch (e) { console.error('Could not save ' + k + ':', e.message); }
  }
  dirty.clear();
}
const saveCfg = () => markDirty('cfg');
function put(col, rec) { bucket(rec.date.slice(0, 7))[col].push(rec); if (IDX[col]) IDX[col].set(rec.id, rec); markDirty(rec.date.slice(0, 7)); return rec; }
const touch = rec => markDirty(rec.date.slice(0, 7));
function rangeOf(col, from, to) {
  const out = [], a = from.slice(0, 7), z = to.slice(0, 7);
  for (const k of Object.keys(MONTHS).sort()) { if (k < a || k > z) continue; for (const r of MONTHS[k][col]) if (r.date >= from && r.date <= to) out.push(r); }
  return out;
}

/* ------------------------------------------------------------------ domain helpers */
const biz = () => CFG.business;
const today = () => localParts(new Date(), biz().timezone).date;
const itemById = id => CFG.items.find(i => i.id === id);
const branchById = id => CFG.branches.find(b => b.id === id);
const stockOf = (b, i) => ((CFG.stock[b] || {})[i]) || 0;
const bump = (b, i, d) => { const s = CFG.stock[b] || (CFG.stock[b] = {}); s[i] = (s[i] || 0) + d; };
const pubUser = u => ({ id: u.id, name: u.name, role: u.role, branch: u.branch || null, active: u.active !== false, startPin: !!u.startPin });
const pubItem = i => ({ id: i.id, name: i.name, category: i.category, price: i.price, unit: i.unit, emoji: i.emoji || '' });
const visibleBranches = u => (u.role === 'sales' || u.role === 'supervisor') ? [u.branch] : CFG.branches.map(b => b.id);
function scopeBranches(u, req) {
  const vis = visibleBranches(u);
  if (!req || req === 'all') return vis;
  if (!vis.includes(req)) throw new HttpError(403, 'You cannot view that branch.');
  return [req];
}
function reservedOut() {
  const m = {};
  for (const t of IDX.transfers.values()) if (t.status === 'pending') for (const l of t.lines) { const k = t.from + '|' + l.itemId; m[k] = (m[k] || 0) + l.qty; }
  return m;
}
function audit(u, action, detail) {
  const now = new Date();
  put('audit', { id: uid(), at: now.toISOString(), date: localParts(now, biz().timezone).date, by: u ? u.id : '', byName: u ? u.name : '', role: u ? u.role : '', action, detail: str(detail, 200) });
}
function calcTotals(subtotal, discount) {
  const b = biz(); let disc = 0;
  if (discount && discount.value > 0) disc = discount.type === 'pct' ? r2(subtotal * Math.min(discount.value, 100) / 100) : Math.min(r2(discount.value), subtotal);
  const taxable = r2(subtotal - disc), rate = Number(b.vatRate) || 0;
  let vat = 0, total = taxable;
  if (rate > 0) { if (b.vatInclusive) vat = r2(taxable - taxable / (1 + rate / 100)); else { vat = r2(taxable * rate / 100); total = r2(taxable + vat); } }
  return { subtotal: r2(subtotal), discount: disc, vat, total };
}
function lowStock(bs) {
  const out = [];
  for (const b of bs) for (const it of CFG.items) {
    if (it.active === false) continue;
    const q = stockOf(b, it.id), lvl = it.reorder == null ? 5 : it.reorder;
    if (q <= lvl) out.push({ branch: b, itemId: it.id, qty: q, reorder: lvl });
  }
  return out.sort((a, b) => a.qty - b.qty);
}
function openShiftOf(userId) { for (const s of IDX.shifts.values()) if (!s.closedAt && s.by === userId) return s; return null; }
function shiftFigures(sh) {
  let cash = 0, total = 0, count = 0;
  for (const s of rangeOf('sales', sh.date, addDays(today(), 1))) {
    if (s.by !== sh.by || s.voided || s.at < sh.openedAt || (sh.closedAt && s.at > sh.closedAt)) continue;
    cash += s.cash || 0; total += s.total; count++;
  }
  return { cashSales: r2(cash), totalSales: r2(total), count, expected: r2(sh.float + cash) };
}
function pendingFor(u) {
  let n = 0;
  for (const t of IDX.transfers.values()) if (t.status === 'pending' && (u.role === 'gm' || (u.role === 'supervisor' && u.branch === t.to))) n++;
  return n;
}

function aggregate(from, to, bs) {
  if (dayDiff(from, to) > 400 || dayDiff(from, to) < 0) throw bad('Choose a date range of up to 400 days.');
  const bset = new Set(bs);
  const sales = rangeOf('sales', from, to).filter(s => bset.has(s.branch));
  const exps = rangeOf('expenses', from, to).filter(e => !e.deleted && bset.has(e.branch));
  const adjs = rangeOf('adjustments', from, to).filter(a => bset.has(a.branch) && a.delta < 0 && a.reason !== 'Recount');
  const A = { from, to, sales: { total: 0, cash: 0, transfer: 0, card: 0, count: 0, discount: 0, vat: 0, avg: 0 }, voided: { count: 0, total: 0 }, expenses: { total: 0, count: exps.length }, net: 0 };
  const days = new Map(); for (let d = from; d <= to; d = addDays(d, 1)) days.set(d, { date: d, sales: 0, cash: 0, transfer: 0, card: 0, expenses: 0, count: 0 });
  const top = new Map(), cats = new Map(), staff = new Map(), types = new Map(), branches = new Map(), expCats = new Map();
  const hours = Array.from({ length: 24 }, () => ({ revenue: 0, count: 0 }));
  bs.forEach(b => branches.set(b, { branch: b, sales: 0, count: 0, expenses: 0 }));
  for (const s of sales) {
    if (s.voided) { A.voided.count++; A.voided.total += s.total; continue; }
    const S = A.sales; S.total += s.total; S.cash += s.cash || 0; S.transfer += s.transfer || 0; S.card += s.card || 0; S.count++; S.discount += s.discountAmt || 0; S.vat += s.vat || 0;
    const d = days.get(s.date); if (d) { d.sales += s.total; d.cash += s.cash || 0; d.transfer += s.transfer || 0; d.card += s.card || 0; d.count++; }
    const h = hours[s.hour == null ? 0 : s.hour]; h.revenue += s.total; h.count++;
    const st = staff.get(s.by) || { id: s.by, name: s.byName, count: 0, total: 0 }; st.count++; st.total += s.total; staff.set(s.by, st);
    const ty = types.get(s.orderType || 'dine-in') || { type: s.orderType || 'dine-in', count: 0, total: 0 }; ty.count++; ty.total += s.total; types.set(ty.type, ty);
    const br = branches.get(s.branch); if (br) { br.sales += s.total; br.count++; }
    for (const l of s.lines) {
      const rev = l.price * l.qty;
      const t = top.get(l.itemId) || { itemId: l.itemId, name: l.name, qty: 0, revenue: 0 }; t.qty += l.qty; t.revenue += rev; top.set(l.itemId, t);
      const c = cats.get(l.category || 'Other') || { name: l.category || 'Other', revenue: 0, qty: 0 }; c.revenue += rev; c.qty += l.qty; cats.set(c.name, c);
    }
  }
  for (const e of exps) {
    A.expenses.total += e.amount;
    const d = days.get(e.date); if (d) d.expenses += e.amount;
    expCats.set(e.category, (expCats.get(e.category) || 0) + e.amount);
    const br = branches.get(e.branch); if (br) br.expenses += e.amount;
  }
  const wast = new Map(); let wq = 0;
  for (const a of adjs) { wq += -a.delta; const it = itemById(a.itemId); const k = it ? it.name : 'Removed item'; wast.set(k, (wast.get(k) || 0) + -a.delta); }
  A.sales.avg = A.sales.count ? r2(A.sales.total / A.sales.count) : 0;
  ['total', 'cash', 'transfer', 'card', 'discount', 'vat'].forEach(k => A.sales[k] = r2(A.sales[k]));
  A.voided.total = r2(A.voided.total); A.expenses.total = r2(A.expenses.total); A.net = r2(A.sales.total - A.expenses.total);
  const rr = o => { for (const k of Object.keys(o)) if (typeof o[k] === 'number' && k !== 'count' && k !== 'qty' && k !== 'hour') o[k] = r2(o[k]); return o; };
  A.byDay = [...days.values()].map(d => { rr(d); d.net = r2(d.sales - d.expenses); return d; });
  A.byBranch = [...branches.values()].map(rr);
  A.byCategory = [...cats.values()].map(rr).sort((a, b) => b.revenue - a.revenue);
  A.topItems = [...top.values()].map(rr).sort((a, b) => b.qty - a.qty).slice(0, 10);
  A.byHour = hours.map(h => ({ revenue: r2(h.revenue), count: h.count }));
  A.byStaff = [...staff.values()].map(rr).sort((a, b) => b.total - a.total);
  A.byType = [...types.values()].map(rr).sort((a, b) => b.total - a.total);
  A.expByCat = [...expCats.entries()].map(([name, total]) => ({ name, total: r2(total) })).sort((a, b) => b.total - a.total);
  A.wastage = { qty: wq, items: [...wast.entries()].map(([name, qty]) => ({ name, qty })).sort((a, b) => b.qty - a.qty).slice(0, 8) };
  return A;
}
const clientConfig = u => ({
  business: CFG.business, branches: CFG.branches, items: CFG.items, expenseCategories: EXP_CATS, adjustReasons: ADJ_REASONS,
  users: u.role === 'gm' ? CFG.users.map(pubUser) : undefined
});

/* ------------------------------------------------------------------ sessions, rate limits, live updates */
function newSession(userId) { const tok = crypto.randomBytes(24).toString('base64url'); CFG.sessions[sha256(tok)] = { uid: userId, exp: Date.now() + SESSION_MS }; saveCfg(); return tok; }
function revokeUser(userId) { for (const k of Object.keys(CFG.sessions)) if (CFG.sessions[k].uid === userId) delete CFG.sessions[k]; saveCfg(); }
function sessionUser(req) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || ''); if (!m) return null;
  const k = sha256(m[1]), s = CFG.sessions[k]; if (!s) return null;
  if (s.exp < Date.now()) { delete CFG.sessions[k]; saveCfg(); return null; }
  const u = CFG.users.find(x => x.id === s.uid && x.active !== false); if (!u) return null;
  if (s.exp - Date.now() < SESSION_MS / 2) { s.exp = Date.now() + SESSION_MS; saveCfg(); }
  req._tokKey = k; return u;
}
const fails = new Map();
const lockLeft = k => { const f = fails.get(k); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; };
function noteFail(k, max) { const f = fails.get(k) || { n: 0, until: 0 }; if (f.until && f.until < Date.now()) { f.n = 0; f.until = 0; } f.n++; if (f.n >= max) { f.until = Date.now() + 300000; f.n = 0; } fails.set(k, f); }
const clients = new Set();
function broadcast(type) { const msg = 'event: change\ndata: ' + JSON.stringify({ type }) + '\n\n'; for (const c of clients) { try { c.write(msg); } catch (e) { clients.delete(c); } } }

/* ------------------------------------------------------------------ API routes */
const routes = [];
function route(method, p, roles, fn) {
  const keys = []; const re = new RegExp('^' + p.replace(/:([a-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, roles, fn });
}
const STAFF_SALES = ['sales', 'supervisor'];

/* --- public --- */
route('GET', '/api/public/menu', null, () => ({
  business: { name: biz().name, currency: biz().currency },
  branches: CFG.branches.map(b => ({ id: b.id, name: b.name })),
  items: CFG.items.filter(i => i.active !== false).map(pubItem)
}));
route('GET', '/api/public/roster', null, () => ({ users: CFG.users.filter(u => u.active !== false).map(u => ({ id: u.id, name: u.name, role: u.role })), business: { name: biz().name } }));

/* --- auth --- */
route('POST', '/api/login', null, ({ body, ip }) => {
  const id = str(body.userId, 60), pin = str(body.pin, 12);
  const lk = Math.max(lockLeft('u:' + id), lockLeft('ip:' + ip));
  if (lk) throw new HttpError(429, 'Too many attempts. Try again in ' + Math.ceil(lk / 60) + ' min.');
  const u = CFG.users.find(x => x.id === id && x.active !== false);
  if (!u || !checkPin(pin, u.pin)) {
    noteFail('u:' + id, 5); noteFail('ip:' + ip, 30);
    if (u) audit(u, 'login-failed', 'Wrong PIN');
    throw new HttpError(401, 'Wrong PIN. Try again.');
  }
  fails.delete('u:' + id);
  const token = newSession(u.id); audit(u, 'login', '');
  return { token, user: pubUser(u) };
});
route('POST', '/api/logout', 'any', ({ req }) => { if (req._tokKey) { delete CFG.sessions[req._tokKey]; saveCfg(); } return { ok: true }; });
route('GET', '/api/bootstrap', 'any', ({ user }) => ({ user: pubUser(user), config: clientConfig(user), today: today(), pending: pendingFor(user) }));
route('GET', '/api/badges', 'any', ({ user }) => ({ pending: pendingFor(user) }));
route('POST', '/api/me/pin', 'any', ({ user, body }) => {
  const cur = str(body.current, 12), next = str(body.next, 12);
  if (!checkPin(cur, user.pin)) throw bad('Your current PIN is not correct.');
  if (!okPin(next)) throw bad('New PIN must be 4 to 6 digits.');
  user.pin = hashPin(next); user.startPin = false; saveCfg(); audit(user, 'pin-change', 'Changed own PIN');
  return { ok: true };
});

/* --- stock --- */
route('GET', '/api/stock', 'any', ({ user }) => {
  const vis = visibleBranches(user), stock = {}, res = reservedOut(), reserved = {};
  vis.forEach(b => { stock[b] = Object.assign({}, CFG.stock[b] || {}); });
  for (const k of Object.keys(res)) if (vis.includes(k.split('|')[0])) reserved[k] = res[k];
  return { stock, reserved };
});
route('GET', '/api/stock/movements', ['supervisor', 'procurement', 'gm'], ({ user, query }) => {
  const bs = new Set(scopeBranches(user, query.branch)), to = today(), from = addDays(to, -30), out = [];
  for (const r of rangeOf('restocks', from, to)) if (bs.has(r.branch)) out.push({ kind: 'Received', at: r.at, branch: r.branch, itemId: r.itemId, qty: r.qty, note: r.note, byName: r.byName });
  for (const a of rangeOf('adjustments', from, to)) if (bs.has(a.branch)) out.push({ kind: a.reason, at: a.at, branch: a.branch, itemId: a.itemId, qty: a.delta, note: a.note, byName: a.byName });
  return { movements: out.sort((a, b) => a.at < b.at ? 1 : -1).slice(0, 25) };
});
route('POST', '/api/restocks', ['procurement', 'gm'], ({ user, body }) => {
  const b = str(body.branch, 20), it = itemById(str(body.itemId, 20)), qty = int(body.qty);
  if (!branchById(b)) throw bad('Choose a branch.'); if (!it) throw bad('Choose an item.'); if (!(qty >= 1 && qty <= 100000)) throw bad('Enter a quantity of 1 or more.');
  const note = str(body.note, 120), cost = Math.max(0, r2(Number(body.cost) || 0)), now = new Date(), date = localParts(now, biz().timezone).date;
  bump(b, it.id, qty);
  put('restocks', { id: uid(), branch: b, itemId: it.id, qty, note, cost, date, at: now.toISOString(), by: user.id, byName: user.name });
  if (body.alsoExpense && cost > 0) put('expenses', { id: uid(), branch: b, date, category: 'Food supplies', note: ('Stock: ' + qty + ' x ' + it.name + (note ? ' (' + note + ')' : '')).slice(0, 140), amount: cost, by: user.id, byName: user.name, at: now.toISOString() });
  saveCfg(); audit(user, 'restock', qty + ' x ' + it.name + ' to ' + branchById(b).name); broadcast('stock'); if (cost > 0) broadcast('expenses');
  return { ok: true };
});
route('POST', '/api/adjustments', ['supervisor', 'gm'], ({ user, body }) => {
  const b = user.role === 'supervisor' ? user.branch : str(body.branch, 20), it = itemById(str(body.itemId, 20)), delta = int(body.delta), reason = str(body.reason, 30);
  if (!branchById(b)) throw bad('Choose a branch.'); if (!it) throw bad('Choose an item.');
  if (!ADJ_REASONS.includes(reason)) throw bad('Choose a reason.'); if (!delta || Math.abs(delta) > 100000) throw bad('Enter a quantity.');
  if (delta > 0 && reason !== 'Recount') throw bad('Only a recount can add stock.');
  if (stockOf(b, it.id) + delta < 0) throw new HttpError(409, 'Only ' + stockOf(b, it.id) + ' ' + it.name + ' in stock at ' + branchById(b).name + '.');
  const now = new Date();
  bump(b, it.id, delta);
  put('adjustments', { id: uid(), branch: b, itemId: it.id, delta, reason, note: str(body.note, 120), date: localParts(now, biz().timezone).date, at: now.toISOString(), by: user.id, byName: user.name });
  saveCfg(); audit(user, 'stock-adjust', reason + ': ' + delta + ' x ' + it.name + ' at ' + branchById(b).name); broadcast('stock');
  return { ok: true };
});

/* --- sales --- */
route('POST', '/api/sales', STAFF_SALES, ({ user, body }) => {
  const b = user.branch, br = branchById(b); if (!br) throw bad('Your account has no branch.');
  if (!Array.isArray(body.lines) || !body.lines.length || body.lines.length > 60) throw bad('Add at least one item.');
  const merged = new Map();
  for (const l of body.lines) {
    const q = int(l.qty); if (!(q >= 1 && q <= 999)) throw bad('Invalid quantity.');
    const it = itemById(l.itemId); if (!it || it.active === false) throw bad('An item in this order is no longer on the menu.');
    merged.set(it.id, (merged.get(it.id) || 0) + q);
  }
  const lines = []; let subtotal = 0;
  for (const [id, q] of merged) {
    const it = itemById(id), have = stockOf(b, id);
    if (have < q) throw new HttpError(409, 'Only ' + have + ' ' + it.name + ' left. Adjust the order.');
    lines.push({ itemId: id, name: it.name, category: it.category, price: it.price, qty: q }); subtotal += it.price * q;
  }
  const shift = openShiftOf(user.id);
  if (biz().requireShift && !shift) throw new HttpError(409, 'Open your shift before selling.');
  const dv = body.discount && ['pct', 'amt'].includes(body.discount.type) ? { type: body.discount.type, value: Math.max(0, Number(body.discount.value) || 0), reason: str(body.discount.reason, 80) } : null;
  const t = calcTotals(subtotal, dv);
  if (user.role === 'sales' && subtotal > 0 && (t.discount / subtotal) * 100 > Number(biz().maxDiscountPct) + 0.001) throw new HttpError(403, 'Discounts above ' + biz().maxDiscountPct + '% need a supervisor.');
  if (!(t.total > 0)) throw bad('The total must be above zero.');
  const p = body.payment || {}, method = ['cash', 'transfer', 'card', 'split'].includes(p.method) ? p.method : null;
  if (!method) throw bad('Choose how the customer paid.');
  let cash = 0, transfer = 0, card = 0, tendered = 0, change = 0;
  if (method === 'cash') { tendered = r2(Number(p.tendered) || 0); if (tendered < t.total) throw bad('Cash received is less than the total.'); cash = t.total; change = r2(tendered - t.total); }
  else if (method === 'transfer') transfer = t.total;
  else if (method === 'card') card = t.total;
  else {
    const c = r2(Number(p.cash) || 0); if (!(c > 0 && c < t.total)) throw bad('For a split payment, cash must be more than zero and less than the total.');
    cash = c; tendered = c; if (p.rest === 'card') card = r2(t.total - c); else transfer = r2(t.total - c);
  }
  const type = ORDER_TYPES.includes(body.order && body.order.type) ? body.order.type : 'dine-in', o = body.order || {};
  const now = new Date(), lp = localParts(now, biz().timezone), sk = b + '|' + lp.date, n = (CFG.seq[sk] || 0) + 1; CFG.seq[sk] = n;
  const sale = {
    id: uid(), no: br.code + '-' + lp.date.slice(5).replace('-', '') + '-' + String(n).padStart(4, '0'), branch: b, date: lp.date, at: now.toISOString(), hour: lp.hour, lines,
    subtotal: t.subtotal, discountType: dv && t.discount > 0 ? dv.type : '', discountValue: dv && t.discount > 0 ? dv.value : 0, discountReason: dv && t.discount > 0 ? dv.reason : '', discountAmt: t.discount,
    vat: t.vat, vatRate: Number(biz().vatRate) || 0, vatInclusive: !!biz().vatInclusive, total: t.total,
    method, cash, transfer, card, tendered, change, ref: str(p.ref, 60),
    orderType: type, table: type === 'dine-in' ? str(o.table, 20) : '', customer: type !== 'dine-in' ? str(o.customer, 60) : '', phone: type === 'delivery' ? str(o.phone, 24) : '', note: str(o.note, 140),
    by: user.id, byName: user.name, shiftId: shift ? shift.id : '', voided: false
  };
  for (const l of lines) bump(b, l.itemId, -l.qty);
  put('sales', sale); saveCfg(); broadcast('sales');
  return { sale };
});
route('GET', '/api/sales', ['sales', 'supervisor', 'gm'], ({ user, query }) => {
  const date = isYmd(query.date) ? query.date : today(), bs = new Set(scopeBranches(user, query.branch));
  let list = rangeOf('sales', date, date).filter(s => bs.has(s.branch));
  if (user.role === 'sales') list = list.filter(s => s.by === user.id);
  const q = str(query.q, 40).toLowerCase();
  if (q) list = list.filter(s => (s.no + ' ' + (s.customer || '') + ' ' + (s.table || '') + ' ' + s.byName + ' ' + s.lines.map(l => l.name).join(' ')).toLowerCase().includes(q));
  list.sort((a, b) => a.at < b.at ? 1 : -1);
  return { date, sales: list.slice(0, 1000), truncated: list.length > 1000 };
});
route('POST', '/api/sales/:id/void', ['supervisor', 'gm'], ({ user, params, body }) => {
  const s = IDX.sales.get(params.id); if (!s) throw new HttpError(404, 'Sale not found.');
  if (s.voided) throw bad('This sale is already voided.');
  if (user.role === 'supervisor' && s.branch !== user.branch) throw new HttpError(403, 'That sale belongs to another branch.');
  const reason = str(body.reason, 120); if (reason.length < 3) throw bad('Give a short reason for the void.');
  s.voided = true; s.voidedBy = user.name; s.voidedAt = new Date().toISOString(); s.voidReason = reason;
  s.lines.forEach(l => bump(s.branch, l.itemId, l.qty));
  touch(s); saveCfg(); audit(user, 'void-sale', s.no + ' (' + s.total + '): ' + reason); broadcast('sales');
  return { sale: s };
});

/* --- expenses --- */
route('POST', '/api/expenses', ['supervisor', 'procurement', 'gm'], ({ user, body }) => {
  const b = user.role === 'supervisor' ? user.branch : str(body.branch, 20), amount = r2(Number(body.amount));
  if (!branchById(b)) throw bad('Choose a branch.'); if (!(amount > 0 && amount < 1e9)) throw bad('Enter an amount above zero.');
  const date = isYmd(body.date) ? body.date : today(); if (date > addDays(today(), 1)) throw bad('The date cannot be in the future.');
  const category = EXP_CATS.includes(body.category) ? body.category : 'Other';
  const e = put('expenses', { id: uid(), branch: b, date, category, note: str(body.note, 140), amount, by: user.id, byName: user.name, at: new Date().toISOString() });
  audit(user, 'expense', category + ' ' + amount + ' at ' + branchById(b).name); broadcast('expenses');
  return { expense: e };
});
route('GET', '/api/expenses', ['supervisor', 'procurement', 'gm'], ({ user, query }) => {
  const to = isYmd(query.to) ? query.to : today(), from = isYmd(query.from) ? query.from : addDays(to, -31), bs = new Set(scopeBranches(user, query.branch));
  if (dayDiff(from, to) > 400) throw bad('Choose a shorter range.');
  const list = rangeOf('expenses', from, to).filter(e => !e.deleted && bs.has(e.branch)).sort((a, b) => a.date === b.date ? (a.at < b.at ? 1 : -1) : (a.date < b.date ? 1 : -1));
  return { expenses: list };
});
route('DELETE', '/api/expenses/:id', ['supervisor', 'procurement', 'gm'], ({ user, params }) => {
  const e = IDX.expenses.get(params.id); if (!e || e.deleted) throw new HttpError(404, 'Expense not found.');
  if (user.role === 'procurement' && e.by !== user.id) throw new HttpError(403, 'You can only delete expenses you entered.');
  if (user.role === 'supervisor' && e.branch !== user.branch) throw new HttpError(403, 'That expense belongs to another branch.');
  e.deleted = true; e.deletedBy = user.name; touch(e); audit(user, 'expense-delete', e.category + ' ' + e.amount); broadcast('expenses');
  return { ok: true };
});

/* --- transfers --- */
const canDecide = (u, t) => u.role === 'gm' || (u.role === 'supervisor' && u.branch === t.to);
route('POST', '/api/transfers', ['procurement', 'gm'], ({ user, body }) => {
  const from = str(body.from, 20), to = str(body.to, 20);
  if (!branchById(from) || !branchById(to) || from === to) throw bad('Choose two different branches.');
  if (!Array.isArray(body.lines) || !body.lines.length || body.lines.length > 60) throw bad('Add at least one item.');
  const merged = new Map();
  for (const l of body.lines) { const q = int(l.qty); if (!itemById(l.itemId)) throw bad('Choose an item on every line.'); if (!(q >= 1 && q <= 100000)) throw bad('Enter a quantity of 1 or more.'); merged.set(l.itemId, (merged.get(l.itemId) || 0) + q); }
  const res = reservedOut(), lines = [];
  for (const [id, q] of merged) {
    const av = stockOf(from, id) - (res[from + '|' + id] || 0);
    if (q > av) throw new HttpError(409, branchById(from).name + ' has only ' + av + ' ' + itemById(id).name + ' available.');
    lines.push({ itemId: id, qty: q });
  }
  const now = new Date();
  const t = put('transfers', { id: uid(), from, to, lines, note: str(body.note, 140), status: 'pending', by: user.id, byName: user.name, at: now.toISOString(), date: localParts(now, biz().timezone).date });
  audit(user, 'transfer-send', branchById(from).name + ' to ' + branchById(to).name); broadcast('transfers');
  return { transfer: t };
});
route('GET', '/api/transfers', ['procurement', 'supervisor', 'gm'], ({ user }) => {
  let list = [...IDX.transfers.values()];
  if (user.role === 'supervisor') list = list.filter(t => t.from === user.branch || t.to === user.branch);
  list.sort((a, b) => a.at < b.at ? 1 : -1);
  return { transfers: list.slice(0, 300) };
});
route('POST', '/api/transfers/:id/approve', ['supervisor', 'gm'], ({ user, params }) => {
  const t = IDX.transfers.get(params.id); if (!t) throw new HttpError(404, 'Transfer not found.');
  if (t.status !== 'pending') throw new HttpError(409, 'This transfer was already ' + t.status + '.');
  if (!canDecide(user, t)) throw new HttpError(403, 'Only the receiving supervisor or the General Manager can approve this.');
  for (const l of t.lines) if (stockOf(t.from, l.itemId) < l.qty) throw new HttpError(409, branchById(t.from).name + ' now has only ' + stockOf(t.from, l.itemId) + ' ' + itemById(l.itemId).name + '. Ask procurement to adjust the transfer.');
  t.lines.forEach(l => { bump(t.from, l.itemId, -l.qty); bump(t.to, l.itemId, l.qty); });
  Object.assign(t, { status: 'approved', decidedBy: user.id, decidedByName: user.name, decidedAt: new Date().toISOString() });
  touch(t); saveCfg(); audit(user, 'transfer-approve', branchById(t.from).name + ' to ' + branchById(t.to).name); broadcast('transfers'); broadcast('stock');
  return { transfer: t };
});
route('POST', '/api/transfers/:id/reject', ['supervisor', 'gm'], ({ user, params, body }) => {
  const t = IDX.transfers.get(params.id); if (!t) throw new HttpError(404, 'Transfer not found.');
  if (t.status !== 'pending') throw new HttpError(409, 'This transfer was already ' + t.status + '.');
  if (!canDecide(user, t)) throw new HttpError(403, 'Only the receiving supervisor or the General Manager can reject this.');
  Object.assign(t, { status: 'rejected', reason: str(body.reason, 140), decidedBy: user.id, decidedByName: user.name, decidedAt: new Date().toISOString() });
  touch(t); audit(user, 'transfer-reject', branchById(t.from).name + ' to ' + branchById(t.to).name); broadcast('transfers');
  return { transfer: t };
});
route('POST', '/api/transfers/:id/cancel', ['procurement', 'gm'], ({ user, params }) => {
  const t = IDX.transfers.get(params.id); if (!t) throw new HttpError(404, 'Transfer not found.');
  if (t.status !== 'pending') throw new HttpError(409, 'This transfer was already ' + t.status + '.');
  if (user.role !== 'gm' && t.by !== user.id) throw new HttpError(403, 'You can only cancel transfers you sent.');
  Object.assign(t, { status: 'cancelled', decidedBy: user.id, decidedByName: user.name, decidedAt: new Date().toISOString() });
  touch(t); audit(user, 'transfer-cancel', branchById(t.from).name + ' to ' + branchById(t.to).name); broadcast('transfers');
  return { transfer: t };
});

/* --- shifts (cash drawer) --- */
route('GET', '/api/shifts/current', STAFF_SALES, ({ user }) => { const sh = openShiftOf(user.id); return { shift: sh ? Object.assign({}, sh, shiftFigures(sh)) : null }; });
route('POST', '/api/shifts/open', STAFF_SALES, ({ user, body }) => {
  if (openShiftOf(user.id)) throw new HttpError(409, 'You already have a shift open.');
  const fl = r2(Number(body.float) || 0); if (fl < 0 || fl > 1e9) throw bad('Enter the opening cash.');
  const now = new Date(), sh = put('shifts', { id: uid(), branch: user.branch, date: localParts(now, biz().timezone).date, by: user.id, byName: user.name, openedAt: now.toISOString(), at: now.toISOString(), float: fl, closedAt: null });
  audit(user, 'shift-open', 'Float ' + fl); broadcast('shifts');
  return { shift: Object.assign({}, sh, shiftFigures(sh)) };
});
route('POST', '/api/shifts/close', STAFF_SALES, ({ user, body }) => {
  const sh = openShiftOf(user.id); if (!sh) throw new HttpError(409, 'You have no shift open.');
  const counted = r2(Number(body.counted)); if (!(counted >= 0) || counted > 1e9) throw bad('Enter the cash you counted.');
  const f = shiftFigures(sh);
  Object.assign(sh, { closedAt: new Date().toISOString(), counted, expected: f.expected, variance: r2(counted - f.expected), cashSales: f.cashSales, totalSales: f.totalSales, count: f.count, closeNote: str(body.note, 140) });
  touch(sh); audit(user, 'shift-close', 'Variance ' + sh.variance); broadcast('shifts');
  return { shift: sh };
});
route('GET', '/api/shifts', ['supervisor', 'gm'], ({ user, query }) => {
  const to = isYmd(query.to) ? query.to : today(), from = isYmd(query.from) ? query.from : to, bs = new Set(scopeBranches(user, query.branch));
  const list = new Map();
  rangeOf('shifts', from, to).filter(s => bs.has(s.branch)).forEach(s => list.set(s.id, s));
  for (const s of IDX.shifts.values()) if (!s.closedAt && bs.has(s.branch)) list.set(s.id, s);
  const out = [...list.values()].sort((a, b) => a.openedAt < b.openedAt ? 1 : -1).map(s => s.closedAt ? s : Object.assign({}, s, shiftFigures(s)));
  return { shifts: out };
});

/* --- overview and reports --- */
route('GET', '/api/overview', ['supervisor', 'gm'], ({ user, query }) => {
  const bs = scopeBranches(user, query.branch), t = today(), wk = [weekStart(t), addDays(weekStart(t), 6)], mo = monthRange(t);
  const day = aggregate(t, t, bs), week = aggregate(wk[0], wk[1], bs), month = aggregate(mo[0], mo[1], bs);
  const small = a => ({ sales: a.sales, expenses: a.expenses, net: a.net });
  const bset = new Set(bs);
  const recent = rangeOf('sales', addDays(t, -2), t).filter(s => bset.has(s.branch)).sort((a, b) => a.at < b.at ? 1 : -1).slice(0, 8);
  const openShifts = [...IDX.shifts.values()].filter(s => !s.closedAt && bset.has(s.branch)).map(s => Object.assign({}, s, shiftFigures(s)));
  return {
    today: t, week: wk, month: mo, day: small(day), weekAgg: small(week), monthAgg: small(month), byHour: day.byHour, topToday: day.topItems.slice(0, 5),
    byBranch: bs.length > 1 ? bs.map(b => { const a = aggregate(t, t, [b]), w = aggregate(wk[0], wk[1], [b]), m = aggregate(mo[0], mo[1], [b]); return { branch: b, day: small(a), week: small(w), month: small(m) }; }) : [],
    low: lowStock(bs).slice(0, 14), recent, openShifts, pending: pendingFor(user)
  };
});
route('GET', '/api/report', ['supervisor', 'gm'], ({ user, query }) => {
  if (!isYmd(query.from) || !isYmd(query.to)) throw bad('Choose a start and end date.');
  const bs = scopeBranches(user, query.branch), cur = aggregate(query.from, query.to, bs);
  let prev = null;
  if (isYmd(query.pfrom) && isYmd(query.pto)) { const p = aggregate(query.pfrom, query.pto, bs); prev = { from: p.from, to: p.to, sales: p.sales, expenses: p.expenses, net: p.net }; }
  return { cur, prev, today: today() };
});
const csvCell = v => { if (typeof v === 'number') return String(v); let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const csv = rows => rows.map(r => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
route('GET', '/api/export/:kind', ['supervisor', 'gm'], ({ user, params, query }) => {
  if (!isYmd(query.from) || !isYmd(query.to) || dayDiff(query.from, query.to) > 400) throw bad('Choose a valid date range.');
  const bs = new Set(scopeBranches(user, query.branch)), bn = id => (branchById(id) || { name: id }).name;
  let rows;
  if (params.kind === 'sales') {
    rows = [['Date', 'Time', 'Receipt', 'Branch', 'Served by', 'Order type', 'Table or customer', 'Items', 'Subtotal', 'Discount', 'VAT', 'Total', 'Cash', 'Transfer', 'Card', 'Status']];
    rangeOf('sales', query.from, query.to).filter(s => bs.has(s.branch)).sort((a, b) => a.at < b.at ? -1 : 1).forEach(s => rows.push([s.date, s.at.slice(11, 16) + ' UTC', s.no, bn(s.branch), s.byName, s.orderType, s.table || s.customer || '', s.lines.map(l => l.qty + ' x ' + l.name).join('; '), s.subtotal, s.discountAmt, s.vat, s.total, s.cash, s.transfer, s.card, s.voided ? 'Voided' : 'Paid']));
  } else if (params.kind === 'items') {
    rows = [['Date', 'Receipt', 'Branch', 'Item', 'Category', 'Quantity', 'Unit price', 'Line total']];
    rangeOf('sales', query.from, query.to).filter(s => bs.has(s.branch) && !s.voided).forEach(s => s.lines.forEach(l => rows.push([s.date, s.no, bn(s.branch), l.name, l.category, l.qty, l.price, r2(l.qty * l.price)])));
  } else if (params.kind === 'expenses') {
    rows = [['Date', 'Branch', 'Category', 'Details', 'Entered by', 'Amount']];
    rangeOf('expenses', query.from, query.to).filter(e => !e.deleted && bs.has(e.branch)).sort((a, b) => a.date < b.date ? -1 : 1).forEach(e => rows.push([e.date, bn(e.branch), e.category, e.note, e.byName, e.amount]));
  } else throw new HttpError(404, 'Unknown export.');
  return { __raw: csv(rows), type: 'text/csv; charset=utf-8', filename: 'ffc-' + params.kind + '-' + query.from + '-to-' + query.to + '.csv' };
});

/* --- General Manager admin --- */
const GM = ['gm'];
route('GET', '/api/admin/users', GM, () => ({ users: CFG.users.map(pubUser) }));
route('POST', '/api/admin/users', GM, ({ user, body }) => {
  const name = str(body.name, 60), role = str(body.role, 20), pin = str(body.pin, 12);
  if (!name) throw bad('Enter a name.'); if (!ROLE_LIST.includes(role)) throw bad('Choose a role.'); if (!okPin(pin)) throw bad('PIN must be 4 to 6 digits.');
  const branch = (role === 'sales' || role === 'supervisor') ? str(body.branch, 20) : null;
  if (branch !== null && !branchById(branch)) throw bad('Choose a branch for this role.');
  const u = { id: 'u_' + uid(), name, role, branch, pin: hashPin(pin), startPin: false, active: true };
  CFG.users.push(u); saveCfg(); audit(user, 'staff-add', name + ' (' + role + ')'); broadcast('config');
  return { user: pubUser(u) };
});
route('PATCH', '/api/admin/users/:id', GM, ({ user, params, body }) => {
  const u = CFG.users.find(x => x.id === params.id); if (!u) throw new HttpError(404, 'Staff member not found.');
  if (body.active === false) {
    if (u.id === user.id) throw bad('You cannot turn off your own account.');
    if (u.role === 'gm' && CFG.users.filter(x => x.role === 'gm' && x.active !== false && x.id !== u.id).length === 0) throw bad('Keep at least one active General Manager.');
  }
  if (typeof body.active === 'boolean') u.active = body.active;
  if (body.name != null) { const n = str(body.name, 60); if (!n) throw bad('Enter a name.'); u.name = n; }
  if (!u.active) revokeUser(u.id);
  saveCfg(); audit(user, 'staff-update', u.name + (typeof body.active === 'boolean' ? (u.active ? ' turned on' : ' turned off') : '')); broadcast('config');
  return { user: pubUser(u) };
});
route('POST', '/api/admin/users/:id/pin', GM, ({ user, params, body }) => {
  const u = CFG.users.find(x => x.id === params.id); if (!u) throw new HttpError(404, 'Staff member not found.');
  const pin = str(body.pin, 12); if (!okPin(pin)) throw bad('PIN must be 4 to 6 digits.');
  u.pin = hashPin(pin); u.startPin = false; if (u.id !== user.id) revokeUser(u.id); saveCfg(); audit(user, 'pin-reset', u.name); broadcast('config');
  return { ok: true };
});
function itemFields(body, cur) {
  const name = str(body.name != null ? body.name : cur && cur.name, 60), category = str(body.category != null ? body.category : cur && cur.category, 30) || 'Meals';
  const unit = str(body.unit != null ? body.unit : cur && cur.unit, 20) || 'piece', price = r2(Number(body.price != null ? body.price : cur && cur.price));
  const emoji = [...str(body.emoji != null ? body.emoji : (cur && cur.emoji) || '', 16)].slice(0, 2).join('');
  const rl = body.reorder != null && body.reorder !== '' ? int(body.reorder) : (cur ? cur.reorder : 5);
  if (!name) throw bad('Enter an item name.'); if (!(price > 0 && price < 1e8)) throw bad('Enter a price above zero.'); if (!(rl >= 0 && rl <= 100000)) throw bad('Enter a whole number for the low-stock level.');
  return { name, category, unit, price, emoji, reorder: rl };
}
route('POST', '/api/admin/items', GM, ({ user, body }) => {
  const it = Object.assign({ id: 'i' + uid(), active: true }, itemFields(body, null));
  CFG.items.push(it); CFG.branches.forEach(b => bump(b.id, it.id, 0)); saveCfg(); audit(user, 'item-add', it.name + ' at ' + it.price); broadcast('config');
  return { item: it };
});
route('PATCH', '/api/admin/items/:id', GM, ({ user, params, body }) => {
  const it = itemById(params.id); if (!it) throw new HttpError(404, 'Item not found.');
  const old = it.price, f = itemFields(body, it); Object.assign(it, f); if (typeof body.active === 'boolean') it.active = body.active;
  saveCfg(); audit(user, 'item-update', it.name + (old !== it.price ? ' price ' + old + ' to ' + it.price : '') + (typeof body.active === 'boolean' ? (it.active ? ' shown' : ' hidden') : '')); broadcast('config');
  return { item: it };
});
route('POST', '/api/admin/branches', GM, ({ user, body }) => {
  const name = str(body.name, 40); if (!name) throw bad('Enter a branch name.');
  const code = (str(body.code, 3).toUpperCase().replace(/[^A-Z0-9]/g, '')) || name.slice(0, 2).toUpperCase();
  if (CFG.branches.some(b => b.code === code)) throw bad('Another branch already uses the code ' + code + '.');
  const b = { id: 'b' + uid(), name, code }; CFG.branches.push(b); CFG.stock[b.id] = {}; CFG.items.forEach(i => { CFG.stock[b.id][i.id] = 0; });
  saveCfg(); audit(user, 'branch-add', name); broadcast('config');
  return { branch: b };
});
route('PATCH', '/api/admin/branches/:id', GM, ({ user, params, body }) => {
  const b = branchById(params.id); if (!b) throw new HttpError(404, 'Branch not found.');
  const name = str(body.name, 40); if (!name) throw bad('Enter a branch name.');
  const old = b.name; b.name = name; saveCfg(); audit(user, 'branch-rename', old + ' to ' + name); broadcast('config');
  return { branch: b };
});
route('PATCH', '/api/admin/settings', GM, ({ user, body }) => {
  const b = biz(), n = {};
  if (body.name != null) { n.name = str(body.name, 60); if (!n.name) throw bad('Enter the business name.'); }
  if (body.currency != null) { n.currency = str(body.currency, 4); if (!n.currency) throw bad('Enter a currency symbol.'); }
  if (body.timezone != null) { n.timezone = str(body.timezone, 60); if (!validTz(n.timezone)) throw bad('That time zone is not recognised. Example: Africa/Lagos.'); }
  if (body.vatRate != null) { n.vatRate = Number(body.vatRate); if (!(n.vatRate >= 0 && n.vatRate <= 100)) throw bad('VAT must be between 0 and 100.'); }
  if (body.vatInclusive != null) n.vatInclusive = !!body.vatInclusive;
  if (body.maxDiscountPct != null) { n.maxDiscountPct = Number(body.maxDiscountPct); if (!(n.maxDiscountPct >= 0 && n.maxDiscountPct <= 100)) throw bad('Discount limit must be between 0 and 100.'); }
  if (body.receiptFooter != null) n.receiptFooter = str(body.receiptFooter, 120);
  if (body.requireShift != null) n.requireShift = !!body.requireShift;
  Object.assign(b, n); saveCfg(); audit(user, 'settings', Object.keys(n).join(', ')); broadcast('config');
  return { business: b };
});
route('GET', '/api/admin/audit', GM, ({ query }) => {
  const to = today(), from = addDays(to, -Math.min(120, Math.max(1, int(query.days) || 30))), q = str(query.q, 40).toLowerCase();
  let list = rangeOf('audit', from, to); if (q) list = list.filter(a => (a.action + ' ' + a.detail + ' ' + a.byName).toLowerCase().includes(q));
  list.sort((a, b) => a.at < b.at ? 1 : -1);
  return { audit: list.slice(0, 300) };
});
route('GET', '/api/admin/backup', GM, () => {
  const months = {}; for (const k of Object.keys(MONTHS).sort()) months[k] = MONTHS[k];
  const cfg = Object.assign({}, CFG, { sessions: undefined, users: CFG.users.map(pubUser) });
  return { __raw: JSON.stringify({ exportedAt: new Date().toISOString(), config: cfg, months }), type: 'application/json', filename: 'ffc-backup-' + today() + '.json' };
});

/* --- live updates --- */
route('GET', '/api/events', 'any', ({ req, res }) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.write('retry: 3000\n\n'); clients.add(res);
  req.on('close', () => clients.delete(res));
  return { __handled: true };
});

/* ------------------------------------------------------------------ HTTP plumbing */
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
};
const clientIp = req => TRUST_PROXY ? ((req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress) : req.socket.remoteAddress;
function readBody(req, limit = 262144) {
  return new Promise((resolve, reject) => {
    let n = 0; const ch = [];
    req.on('data', c => { n += c.length; if (n > limit) { reject(new HttpError(413, 'Request too large.')); req.destroy(); return; } ch.push(c); });
    req.on('end', () => { if (!ch.length) return resolve({}); try { const j = JSON.parse(Buffer.concat(ch).toString('utf8')); resolve(j && typeof j === 'object' ? j : {}); } catch (e) { reject(bad('Invalid JSON.')); } });
    req.on('error', reject);
  });
}
function sendJson(req, res, status, obj) {
  const buf = Buffer.from(JSON.stringify(obj)), h = Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, SEC);
  if (buf.length > 2048 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { const z = zlib.gzipSync(buf); h['Content-Encoding'] = 'gzip'; h.Vary = 'Accept-Encoding'; res.writeHead(status, h); return res.end(z); }
  res.writeHead(status, h); res.end(buf);
}
async function handleApi(req, res, url) {
  const pathname = url.pathname, query = Object.fromEntries(url.searchParams);
  let matched = null, pathHit = false;
  for (const r of routes) { const m = r.re.exec(pathname); if (!m) continue; pathHit = true; if (r.method !== req.method) continue; matched = { r, m }; break; }
  if (!matched) return sendJson(req, res, pathHit ? 405 : 404, { error: pathHit ? 'Method not allowed.' : 'Not found.' });
  const { r, m } = matched; let user = null;
  if (r.roles) {
    user = sessionUser(req); if (!user) return sendJson(req, res, 401, { error: 'Please sign in again.' });
    if (Array.isArray(r.roles) && !r.roles.includes(user.role)) return sendJson(req, res, 403, { error: 'Your role cannot do this.' });
  }
  const params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
  const body = (req.method === 'GET' || req.method === 'DELETE') ? {} : await readBody(req);
  const out = await r.fn({ req, res, user, params, query, body, ip: clientIp(req) });
  if (out && out.__handled) return;
  if (out && out.__raw != null) {
    res.writeHead(200, Object.assign({ 'Content-Type': out.type, 'Content-Disposition': 'attachment; filename="' + out.filename + '"', 'Cache-Control': 'no-store' }, SEC)); return res.end(out.__raw);
  }
  sendJson(req, res, 200, out === undefined ? { ok: true } : out);
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2' };
const TEXTY = new Set(['.html', '.css', '.js', '.json', '.webmanifest', '.svg', '.txt']);
const fileCache = new Map();
function serveFile(req, res, file, status) {
  let st; try { st = fs.statSync(file); } catch (e) { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(file).toLowerCase();
  let c = fileCache.get(file);
  if (!c || c.mtime !== st.mtimeMs || c.size !== st.size) {
    const buf = fs.readFileSync(file);
    c = { mtime: st.mtimeMs, size: st.size, buf, etag: '"' + sha256(buf).slice(0, 20) + '"', gz: TEXTY.has(ext) && buf.length > 1024 ? zlib.gzipSync(buf) : null };
    fileCache.set(file, c);
  }
  const h = Object.assign({ 'Content-Type': MIME[ext] || 'application/octet-stream', ETag: c.etag, 'Cache-Control': 'no-cache', Vary: 'Accept-Encoding' }, SEC);
  if (status === 200 && req.headers['if-none-match'] === c.etag) { res.writeHead(304, h); res.end(); return true; }
  let body = c.buf;
  if (c.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { body = c.gz; h['Content-Encoding'] = 'gzip'; }
  h['Content-Length'] = body.length; res.writeHead(status || 200, h); res.end(req.method === 'HEAD' ? undefined : body);
  return true;
}
function serveStatic(req, res, pathname) {
  let rel; try { rel = decodeURIComponent(pathname); } catch (e) { res.writeHead(400, SEC); return res.end('Bad request'); }
  if (rel === '/app') { res.writeHead(301, Object.assign({ Location: '/app/' }, SEC)); return res.end(); }
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (file !== PUBLIC_DIR && !file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403, SEC); return res.end('Forbidden'); }
  if (serveFile(req, res, file, 200)) return;
  if (rel.startsWith('/app/') && !path.extname(rel) && serveFile(req, res, path.join(PUBLIC_DIR, 'app', 'index.html'), 200)) return;
  if (!serveFile(req, res, path.join(PUBLIC_DIR, '404.html'), 404)) { res.writeHead(404, Object.assign({ 'Content-Type': 'text/plain; charset=utf-8' }, SEC)); res.end('Not found'); }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, SEC); return res.end('Method not allowed'); }
    serveStatic(req, res, url.pathname);
  } catch (e) {
    if (res.headersSent) { try { res.end(); } catch (x) { /* ignore */ } return; }
    if (e instanceof HttpError) return sendJson(req, res, e.status, { error: e.message });
    console.error(e); sendJson(req, res, 500, { error: 'Something went wrong on the server.' });
  }
});
server.keepAliveTimeout = 65000;

loadAll();
setInterval(() => { for (const c of clients) { try { c.write(': ping\n\n'); } catch (e) { clients.delete(c); } } }, 25000).unref();
setInterval(() => { const n = Date.now(); let ch = false; for (const k of Object.keys(CFG.sessions)) if (CFG.sessions[k].exp < n) { delete CFG.sessions[k]; ch = true; } if (ch) saveCfg(); }, 3600000).unref();
function shutdown() { console.log('Saving and shutting down...'); try { flush(); } catch (e) { /* ignore */ } process.exit(0); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
server.listen(PORT, HOST, () => {
  console.log('FFC Eatery POS is running.\n  Website:  http://localhost:' + PORT + '/\n  POS app:  http://localhost:' + PORT + '/app/\n  Data in:  ' + DATA_DIR);
});
