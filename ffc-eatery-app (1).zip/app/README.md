# FFC Eatery — POS & Website

A full-stack website + point-of-sale web app for FFC Eatery, with two branches
(Main and Second) and four staff roles.

## Run locally

Requires Node.js 18+, no dependencies to install.

```bash
node server.js
```

- Public site: http://localhost:3000/
- Staff POS app: http://localhost:3000/app/
- Set `PORT=xxxx` to change the port.

On first run it seeds demo accounts (set `SEED_DEMO=0` to skip):

| Role | Name | PIN |
|---|---|---|
| General Manager | Amaka | 1000 |
| Procurement Officer | Tunde | 2000 |
| Supervisor, Main | Ngozi | 3000 |
| Supervisor, Second | Ibrahim | 3001 |
| Sales, Main | Chidi | 4000 |
| Sales, Second | Bola | 4001 |

Change these PINs from **Settings → Staff** after signing in as GM. Everyone
is prompted to set their own PIN the first time they sign in with a starter
PIN.

## What each role can do

- **Sales Point** — ring up sales (cash / transfer / card / split), apply
  discounts within an allowed cap, pick order type (dine-in / takeaway /
  delivery), open & close their cash shift.
- **Supervisor** — everything Sales Point can do for their branch, plus void
  sales, approve/reject incoming stock transfers, record wastage/adjustments,
  see their branch's dashboard and reports.
- **Procurement Officer** — restock branches, create stock transfers between
  branches, see stock levels everywhere.
- **General Manager** — everything, for all branches: full reports & CSV
  exports, menu/staff/branch/business settings, audit log, backups.

## Data

Stored as plain JSON under `data/` (created on first run): `config.json`
holds settings/users/items/stock, and `data/months/YYYY-MM.json` holds each
month's sales, expenses, restocks, transfers and shifts. Back it up by
copying the `data/` folder, or use **Settings → Backup** as GM.

## Deploying

- **Docker**: `docker build -t ffc-pos . && docker run -p 3000:3000 -v ffc-data:/app/data ffc-pos`
- **Render**: `render.yaml` is included — connect the repo and Render will
  pick it up. Mount a persistent disk at `/app/data` so data survives
  deploys.
- Set `ADMIN_PIN` as an environment variable to control the GM's seeded PIN
  instead of the default.

## Project layout

```
server.js              Zero-dependency Node backend (API, auth, SSE, static files)
public/
  index.html, assets/   Public marketing site (menu, branches)
  app/                  The POS web app (login, sell, sales, stock, transfers,
                         shifts, expenses, reports, settings)
```
